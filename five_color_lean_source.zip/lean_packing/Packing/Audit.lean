import Packing.ClosedWalks
import Packing.NecklaceTheorem
import Packing.SmallGraphs
import Packing.SharpnessResult
import Packing.Tips
import Packing.MarkedCycles
import Packing.TriangleLemmas
import Packing.Target
import Packing.NegativeControls
import Packing.FullTheorem

#print axioms Packing.Universal.arbitrary_gap_sequence
#print axioms Packing.Universal.long_single_gap
#print axioms Packing.Automaton.stabilization
#print axioms Packing.History.ordinary_steps_sound
#print axioms Packing.History.periodic_two_arc_separation
#print axioms Packing.closed_history_walk
#print axioms Packing.closed_history_cycle_colorable
#print axioms Packing.IsPacking.withTips
#print axioms Packing.periodic_history_marked_cycle_colorable
#print axioms Packing.necklace_two_or_more_colorable
#print axioms Packing.necklace_long_singleton_colorable
#print axioms Packing.necklace_colorable
#print axioms Packing.SingleGap2.colorable
#print axioms Packing.SingleGap3.colorable
#print axioms Packing.SingleGap4.colorable
#print axioms Packing.triangle_has_degree_two
#print axioms Packing.SmallGraphs.Diamond.colorable
#print axioms Packing.SmallGraphs.GapThree.colorable
#print axioms Packing.SmallGraphs.GapFour.colorable
#print axioms Packing.SmallGraphs.Barbell.colorable
#print axioms Packing.SmallGraphs.SharpnessExample.colorable
#print axioms Packing.SmallGraphs.SharpnessExample.not_four_colorable
#print axioms Packing.SmallGraphs.SharpnessExample.in_target_class
#print axioms Packing.SmallGraphs.SharpnessExample.exactly_five
#print axioms Packing.PackingColorable.of_components
#print axioms Packing.TargetClass.component
#print axioms Packing.connected_shared_edge_colorable
#print axioms Packing.TriangleSelection.exists_data
#print axioms Packing.TipDeletionData.connected
#print axioms Packing.TipDeletionData.degree_le_two
#print axioms Packing.TipDeletionData.colorable
#print axioms Packing.degree_two_vertex_order
#print axioms Packing.degree_two_induced_cycle
#print axioms Packing.connected_barbell_colorable
#print axioms Packing.TipDeletionData.bridge_colorable
#print axioms Packing.backboneCycle_colorable
#print axioms Packing.degree_two_colorable
#print axioms Packing.markedCycle_colorable
#print axioms Packing.degree_two_tipped_cycle
#print axioms Packing.cyclic_spacing_of_predecessor_exclusions
#print axioms Packing.degree_two_tipped_colorable
#print axioms Packing.connected_target_colorable
#print axioms Packing.target_class_colorable
#print axioms Packing.target_theorem
#print axioms Packing.full_theorem_and_sharpness
