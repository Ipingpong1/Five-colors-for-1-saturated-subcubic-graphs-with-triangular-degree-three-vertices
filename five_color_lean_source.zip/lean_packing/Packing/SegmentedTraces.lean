import Packing.Traces

namespace Packing

/-- Cumulative segment endpoints, including the final endpoint. -/
def segmentEnds : List Nat → List Nat
  | [] => []
  | n :: ns => n :: (segmentEnds ns).map (n + ·)

theorem segmentEnds_le_sum (ns : List Nat) (k : Nat) (hk : k ∈ segmentEnds ns) :
    k ≤ ns.sum := by
  induction ns generalizing k with
  | nil => simp [segmentEnds] at hk
  | cons n ns ih =>
    simp only [segmentEnds, List.mem_cons, List.mem_map] at hk
    rcases hk with rfl | ⟨j, hj, rfl⟩
    · simp only [List.sum_cons]; omega
    · have := ih j hj
      simp only [List.sum_cons]; omega

inductive SegmentedTrace (B : Rel α) (good : α → Prop) : List Nat → α → α → Prop
  | nil (a) : SegmentedTrace B good [] a a
  | cons {n ns a b c} : Trace B n a b → good b →
      SegmentedTrace B good ns b c → SegmentedTrace B good (n :: ns) a c

def joinPaths (f g : Nat → α) (n : Nat) : Nat → α :=
  fun k => if k ≤ n then f k else g (k-n)

theorem joinPaths_left (f g : Nat → α) (n k : Nat) (hk : k ≤ n) :
    joinPaths f g n k = f k := by simp [joinPaths, hk]

theorem joinPaths_right (f g : Nat → α) (n k : Nat) (bridge : f n = g 0) :
    joinPaths f g n (n+k) = g k := by
  by_cases hz : k = 0
  · subst k; simpa [joinPaths] using bridge
  · simp [joinPaths, show ¬ n+k ≤ n by omega]

theorem SegmentedTrace.indexed {B : Rel α} {good : α → Prop}
    {ns : List Nat} {a b : α} (p : SegmentedTrace B good ns a b) :
    ∃ f : Nat → α, f 0 = a ∧ f ns.sum = b ∧
      (∀ k, k < ns.sum → B (f k) (f (k+1))) ∧
      ∀ k ∈ segmentEnds ns, good (f k) := by
  induction p with
  | nil a => exact ⟨fun _ => a, rfl, rfl, fun _ h => by simp at h, by simp [segmentEnds]⟩
  | @cons n ns a b c p hb q ih =>
    obtain ⟨f, fzero, fend, fedge⟩ := p.indexed
    obtain ⟨g, gzero, gend, gedge, ggood⟩ := ih
    have bridge : f n = g 0 := fend.trans gzero.symm
    refine ⟨joinPaths f g n, ?_, ?_, ?_, ?_⟩
    · rw [joinPaths_left f g n 0 (by omega)]; exact fzero
    · simpa only [List.sum_cons, joinPaths_right f g n ns.sum bridge] using gend
    · intro k hk
      by_cases hkn : k < n
      · rw [joinPaths_left f g n k (by omega), joinPaths_left f g n (k+1) (by omega)]
        exact fedge k hkn
      · have he : k = n+(k-n) := by omega
        have he' : k+1 = n+((k-n)+1) := by omega
        rw [he, joinPaths_right f g n (k-n) bridge]
        have hnext : joinPaths f g n (n+(k-n)+1) = g ((k-n)+1) := by
          rw [show n+(k-n)+1 = n+((k-n)+1) by omega, joinPaths_right f g n ((k-n)+1) bridge]
        rw [hnext]
        exact gedge (k-n) (by simp only [List.sum_cons] at hk; omega)
    · intro k hk
      simp only [segmentEnds, List.mem_cons, List.mem_map] at hk
      rcases hk with hk | ⟨j, hj, rfl⟩
      · rw [hk, joinPaths_left f g n n (by omega), fend]; exact hb
      · rw [joinPaths_right f g n j bridge]; exact ggood j hj

theorem Rel.comp_ident (P : Rel α) : P.comp Rel.ident = P := by
  funext a b
  apply propext
  constructor
  · rintro ⟨c, h, rfl⟩; exact h
  · intro h; exact ⟨b, h, rfl⟩

theorem extend_comp_left (R : γ → Rel α) (P Q : Rel α) (gs : List γ) :
    extend R (P.comp Q) gs = P.comp (extend R Q gs) := by
  induction gs generalizing Q with
  | nil => rfl
  | cons g gs ih =>
    simp only [extend, Rel.comp_assoc]
    exact ih (Q.comp (R g))

theorem product_cons (R : γ → Rel α) (g : γ) (gs : List γ) :
    product R (g::gs) = (R g).comp (product R gs) := by
  unfold product
  rw [extend, Rel.ident_comp, ← Rel.comp_ident (R g), extend_comp_left]
  rw [Rel.comp_ident]

theorem segmented_product (B : Rel α) (good : α → Prop) (R : γ → Rel β)
    (f : β → α) (len : γ → Nat)
    (hR : ∀ g u v, R g u v → Trace B (len g) (f u) (f v))
    (hf : ∀ v, good (f v)) (gs : List γ) (u v : β) (h : product R gs u v) :
    SegmentedTrace B good (gs.map len) (f u) (f v) := by
  induction gs generalizing u v with
  | nil =>
    change u = v at h
    subst v
    exact SegmentedTrace.nil (f u)
  | cons g gs ih =>
    rw [product_cons] at h
    obtain ⟨w, hw, ht⟩ := h
    exact SegmentedTrace.cons (hR g u w hw) (hf w) (ih w v ht)

/-- Repeating a finite closed run preserves every indexed state, including
its endpoint, after reducing the index modulo the period. -/
theorem periodize_indexed (B : Rel α) (f : Nat → α) (L : Nat) (hL : 0 < L)
    (closed : f L = f 0) (edges : ∀ k, k < L → B (f k) (f (k+1))) :
    ∃ run : Nat → α, (∀ k, B (run k) (run (k+1))) ∧
      (∀ k, run (k+L) = run k) ∧ ∀ k, k ≤ L → run (k % L) = f k := by
  let run := fun k => f (k % L)
  refine ⟨run, ?_, ?_, ?_⟩
  · intro k
    have hk := Nat.mod_lt k hL
    have he := edges (k % L) hk
    change B (f (k % L)) (f ((k+1) % L))
    rw [← Nat.mod_add_mod k L 1]
    by_cases hlast : k % L + 1 = L
    · rw [hlast, Nat.mod_self]
      rwa [hlast, closed] at he
    · have hs : k % L + 1 < L := by omega
      rw [Nat.mod_eq_of_lt hs]
      exact he
  · intro k; simp [run]
  · intro k hk
    change f ((k % L) % L) = f k
    rw [Nat.mod_mod]
    by_cases hl : k < L
    · rw [Nat.mod_eq_of_lt hl]
    · have he : k = L := by omega
      subst k
      rw [Nat.mod_self]
      exact closed.symm

end Packing
