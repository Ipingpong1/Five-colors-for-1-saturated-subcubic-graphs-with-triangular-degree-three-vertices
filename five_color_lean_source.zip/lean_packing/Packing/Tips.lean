import Packing.Graphs

namespace Packing
open SimpleGraph

/-- A graph map that may collapse edges still sends walks to no-longer walks. -/
theorem map_walk_allowing_collapse {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    (f : V → W) (hf : ∀ u v, G.Adj u v → f u = f v ∨ H.Adj (f u) (f v))
    {u v : V} (p : G.Walk u v) :
    ∃ q : H.Walk (f u) (f v), q.length ≤ p.length := by
  induction p with
  | nil => exact ⟨Walk.nil, Nat.le_refl 0⟩
  | @cons u v w huv p ih =>
    obtain ⟨q, hq⟩ := ih
    rcases hf u v huv with heq | hadj
    · rw [heq]
      exact ⟨q, Nat.le_trans hq (by simp)⟩
    · exact ⟨Walk.cons hadj q, by simpa using Nat.add_le_add_right hq 1⟩

theorem walk_length_gt_one {V : Type*} {G : SimpleGraph V} {u v : V}
    (hne : u ≠ v) (hno : ¬ G.Adj u v) (p : G.Walk u v) : 1 < p.length := by
  cases p with
  | nil => exact False.elim (hne rfl)
  | cons h p =>
    cases p with
    | nil => exact False.elim (hno h)
    | cons h' p => simp only [Walk.length_cons]; omega

/-- Add independent tips, each adjacent to the endpoints of an existing edge. -/
def tipGraph {V T : Type*} (G : SimpleGraph V) (l r : T → V) : SimpleGraph (V ⊕ T) where
  Adj x y := match x, y with
    | .inl u, .inl v => G.Adj u v
    | .inl u, .inr t => u = l t ∨ u = r t
    | .inr t, .inl u => u = l t ∨ u = r t
    | .inr _, .inr _ => False
  symm := ⟨by
    intro x y h
    cases x <;> cases y
    · exact h.symm
    · exact h
    · exact h
    · exact h⟩
  loopless := ⟨by
    intro x
    cases x
    · exact fun h => h.ne rfl
    · exact id⟩

def tipColor {V T : Type*} (c : V → Nat) : V ⊕ T → Nat
  | .inl v => c v
  | .inr _ => 1

theorem tips_projection {V T : Type*} (G : SimpleGraph V) (l r : T → V)
    (edges : ∀ t, G.Adj (l t) (r t)) (x y : V ⊕ T)
    (h : (tipGraph G l r).Adj x y) :
    Sum.elim id l x = Sum.elim id l y ∨ G.Adj (Sum.elim id l x) (Sum.elim id l y) := by
  cases x with
  | inl u =>
    cases y with
    | inl v => exact Or.inr h
    | inr t =>
      rcases h with h | h
      · exact Or.inl h
      · exact Or.inr (h ▸ (edges t).symm)
  | inr t =>
    cases y with
    | inl u =>
      rcases h with h | h
      · exact Or.inl h.symm
      · exact Or.inr (h ▸ edges t)
    | inr s => exact False.elim h

/-- Coloring every added tip 1 preserves packing if all its ports avoid 1. -/
theorem IsPacking.withTips {V T : Type*} {G : SimpleGraph V} {c : V → Nat}
    (hc : IsPacking G c) (l r : T → V)
    (edges : ∀ t, G.Adj (l t) (r t))
    (ports : ∀ t, c (l t) ≠ 1 ∧ c (r t) ≠ 1) :
    IsPacking (tipGraph G l r) (tipColor c) := by
  intro x y hne heq p
  cases x with
  | inl u =>
    cases y with
    | inl v =>
      have huv : u ≠ v := fun h => hne (congrArg Sum.inl h)
      obtain ⟨q, hq⟩ := map_walk_allowing_collapse (Sum.elim id l)
        (tips_projection G l r edges) p
      exact Nat.lt_of_lt_of_le (hc u v huv heq q) hq
    | inr t =>
      have hu : c u = 1 := heq
      have hno : ¬ (tipGraph G l r).Adj (.inl u) (.inr t) := by
        intro h
        rcases h with h | h
        · exact (ports t).1 (h ▸ hu)
        · exact (ports t).2 (h ▸ hu)
      change c u < p.length
      rw [hu]
      exact walk_length_gt_one hne hno p
  | inr t =>
    cases y with
    | inl u =>
      have hu : c u = 1 := heq.symm
      have hno : ¬ (tipGraph G l r).Adj (.inr t) (.inl u) := by
        intro h
        rcases h with h | h
        · exact (ports t).1 (h ▸ hu)
        · exact (ports t).2 (h ▸ hu)
      exact walk_length_gt_one hne hno p
    | inr s => exact walk_length_gt_one hne (fun h => h) p

theorem packingColorable_withTips {V T : Type*} {G : SimpleGraph V} {c : V → Nat}
    {k : Nat} (hk : 1 ≤ k) (bounds : ∀ v, 1 ≤ c v ∧ c v ≤ k)
    (hc : IsPacking G c) (l r : T → V) (edges : ∀ t, G.Adj (l t) (r t))
    (ports : ∀ t, c (l t) ≠ 1 ∧ c (r t) ≠ 1) :
    PackingColorable (tipGraph G l r) k := by
  refine ⟨tipColor c, ?_, hc.withTips l r edges ports⟩
  intro x
  cases x with
  | inl v => exact bounds v
  | inr t => exact ⟨Nat.le_refl 1, hk⟩

end Packing
