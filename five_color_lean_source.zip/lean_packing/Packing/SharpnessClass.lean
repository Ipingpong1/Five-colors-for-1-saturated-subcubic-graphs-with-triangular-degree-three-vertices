import Packing.SmallGraphs

namespace Packing.SmallGraphs.SharpnessExample
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

/-- The explicit sharpness graph satisfies exactly the hypotheses of the paper. -/
theorem in_target_class : TargetClass graph := by
  unfold TargetClass
  decide_cbv

#print axioms in_target_class
end Packing.SmallGraphs.SharpnessExample
