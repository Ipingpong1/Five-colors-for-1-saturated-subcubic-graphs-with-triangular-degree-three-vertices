import Packing.Relations
namespace Packing.History
abbrev Word := Vector Nat 5

def Admissible (s : Word) : Prop :=
  (∀ i : Fin 5, 1 ≤ s[i.val] ∧ s[i.val] ≤ 5) ∧
  (∀ i j : Fin 5, i.val < j.val → s[i.val] = s[j.val] → s[i.val] < j.val - i.val)
instance (s : Word) : Decidable (Admissible s) := by unfold Admissible; infer_instance

def Step (s t : Word) : Prop :=
  (∀ i : Fin 4, t[i.val] = s[i.val+1]) ∧
  (1 ≤ t[4] ∧ t[4] ≤ 5) ∧
  (∀ i : Fin 5, s[i.val] = t[4] → t[4] < 5 - i.val)
instance (s t : Word) : Decidable (Step s t) := by unfold Step; infer_instance

end Packing.History
