import Packing.ConnectedReduction
import Packing.Components
import Packing.Target
import Packing.SharpnessResult

namespace Packing
open SimpleGraph

/-- Every finite simple subcubic graph whose degree-three vertices are
triangular and each have at most one degree-three neighbor has a packing
coloring with colors 1 through 5. Disconnected and empty graphs are included. -/
theorem target_class_colorable {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G) :
    PackingColorable G 5 := by
  classical
  apply PackingColorable.of_components
  intro C
  letI : Fintype C := Fintype.ofFinite _
  exact connected_target_colorable C.toSimpleGraph (hG.component C) C.connected_toSimpleGraph

/-- The statement recorded in `Target.lean`, now proved. -/
theorem target_theorem : TargetTheorem := by
  classical
  unfold TargetTheorem
  intro n G hG
  exact target_class_colorable G hG

/-- The universal upper bound together with a twelve-vertex target-class
example for which four colors are impossible. Thus five is optimal. -/
theorem full_theorem_and_sharpness : TargetTheorem ∧
    ∃ G : SimpleGraph (Fin 12),
      (∃ inst : DecidableRel G.Adj, @TargetClass _ _ G inst) ∧
      PackingColorable G 5 ∧ ¬ PackingColorable G 4 :=
  ⟨target_theorem, SmallGraphs.SharpnessExample.sharp_example⟩

end Packing
