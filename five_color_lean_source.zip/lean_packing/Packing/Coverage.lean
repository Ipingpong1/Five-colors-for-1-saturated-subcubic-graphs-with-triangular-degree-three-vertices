import Packing.BitMatrix

namespace Packing

/-- Explicit intermediate vertices witnessing a matrix-product inclusion. -/
abbrev CoverWitness (n : Nat) := Vector (List (Fin n)) n

def coverCheck (P Q R : BitMatrix n) (w : CoverWitness n) : Bool :=
  allFin n fun i =>
    (w[i.val].all fun k => Q[i.val].testBit k.val) &&
    ((P[i.val] &&& orList (w[i.val].map fun k => R[k.val])) == P[i.val])

/-- The witness generator is untrusted. This theorem proves the checker sound. -/
theorem coverCheck_sound (P Q R : BitMatrix n) (w : CoverWitness n)
    (h : coverCheck P Q R w = true) : P.denote.Included (Q.denote.comp R.denote) := by
  intro i j hp
  have hc := allFin_sound h i
  simp only [Bool.and_eq_true] at hc
  have hb := hc
  change P[i.val].testBit j.val = true at hp
  have heq : P[i.val] &&& orList (w[i.val].map fun k => R[k.val]) = P[i.val] := by
    simpa only [beq_iff_eq] using hb.2
  have hbit := congrArg (fun x : Nat => x.testBit j.val) heq
  have hor : (orList (w[i.val].map fun k => R[k.val])).testBit j.val = true := by
    simpa only [Nat.testBit_and, hp, Bool.true_and] using hbit
  obtain ⟨row, hrow, hbit⟩ := (orList_spec _ j.val).mp hor
  obtain ⟨k, hk, he⟩ := List.mem_map.mp hrow
  have hq := List.all_eq_true.mp hb.1 k hk
  refine ⟨k, hq, ?_⟩
  change R[k.val].testBit j.val = true
  rw [he]
  exact hbit

end Packing
