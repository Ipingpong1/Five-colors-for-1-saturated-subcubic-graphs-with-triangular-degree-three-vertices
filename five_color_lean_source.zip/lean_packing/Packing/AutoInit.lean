import Packing.GapDefs
import Packing.FastMatrix
namespace Packing.Automaton.Checks
open Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

theorem initial_checked : P0 = BitMatrix.ident 390 := by
  apply BitMatrix.eqCheck_sound
  decide +kernel

theorem stabilization_checked : P14 = P15 := by rfl
end Packing.Automaton.Checks
