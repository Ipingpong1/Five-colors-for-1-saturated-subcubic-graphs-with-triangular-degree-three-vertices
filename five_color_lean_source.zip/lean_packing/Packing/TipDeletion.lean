import Packing.Tips
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

namespace Packing
open SimpleGraph

/-- Data for simultaneously removing independent degree-two triangle tips.
The neighborhood equivalence is exact, so no incident edge is discarded. -/
structure TipDeletionData {V : Type*} (G : SimpleGraph V) where
  tips : Set V
  left : tips → V
  right : tips → V
  left_keep : ∀ t, left t ∉ tips
  right_keep : ∀ t, right t ∉ tips
  ports_adj : ∀ t, G.Adj (left t) (right t)
  tip_adj : ∀ (t : tips) v, G.Adj t.val v ↔ v = left t ∨ v = right t

namespace TipDeletionData
variable {V : Type*} {G : SimpleGraph V} (D : TipDeletionData G)

abbrev Kept := {v : V // v ∉ D.tips}
noncomputable instance [Fintype V] : Fintype D.Kept := Fintype.ofFinite _
def backbone : SimpleGraph D.Kept := G.induce {v | v ∉ D.tips}
noncomputable instance : DecidableRel D.backbone.Adj := Classical.decRel _
def leftPort (t : D.tips) : D.Kept := ⟨D.left t, D.left_keep t⟩
def rightPort (t : D.tips) : D.Kept := ⟨D.right t, D.right_keep t⟩

theorem ports_edge (t : D.tips) : D.backbone.Adj (D.leftPort t) (D.rightPort t) :=
  D.ports_adj t

noncomputable def project (v : V) : D.Kept := by
  classical
  exact if h : v ∈ D.tips then D.leftPort ⟨v, h⟩ else ⟨v, h⟩

@[simp] theorem project_kept (v : D.Kept) : D.project v.val = v := by
  classical
  simp [project, v.property]

theorem project_edges (u v : V) (h : G.Adj u v) :
    D.project u = D.project v ∨ D.backbone.Adj (D.project u) (D.project v) := by
  classical
  by_cases hu : u ∈ D.tips
  · have hv : v = D.left ⟨u, hu⟩ ∨ v = D.right ⟨u, hu⟩ := (D.tip_adj ⟨u, hu⟩ v).mp h
    rcases hv with rfl | rfl
    · left
      simp [project, hu, D.left_keep, leftPort]
    · right
      simpa [project, hu, D.right_keep, backbone, leftPort, rightPort] using D.ports_adj ⟨u, hu⟩
  · by_cases hv : v ∈ D.tips
    · have hx := (D.tip_adj ⟨v, hv⟩ u).mp h.symm
      rcases hx with rfl | rfl
      · left
        simp [project, hv, D.left_keep, leftPort]
      · right
        simpa [project, hv, D.right_keep, backbone, leftPort, rightPort] using (D.ports_adj ⟨v, hv⟩).symm
    · right
      simpa [project, hu, hv, backbone] using h

theorem preconnected (h : G.Preconnected) : D.backbone.Preconnected := by
  intro u v
  obtain ⟨p⟩ := h u.val v.val
  obtain ⟨q, _⟩ := map_walk_allowing_collapse D.project D.project_edges p
  simpa only [project_kept] using q.reachable

theorem connected (h : G.Connected) : D.backbone.Connected := by
  obtain ⟨v⟩ := h.nonempty
  letI : Nonempty D.Kept := ⟨D.project v⟩
  exact ⟨D.preconnected h.preconnected⟩

noncomputable def splitVertex (v : V) : D.Kept ⊕ D.tips := by
  classical
  exact if h : v ∈ D.tips then .inr ⟨v, h⟩ else .inl ⟨v, h⟩

theorem splitVertex_injective : Function.Injective D.splitVertex := by
  classical
  intro u v h
  have recover (w : V) : Sum.elim Subtype.val Subtype.val (D.splitVertex w) = w := by
    simp only [splitVertex]
    split <;> rfl
  exact (recover u).symm.trans ((congrArg (Sum.elim Subtype.val Subtype.val) h).trans (recover v))

noncomputable def splitHom : G →g tipGraph D.backbone D.leftPort D.rightPort where
  toFun := D.splitVertex
  map_rel' := by
    classical
    intro u v h
    by_cases hu : u ∈ D.tips
    · have hv : v ∉ D.tips := by
        rcases (D.tip_adj ⟨u, hu⟩ v).mp h with hv | hv
        · exact hv ▸ D.left_keep ⟨u, hu⟩
        · exact hv ▸ D.right_keep ⟨u, hu⟩
      simp only [splitVertex, dif_pos hu, dif_neg hv, tipGraph]
      rcases (D.tip_adj ⟨u, hu⟩ v).mp h with hv | hv
      · exact Or.inl (Subtype.ext hv)
      · exact Or.inr (Subtype.ext hv)
    · by_cases hv : v ∈ D.tips
      · simp only [splitVertex, dif_neg hu, dif_pos hv, tipGraph]
        rcases (D.tip_adj ⟨v, hv⟩ u).mp h.symm with hu | hu
        · exact Or.inl (Subtype.ext hu)
        · exact Or.inr (Subtype.ext hu)
      · simpa only [splitVertex, dif_neg hu, dif_neg hv, tipGraph, backbone, induce_adj] using h

theorem colorable {k : Nat}
    (h : PackingColorable (tipGraph D.backbone D.leftPort D.rightPort) k) :
    PackingColorable G k := h.pullback D.splitHom D.splitVertex_injective

/-- Each degree-three vertex loses a neighbor, so the retained graph has degree at most two. -/
theorem degree_le_two [Fintype V] [DecidableRel G.Adj]
    (bound : ∀ v, G.degree v ≤ 3)
    (drop : ∀ v, G.degree v = 3 → ∃ t : D.tips, G.Adj v t.val) :
    ∀ v : D.Kept, D.backbone.degree v ≤ 2 := by
  classical
  intro v
  let ns := (D.backbone.neighborFinset v).map (Function.Embedding.subtype _)
  have sub : ns ⊆ G.neighborFinset v.val := by
    intro w hw
    obtain ⟨x, hx, rfl⟩ := Finset.mem_map.mp hw
    exact (G.mem_neighborFinset _ _).mpr ((D.backbone.mem_neighborFinset _ _).mp hx)
  have card : ns.card = D.backbone.degree v := by simp [ns]
  have le := Finset.card_le_card sub
  rw [card, G.card_neighborFinset_eq_degree] at le
  by_cases hv : G.degree v.val = 3
  · obtain ⟨t, ht⟩ := drop v.val hv
    have hn : t.val ∉ ns := by
      intro h
      obtain ⟨x, _, hx⟩ := Finset.mem_map.mp h
      change x.val = t.val at hx
      exact x.property (hx.symm ▸ t.property)
    have strict : ns ⊂ G.neighborFinset v.val := Finset.ssubset_iff_subset_ne.mpr ⟨sub, by
      intro he
      exact hn (he.symm ▸ (G.mem_neighborFinset _ _).mpr ht)⟩
    have hc := Finset.card_lt_card strict
    rw [card, G.card_neighborFinset_eq_degree, hv] at hc
    omega
  · have := bound v.val
    omega

end TipDeletionData
end Packing
