import Packing.CycleCompletion

namespace Packing
open SimpleGraph

/-- Put arbitrary disjoint marked edges on an induced cycle completion.
The two predecessor exclusions express at least two connector edges between
distinct marked edges. The graph homomorphism retains every triangle tip. -/
theorem degree_two_tipped_cycle {V T : Type*} [Fintype V]
    (H : SimpleGraph V) [DecidableRel H.Adj]
    (hd : ∀ v, H.degree v ≤ 2) (hc : H.Connected)
    (l r : T → V) (edges : ∀ t, H.Adj (l t) (r t))
    (disjoint : ∀ s t v, (v = l s ∨ v = r s) → (v = l t ∨ v = r t) → s = t)
    (noCross : ∀ s t, s ≠ t → ∀ u v,
      (u = l s ∨ u = r s) → (v = l t ∨ v = r t) → ¬ H.Adj u v) :
    ∃ (L : Nat), ∃ hL : 3 ≤ L, ∃ m : T → Fin L,
      Function.Injective m ∧
      (∀ s t, s ≠ t → m s ≠ cyclePrev (m t)) ∧
      (∀ s t, s ≠ t → m s ≠ cyclePrev (cyclePrev (m t))) ∧
      ∃ f : tipGraph H l r →g tipGraph (backboneCycle L) (cyclePrev ∘ m) m,
        Function.Injective f := by
  classical
  obtain ⟨L,hL,⟨f⟩⟩ := degree_two_induced_cycle H hd hc
  let m : T → Fin L := fun t => if f (l t) = cyclePrev (f (r t)) then f (r t) else f (l t)
  have orientation (t : T) :
      (f (l t) = cyclePrev (m t) ∧ f (r t) = m t) ∨
      (f (r t) = cyclePrev (m t) ∧ f (l t) = m t) := by
    have he := cycle_edge_orient (f.map_rel_iff.mpr (edges t))
    dsimp only [m]
    split_ifs with heq
    · exact Or.inl ⟨heq,rfl⟩
    · exact Or.inr ⟨he.resolve_left heq,rfl⟩
  have end_preimage (t : T) : ∃ v, (v = l t ∨ v = r t) ∧ f v = m t := by
    rcases orientation t with h | h
    · exact ⟨r t, Or.inr rfl, h.2⟩
    · exact ⟨l t, Or.inl rfl, h.2⟩
  have prev_preimage (t : T) : ∃ v, (v = l t ∨ v = r t) ∧ f v = cyclePrev (m t) := by
    rcases orientation t with h | h
    · exact ⟨l t, Or.inl rfl, h.1⟩
    · exact ⟨r t, Or.inr rfl, h.1⟩
  have mi : Function.Injective m := by
    intro s t he
    obtain ⟨u,hu,hum⟩ := end_preimage s
    obtain ⟨v,hv,hvm⟩ := end_preimage t
    have huv : u = v := f.injective (hum.trans (he.trans hvm.symm))
    exact disjoint s t u hu (huv.symm ▸ hv)
  have sep1 (s t : T) (hst : s ≠ t) : m s ≠ cyclePrev (m t) := by
    intro he
    obtain ⟨u,hu,hum⟩ := end_preimage s
    obtain ⟨v,hv,hvm⟩ := prev_preimage t
    have huv : u = v := f.injective (hum.trans (he.trans hvm.symm))
    exact hst (disjoint s t u hu (huv.symm ▸ hv))
  have sep2 (s t : T) (hst : s ≠ t) : m s ≠ cyclePrev (cyclePrev (m t)) := by
    intro he
    obtain ⟨u,hu,hum⟩ := end_preimage s
    obtain ⟨v,hv,hvm⟩ := prev_preimage t
    have edge : (backboneCycle L).Adj (f u) (f v) := by
      rw [hum,hvm,he]
      exact cyclePrev_adj (by omega) _
    exact noCross s t hst u v hu hv (f.map_rel_iff.mp edge)
  let F : tipGraph H l r →g tipGraph (backboneCycle L) (cyclePrev ∘ m) m := {
    toFun := Sum.map f id
    map_rel' := by
      intro x y h
      cases x with
      | inl u =>
        cases y with
        | inl v => exact f.map_rel_iff.mpr h
        | inr t =>
          change f u = cyclePrev (m t) ∨ f u = m t
          rcases h with h | h
          · rcases orientation t with he | he
            · exact Or.inl (congrArg f h |>.trans he.1)
            · exact Or.inr (congrArg f h |>.trans he.2)
          · rcases orientation t with he | he
            · exact Or.inr (congrArg f h |>.trans he.2)
            · exact Or.inl (congrArg f h |>.trans he.1)
      | inr t =>
        cases y with
        | inl v =>
          change f v = cyclePrev (m t) ∨ f v = m t
          rcases h with h | h
          · rcases orientation t with he | he
            · exact Or.inl (congrArg f h |>.trans he.1)
            · exact Or.inr (congrArg f h |>.trans he.2)
          · rcases orientation t with he | he
            · exact Or.inr (congrArg f h |>.trans he.2)
            · exact Or.inl (congrArg f h |>.trans he.1)
        | inr s => exact False.elim h
  }
  refine ⟨L,hL,m,mi,sep1,sep2,F,?_⟩
  intro x y he
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl (f.injective (Sum.inl.inj he))
    | inr t =>
      change (Sum.inl (f u) : Fin L ⊕ T) = Sum.inr t at he
      cases he
  | inr s =>
    cases y with
    | inl v =>
      change (Sum.inr s : Fin L ⊕ T) = Sum.inl (f v) at he
      cases he
    | inr t => exact congrArg Sum.inr (Sum.inr.inj he)

/-- Convert the two forbidden predecessor offsets into cyclic spacing. -/
theorem cyclic_spacing_of_predecessor_exclusions {T : Type*} {L : Nat}
    (hL : 3 ≤ L) (m : T → Fin L) (mi : Function.Injective m)
    (h1 : ∀ s t, s ≠ t → m s ≠ cyclePrev (m t))
    (h2 : ∀ s t, s ≠ t → m s ≠ cyclePrev (cyclePrev (m t)))
    (s t : T) (hst : s ≠ t) :
    if (m s).val < (m t).val then (m s).val + 3 ≤ (m t).val
    else (m s).val + 3 ≤ L + (m t).val := by
  have hs := (m s).isLt
  have ht := (m t).isLt
  have ne : (m s).val ≠ (m t).val := fun h => hst (mi (Fin.ext h))
  have ne1 : (m s).val ≠ (cyclePrev (m t)).val := fun h => h1 s t hst (Fin.ext h)
  have ne2 : (m s).val ≠ (cyclePrev (cyclePrev (m t))).val := fun h => h2 s t hst (Fin.ext h)
  simp only [cyclePrev] at ne1 ne2
  split_ifs at ne1 ne2 ⊢ <;> omega

end Packing
