import Packing.AutoChecks
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Fin
namespace Packing.Automaton
open Data Checks
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

theorem power_steps_checked : ∀ k : Fin 15,
    (powers[k.val]).mul B = powers[k.val + 1] := by
  intro k
  fin_cases k
  · exact power_step0
  · exact power_step1
  · exact power_step2
  · exact power_step3
  · exact power_step4
  · exact power_step5
  · exact power_step6
  · exact power_step7
  · exact power_step8
  · exact power_step9
  · exact power_step10
  · exact power_step11
  · exact power_step12
  · exact power_step13
  · exact power_step14

theorem powers_denote (n : Nat) (hn : n < 16) :
    (powers[n]).denote = B.denote.power n := by
  induction n with
  | zero =>
    change P0.denote = Rel.ident
    rw [initial_checked, BitMatrix.ident_spec]
  | succ n ih =>
    have hn' : n < 16 := by omega
    have hs := power_steps_checked ⟨n, by omega⟩
    have hd := congrArg BitMatrix.denote hs
    rw [BitMatrix.mul_spec] at hd
    rw [← hd, ih hn']
    rfl

theorem stabilization : B.denote.power 14 = B.denote.power 15 := by
  rw [← powers_denote 14 (by decide), ← powers_denote 15 (by decide)]
  exact congrArg BitMatrix.denote stabilization_checked

theorem all_large_powers (n : Nat) (hn : 14 ≤ n) :
    B.denote.power n = B.denote.power 14 :=
  Rel.power_stable_of_le B.denote 14 n stabilization hn

theorem gaps_checked : ∀ g : Fin 14,
    (((powers[g.val + 1]).mul A).mul A).restrict boundaryMap = gaps[g.val] := by
  intro g
  fin_cases g
  · exact gap_check0
  · exact gap_check1
  · exact gap_check2
  · exact gap_check3
  · exact gap_check4
  · exact gap_check5
  · exact gap_check6
  · exact gap_check7
  · exact gap_check8
  · exact gap_check9
  · exact gap_check10
  · exact gap_check11
  · exact gap_check12
  · exact gap_check13

theorem gap_spec (g : Fin 14) : gap (g.val + 2) = (gaps[g.val]).denote := by
  have h := congrArg BitMatrix.denote (gaps_checked g)
  rw [BitMatrix.restrict_spec, BitMatrix.mul_spec, BitMatrix.mul_spec,
    powers_denote (g.val + 1) (by omega)] at h
  unfold gap
  rw [show g.val + 2 - 1 = g.val + 1 by omega]
  exact h

theorem gap_stable (g : Nat) (hg : 15 ≤ g) : gap g = gap 15 := by
  unfold gap
  rw [all_large_powers (g-1) (by omega)]

theorem gap_clamp (g : Nat) : gap g = gap (min g 15) := by
  by_cases h : g ≤ 15
  · rw [Nat.min_eq_left h]
  · rw [Nat.min_eq_right (by omega)]
    exact gap_stable g (by omega)

#print axioms stabilization
#print axioms gap_spec
end Packing.Automaton
