import Packing.HistoryDefs
namespace Packing.History

/-- After d shifts, surviving coordinates still name the same colors. -/
theorem history_shift (s : Nat → Word) (steps : ∀ n, Step (s n) (s (n+1)))
    (n d i : Nat) (hi : i + d < 5) :
    (s (n+d))[i] = (s n)[i+d] := by
  induction d generalizing i with
  | zero => simp
  | succ d ih =>
    have hshift := (steps (n+d)).1 (⟨i, by omega⟩ : Fin 4)
    have hold := ih (i+1) (by omega)
    have e : i + 1 + d = i + (d+1) := by omega
    simpa only [Nat.add_assoc, e] using hshift.trans hold

/-- Every infinite run of the history automaton is a packing coloring of the
one-sided infinite path. This includes the distance-five boundary case. -/
theorem path_separation (s : Nat → Word) (steps : ∀ n, Step (s n) (s (n+1)))
    (n d : Nat) (hd : 0 < d) (same : (s n)[4] = (s (n+d))[4]) :
    (s n)[4] < d := by
  by_cases hsmall : d ≤ 5
  · have hi : 5 - d + (d-1) < 5 := by omega
    have hs := history_shift s steps n (d-1) (5-d) hi
    have e : 5 - d + (d-1) = 4 := by omega
    have en : n + (d-1) + 1 = n+d := by omega
    have hv : (s (n + (d-1)))[5-d] = (s (n+d))[4] := by
      simpa only [e] using hs.trans (by simpa only [e] using same)
    have hc := (steps (n+(d-1))).2.2 (⟨5-d, by omega⟩ : Fin 5)
    rw [en] at hc
    have hbound := hc hv
    have he : 5 - (5-d) = d := by omega
    simpa only [he, ← same] using hbound
  · have h := (steps n).2.1.2
    have hn := (steps n).2.1.1
    -- Obtain the palette bound at n from the equal later position.
    have hlast := (steps (n+d-1)).2.1.2
    have he : n+d-1+1 = n+d := by omega
    rw [he, ← same] at hlast
    omega

/-- Length of the forward arc between distinct positions on a cycle. -/
def arcLength (L a b : Nat) : Nat := if a < b then b-a else L+b-a

/-- Periodicity exposes conflicts across the cut as ordinary path conflicts. -/
theorem periodic_arc_separation (s : Nat → Word)
    (steps : ∀ n, Step (s n) (s (n+1))) (L : Nat)
    (periodic : ∀ n, s (n+L) = s n) (a b : Fin L)
    (hne : a ≠ b) (same : (s a.val)[4] = (s b.val)[4]) :
    (s a.val)[4] < arcLength L a.val b.val := by
  have ha := a.isLt
  have hb := b.isLt
  have hn : a.val ≠ b.val := fun h => hne (Fin.ext h)
  unfold arcLength
  split
  · rename_i hab
    have he : a.val + (b.val-a.val) = b.val := by omega
    exact path_separation s steps a.val (b.val-a.val) (by omega)
      (by simpa only [he] using same)
  · rename_i hab
    have he : a.val + (L+b.val-a.val) = b.val+L := by omega
    have hc : (s a.val)[4] = (s (a.val + (L+b.val-a.val)))[4] := by
      rw [he, periodic b.val]
      exact same
    exact path_separation s steps a.val (L+b.val-a.val) (by omega) hc

/-- Both directions around the cycle satisfy the packing constraint. -/
theorem periodic_two_arc_separation (s : Nat → Word)
    (steps : ∀ n, Step (s n) (s (n+1))) (L : Nat)
    (periodic : ∀ n, s (n+L) = s n) (a b : Fin L)
    (hne : a ≠ b) (same : (s a.val)[4] = (s b.val)[4]) :
    (s a.val)[4] < min (arcLength L a.val b.val) (arcLength L b.val a.val) := by
  have hf := periodic_arc_separation s steps L periodic a b hne same
  have hr := periodic_arc_separation s steps L periodic b a (Ne.symm hne) same.symm
  rw [← same] at hr
  omega

end Packing.History
