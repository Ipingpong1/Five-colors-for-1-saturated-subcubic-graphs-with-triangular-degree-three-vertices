import Packing.Sharpness
import Packing.SharpnessClass

namespace Packing.SmallGraphs.SharpnessExample

/-- Five colors are sufficient, and every smaller palette is impossible. -/
theorem exactly_five : PackingColorable graph 5 ∧
    ∀ k : Nat, k < 5 → ¬ PackingColorable graph k := by
  refine ⟨colorable, ?_⟩
  intro k hk hc
  exact not_four_colorable (hc.palette_mono (by omega))

/-- A member of the precise target class attains the proposed upper bound. -/
theorem sharp_example : ∃ G : SimpleGraph (Fin 12),
    (∃ inst : DecidableRel G.Adj, @TargetClass _ _ G inst) ∧
    PackingColorable G 5 ∧ ¬ PackingColorable G 4 := by
  exact ⟨graph, ⟨inferInstance, in_target_class⟩, colorable, not_four_colorable⟩

#print axioms exactly_five
end Packing.SmallGraphs.SharpnessExample
