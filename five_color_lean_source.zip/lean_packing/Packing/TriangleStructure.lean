import Packing.TriangleLemmas
import Packing.SmallGraphs
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

namespace Packing
open SimpleGraph

/-- Two known distinct neighbors exhaust a degree-at-most-two neighborhood. -/
theorem neighbors_eq_pair {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj]
    (x a b : V) (hx : G.degree x ≤ 2)
    (ha : G.Adj x a) (hb : G.Adj x b) (hab : a ≠ b) :
    ∀ y, G.Adj x y ↔ y = a ∨ y = b := by
  classical
  have hs : ({a,b} : Finset V) ⊆ G.neighborFinset x := by
    intro y hy
    simp only [Finset.mem_insert, Finset.mem_singleton] at hy
    rcases hy with rfl | rfl
    · exact (G.mem_neighborFinset x _).mpr ha
    · exact (G.mem_neighborFinset x _).mpr hb
  have he : ({a,b} : Finset V) = G.neighborFinset x := by
    apply Finset.eq_of_subset_of_card_le hs
    simpa only [Finset.card_pair hab, G.card_neighborFinset_eq_degree] using hx
  intro y
  rw [← G.mem_neighborFinset, ← he]
  simp only [Finset.mem_insert, Finset.mem_singleton]

/-- Three known distinct neighbors exhaust a subcubic neighborhood. -/
theorem neighbors_eq_triple {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj]
    (x a b c : V) (hx : G.degree x ≤ 3)
    (ha : G.Adj x a) (hb : G.Adj x b) (hc : G.Adj x c)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    ∀ y, G.Adj x y ↔ y = a ∨ y = b ∨ y = c := by
  classical
  have hs : ({a,b,c} : Finset V) ⊆ G.neighborFinset x := by
    intro y hy
    simp only [Finset.mem_insert, Finset.mem_singleton] at hy
    rcases hy with rfl | rfl | rfl
    · exact (G.mem_neighborFinset x _).mpr ha
    · exact (G.mem_neighborFinset x _).mpr hb
    · exact (G.mem_neighborFinset x _).mpr hc
  have he : ({a,b,c} : Finset V) = G.neighborFinset x := by
    apply Finset.eq_of_subset_of_card_le hs
    have hcard : ({a,b,c} : Finset V).card = 3 :=
      Finset.card_triple_eq_three_iff.mpr ⟨hab,hac,hbc⟩
    simpa only [hcard, G.card_neighborFinset_eq_degree] using hx
  intro y
  rw [← G.mem_neighborFinset, ← he]
  simp only [Finset.mem_insert, Finset.mem_singleton]

/-- A set closed under taking neighbors contains every vertex reachable
from one of its vertices. -/
theorem walk_closed_set {V : Type*} (G : SimpleGraph V) (s : Set V)
    (closed : ∀ x ∈ s, ∀ y, G.Adj x y → y ∈ s)
    {x y : V} (p : G.Walk x y) (hx : x ∈ s) : y ∈ s := by
  induction p with
  | nil => exact hx
  | @cons x y z hxy p ih => exact ih (closed x hx y hxy)

/-- In the shared-edge case the four diamond vertices have no outside
neighbors; this gives the full component assertion, not just its degrees. -/
theorem shared_edge_component {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (u v a b : V) (huv : G.Adj u v) (hua : G.Adj u a) (hub : G.Adj u b)
    (hva : G.Adj v a) (hvb : G.Adj v b) (hab : a ≠ b) :
    ∀ x, G.Reachable u x → x = u ∨ x = v ∨ x = a ∨ x = b := by
  obtain ⟨hu,hv,ha,hb⟩ := shared_edge_degrees G hG u v a b huv hua hub hva hvb hab
  have nu := neighbors_eq_triple G u v a b (hG.1 u) huv hua hub hva.ne hvb.ne hab
  have nv := neighbors_eq_triple G v u a b (hG.1 v) huv.symm hva hvb hua.ne hub.ne hab
  have na := neighbors_eq_pair G a u v (by omega) hua.symm hva.symm huv.ne
  have nb := neighbors_eq_pair G b u v (by omega) hub.symm hvb.symm huv.ne
  intro x ⟨p⟩
  exact walk_closed_set G {x | x = u ∨ x = v ∨ x = a ∨ x = b} (by
    intro x hx y hxy
    rcases hx with rfl | rfl | rfl | rfl
    · rcases (nu y).mp hxy with h | h | h
      · exact Or.inr (Or.inl h)
      · exact Or.inr (Or.inr (Or.inl h))
      · exact Or.inr (Or.inr (Or.inr h))
    · rcases (nv y).mp hxy with h | h | h
      · exact Or.inl h
      · exact Or.inr (Or.inr (Or.inl h))
      · exact Or.inr (Or.inr (Or.inr h))
    · rcases (na y).mp hxy with h | h
      · exact Or.inl h
      · exact Or.inr (Or.inl h)
    · rcases (nb y).mp hxy with h | h
      · exact Or.inl h
      · exact Or.inr (Or.inl h)) p (Or.inl rfl)

/-- In the absence of a diamond, triangles meeting at a vertex have the
same other two vertices. Subcubicity rules out meeting only at one vertex. -/
theorem triangle_overlap_pair {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (hdiamond : ∀ u v a b, G.Adj u v → G.Adj u a → G.Adj u b →
      G.Adj v a → G.Adj v b → a = b)
    (a b c d e : V)
    (hab : G.Adj a b) (hbc : G.Adj b c) (hca : G.Adj c a)
    (had : G.Adj a d) (hde : G.Adj d e) (hea : G.Adj e a) :
    (b = d ∧ c = e) ∨ (b = e ∧ c = d) := by
  by_cases hbd : b = d
  · subst d
    exact Or.inl ⟨rfl, hdiamond a b c e hab hca.symm hea.symm hbc hde⟩
  by_cases hbe : b = e
  · subst e
    exact Or.inr ⟨rfl, hdiamond a b c d hab hca.symm had hbc hde.symm⟩
  by_cases hcd : c = d
  · subst d
    exact Or.inr ⟨hdiamond a c b e hca.symm hab hea.symm hbc.symm hde, rfl⟩
  by_cases hce : c = e
  · subst e
    exact Or.inl ⟨hdiamond a c b d hca.symm hab had hbc.symm hde.symm, rfl⟩
  have he := (neighbors_eq_triple G a b c d (hG.1 a) hab hca.symm had
    hbc.ne hbd hcd e).mp hea.symm
  rcases he with he | he | he
  · exact (hbe he.symm).elim
  · exact (hce he.symm).elim
  · exact (hde.ne he.symm).elim

/-- A connected target-class graph containing a shared-edge pair of
triangles is a diamond, hence has a packing coloring with four colors. -/
theorem connected_shared_edge_colorable {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (hc : G.Connected)
    (u v a b : V) (huv : G.Adj u v) (hua : G.Adj u a) (hub : G.Adj u b)
    (hva : G.Adj v a) (hvb : G.Adj v b) (hab : a ≠ b) :
    PackingColorable G 4 := by
  classical
  have total : ∀ x, x = u ∨ x = v ∨ x = a ∨ x = b :=
    fun x => shared_edge_component G hG u v a b huv hua hub hva hvb hab x (hc u x)
  have huvn := huv.ne
  have huan := hua.ne
  have hubn := hub.ne
  have hvan := hva.ne
  have hvbn := hvb.ne
  have degrees := shared_edge_degrees G hG u v a b huv hua hub hva hvb hab
  have hnab : ¬G.Adj a b := by
    intro h
    have hm := (neighbors_eq_pair G a u v (by omega) hua.symm hva.symm huv.ne b).mp h
    rcases hm with h | h
    · exact hub.ne h.symm
    · exact hvb.ne h.symm
  have hnba : ¬G.Adj b a := fun h => hnab h.symm
  let f : V → Fin 4 := fun x => if x = u then 0 else if x = v then 1 else if x = a then 2 else 3
  have fu : f u = 0 := by simp [f]
  have fv : f v = 1 := by simp [f, huvn.symm]
  have fa : f a = 2 := by simp [f, huan.symm, hvan.symm]
  have fb : f b = 3 := by simp [f, hubn.symm, hvbn.symm, hab.symm]
  have hinj : Function.Injective f := by
    intro x y h
    rcases total x with hx | hx | hx | hx <;>
      rcases total y with hy | hy | hy | hy <;>
      simp_all
  let hom : G →g SmallGraphs.Diamond.graph := {
    toFun := f
    map_rel' := by
      intro x y hxy
      rcases total x with hx | hx | hx | hx <;>
        rcases total y with hy | hy | hy | hy <;>
        simp_all [SmallGraphs.Diamond.graph, SimpleGraph.fromRel, SmallGraphs.Diamond.edges]
  }
  exact SmallGraphs.Diamond.colorable.pullback hom hinj

end Packing
