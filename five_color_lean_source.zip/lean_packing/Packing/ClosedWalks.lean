import Packing.Universal
import Packing.History
import Packing.PathSemantics
import Packing.Traces
import Packing.Cycles

namespace Packing

/-- Each actual gap relation supplies exactly g+1 history transitions. -/
theorem gap_trace (g : Universal.Gap) (i j : Fin 171)
    (h : Universal.R g i j) :
    Trace Data.B.denote (g.val + 1) (Automaton.boundaryMap i) (Automaton.boundaryMap j) := by
  rcases h with ⟨u, ⟨v, hv, hA⟩, hu⟩
  have hB := (power_iff_trace Data.B.denote (g.val-1) _ _).mp hv
  have sub := BitMatrix.subCheck_sound Data.A Data.B History.restricted_steps_subset
  have tr := Trace.snoc (Trace.snoc hB (sub _ _ hA)) (sub _ _ hu)
  have he : g.val - 1 + 1 + 1 = g.val + 1 := by have := g.property; omega
  simpa only [he] using tr

/-- Every admissible gap sequence with at least two gaps has a closed history
walk of exactly the backbone length. No graph-order cutoff occurs here. -/
theorem closed_history_walk (g h : Universal.Gap) (tail : List Universal.Gap) :
    ∃ start : Fin 390,
      Trace Data.B.denote (((g :: h :: tail).map (fun x => x.val + 1)).sum) start start := by
  obtain ⟨i, hi⟩ := Universal.arbitrary_gap_sequence g h tail
  exact ⟨Automaton.boundaryMap i,
    trace_product Data.B.denote Universal.R Automaton.boundaryMap
      (fun x => x.val + 1) gap_trace (g :: h :: tail) i i hi⟩

theorem closed_history_walk_singleton (g : Universal.Gap) (hg : 5 ≤ g.val) :
    ∃ start : Fin 390, Trace Data.B.denote (g.val + 1) start start := by
  obtain ⟨i, hi⟩ := Universal.long_single_gap g hg
  have hh : Universal.R g i i := by
    simpa only [product, extend, Rel.ident_comp] using hi
  exact ⟨Automaton.boundaryMap i, gap_trace g i i hh⟩

/-- The emitted colors of every concrete automaton run obey packing separation. -/
theorem concrete_path_separation (run : Nat → Fin 390)
    (edges : ∀ n, Data.B.denote (run n) (run (n+1)))
    (n d : Nat) (hd : 0 < d)
    (same : Data.histories[(run n).val][4] = Data.histories[(run (n+d)).val][4]) :
    Data.histories[(run n).val][4] < d :=
  History.path_separation (fun k => Data.histories[(run k).val])
    (fun k => History.ordinary_steps_sound _ _ (edges k)) n d hd same

#print axioms closed_history_walk
#print axioms concrete_path_separation
end Packing

namespace Packing
/-- The concrete closed history walk produces a packing coloring of the
unmarked cycle. The separate marked-port bookkeeping is not asserted here. -/
theorem closed_history_cycle_colorable {L : Nat} {a : Fin 390}
    (p : Trace Data.B.denote L a a) (hL : 0 < L) :
    PackingColorable (backboneCycle L) 5 := by
  obtain ⟨run, _, edges, periodic⟩ := p.periodic_run hL
  let s : Nat → History.Word := fun k => Data.histories[(run k).val]
  apply periodic_history_cycle_colorable s
    (fun k => History.ordinary_steps_sound _ _ (edges k)) L
  · intro k
    simp only [s, periodic k]
  · intro k
    exact (History.histories_admissible (run k)).1 ⟨4, by decide⟩

#print axioms closed_history_cycle_colorable
end Packing
