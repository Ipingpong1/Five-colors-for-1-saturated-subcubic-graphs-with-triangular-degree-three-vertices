import Packing.DegreeTwo
import Packing.MarkedCycles

namespace Packing
open SimpleGraph

/-- Completing a path with two fresh vertices creates no new edge between
old vertices. A genuine cycle is retained unchanged. -/
theorem degree_two_induced_cycle {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2) (hc : G.Connected) :
    ∃ L, 3 ≤ L ∧ Nonempty (G ↪g backboneCycle L) := by
  classical
  obtain ⟨n, hn, e, hstep, hedge⟩ := degree_two_vertex_order G hd hc
  let first : Fin n := ⟨0, hn⟩
  let last : Fin n := ⟨n-1, by omega⟩
  by_cases hclosed : 3 ≤ n ∧ G.Adj (e last) (e first)
  · have reflect (i j : Fin n) (h : (backboneCycle n).Adj i j) : G.Adj (e i) (e j) := by
      change i ≠ j ∧ ((i.val+1=j.val ∨ (i.val+1=n ∧ j.val=0)) ∨
        (j.val+1=i.val ∨ (j.val+1=n ∧ i.val=0))) at h
      rcases h.2 with (h | ⟨hi,hj⟩) | (h | ⟨hj,hi⟩)
      · exact hstep i j h
      · have hi' : i = last := Fin.ext (by dsimp [last]; omega)
        have hj' : j = first := Fin.ext hj
        simpa only [hi', hj'] using hclosed.2
      · exact (hstep j i h).symm
      · have hj' : j = last := Fin.ext (by dsimp [last]; omega)
        have hi' : i = first := Fin.ext hi
        simpa only [hi', hj'] using hclosed.2.symm
    refine ⟨n, hclosed.1, ⟨{ toFun := e.symm, inj' := e.symm.injective, map_rel_iff' := ?_ }⟩⟩
    intro u v
    constructor
    · intro h
      simpa only [Equiv.apply_symm_apply] using reflect (e.symm u) (e.symm v) h
    · intro h
      change (backboneCycle n).Adj (e.symm u) (e.symm v)
      apply hedge
      simpa only [Equiv.apply_symm_apply] using h
  · have line_edges (i j : Fin n) (h : G.Adj (e i) (e j)) :
        i.val+1=j.val ∨ j.val+1=i.val := by
      have hc := hedge i j h
      have hi := i.isLt
      have hj := j.isLt
      change i ≠ j ∧ ((i.val+1=j.val ∨ (i.val+1=n ∧ j.val=0)) ∨
        (j.val+1=i.val ∨ (j.val+1=n ∧ i.val=0))) at hc
      rcases hc.2 with (hh | ⟨hi',hj'⟩) | (hh | ⟨hj',hi'⟩)
      · exact Or.inl hh
      · by_cases hn3 : 3 ≤ n
        · have ie : i = last := Fin.ext (by dsimp [last]; omega)
          have je : j = first := Fin.ext hj'
          exact (hclosed ⟨hn3, by simpa only [ie,je] using h⟩).elim
        · have hn1 : 1 < n := by
            by_contra hnot
            have he : i = j := Fin.ext (by omega)
            exact hc.1 he
          omega
      · exact Or.inr hh
      · by_cases hn3 : 3 ≤ n
        · have je : j = last := Fin.ext (by dsimp [last]; omega)
          have ie : i = first := Fin.ext hi'
          exact (hclosed ⟨hn3, by simpa only [ie,je] using h.symm⟩).elim
        · have hn1 : 1 < n := by
            by_contra hnot
            have he : i = j := Fin.ext (by omega)
            exact hc.1 he
          omega
    let f : V → Fin (n+2) := fun v => ⟨(e.symm v).val+1, by have := (e.symm v).isLt; omega⟩
    have fi : Function.Injective f := by
      intro u v huv
      apply e.symm.injective
      apply Fin.ext
      have := congrArg Fin.val huv
      dsimp [f] at this
      omega
    refine ⟨n+2, by omega, ⟨{ toFun := f, inj' := fi, map_rel_iff' := ?_ }⟩⟩
    intro u v
    constructor
    · intro h
      change f u ≠ f v ∧ (((e.symm u).val+1+1=(e.symm v).val+1 ∨
        ((e.symm u).val+1+1=n+2 ∧ (e.symm v).val+1=0)) ∨
        ((e.symm v).val+1+1=(e.symm u).val+1 ∨
        ((e.symm v).val+1+1=n+2 ∧ (e.symm u).val+1=0))) at h
      have he : (e.symm u).val+1=(e.symm v).val ∨ (e.symm v).val+1=(e.symm u).val := by omega
      rcases he with he | he
      · simpa only [Equiv.apply_symm_apply] using hstep (e.symm u) (e.symm v) he
      · simpa only [Equiv.apply_symm_apply] using (hstep (e.symm v) (e.symm u) he).symm
    · intro h
      have he := line_edges (e.symm u) (e.symm v) (by simpa only [Equiv.apply_symm_apply] using h)
      change f u ≠ f v ∧ _
      refine ⟨fun he => h.ne (fi he), ?_⟩
      rcases he with he | he
      · exact Or.inl (Or.inl (by dsimp [f]; omega))
      · exact Or.inr (Or.inl (by dsimp [f]; omega))

/-- An oriented cycle edge ends either at its first argument or its second. -/
theorem cycle_edge_orient {L : Nat} {u v : Fin L} (h : (backboneCycle L).Adj u v) :
    u = cyclePrev v ∨ v = cyclePrev u := by
  have hu := u.isLt
  have hv := v.isLt
  change u ≠ v ∧ ((u.val+1=v.val ∨ (u.val+1=L ∧ v.val=0)) ∨
    (v.val+1=u.val ∨ (v.val+1=L ∧ u.val=0))) at h
  rcases h.2 with (h | ⟨h,hz⟩) | (h | ⟨h,hz⟩)
  · left; apply Fin.ext; simp only [cyclePrev]; split_ifs <;> omega
  · left; apply Fin.ext; simp only [cyclePrev, hz, ↓reduceIte]; omega
  · right; apply Fin.ext; simp only [cyclePrev]; split_ifs <;> omega
  · right; apply Fin.ext; simp only [cyclePrev, hz, ↓reduceIte]; omega

end Packing
