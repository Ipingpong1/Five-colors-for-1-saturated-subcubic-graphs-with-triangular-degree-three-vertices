import Packing.TipCycleMaps
import Packing.MarkedCycleReduction

namespace Packing
open SimpleGraph

/-- A connected maximum-degree-two backbone with disjoint triangle edges and
no direct edge between different triangle ports has a five-color packing
coloring after all the triangle tips are restored. -/
theorem degree_two_tipped_colorable {V T : Type*} [Fintype V] [Fintype T]
    (H : SimpleGraph V) [DecidableRel H.Adj]
    (hd : ∀ v, H.degree v ≤ 2) (hc : H.Connected)
    (l r : T → V) (edges : ∀ t, H.Adj (l t) (r t))
    (disjoint : ∀ s t v, (v = l s ∨ v = r s) → (v = l t ∨ v = r t) → s = t)
    (noCross : ∀ s t, s ≠ t → ∀ u v,
      (u = l s ∨ u = r s) → (v = l t ∨ v = r t) → ¬ H.Adj u v) :
    PackingColorable (tipGraph H l r) 5 := by
  obtain ⟨L,hL,m,mi,h1,h2,f,fi⟩ := degree_two_tipped_cycle H hd hc l r edges disjoint noCross
  have separated : SeparatedMarks L m :=
    cyclic_spacing_of_predecessor_exclusions hL m mi h1 h2
  exact (markedCycle_colorable L hL m mi separated).pullback f fi

end Packing
