import Packing.ClosedWalks
import Packing.NecklaceDefs
import Packing.SingleNecklaces

namespace Packing

theorem necklace_of_closed_gap_word (gs : List Universal.Gap)
    (hL : 2 ≤ backboneLength (gs.map (fun g => g.val)))
    (hd : (product Universal.R gs).Diagonal) :
    PackingColorable (necklace (gs.map (fun g => g.val)) (by omega)) 5 := by
  obtain ⟨i, hi⟩ := hd
  have p := segmented_product Data.B.denote boundaryGood Universal.R
    Automaton.boundaryMap (fun g : Universal.Gap => g.val+1)
    gap_trace boundaryGood_map gs i i hi
  apply necklace_colorable_of_segmented (gs.map (fun g => g.val)) hL (Automaton.boundaryMap i)
  simpa only [List.map_map, Function.comp_def] using p

/-- Every necklace with at least two triangles and connector gaps at least
2 has a packing coloring with at most five colors. There is no size bound. -/
theorem necklace_two_or_more_colorable (g h : Universal.Gap) (tail : List Universal.Gap) :
    PackingColorable
      (necklace ((g::h::tail).map (fun x => x.val)) (by
        simp only [backboneLength, List.map_cons, List.sum_cons]
        have := g.property
        have := h.property
        omega)) 5 := by
  have hL : 2 ≤ backboneLength ((g::h::tail).map (fun x => x.val)) := by
    simp only [backboneLength, List.map_cons, List.sum_cons]
    have := g.property
    have := h.property
    omega
  exact necklace_of_closed_gap_word (g::h::tail) hL
    (Universal.arbitrary_gap_sequence g h tail)

/-- The long one-triangle necklaces. The three shorter cases are kept separate. -/
theorem necklace_long_singleton_colorable (g : Universal.Gap) (hg : 5 ≤ g.val) :
    PackingColorable (necklace [g.val] (by simp [backboneLength])) 5 := by
  have hL : 2 ≤ backboneLength [g.val] := by simp [backboneLength]; omega
  exact necklace_of_closed_gap_word [g] hL (Universal.long_single_gap g hg)

#print axioms necklace_two_or_more_colorable
#print axioms necklace_long_singleton_colorable

theorem necklace_singleton_colorable (g : Universal.Gap) :
    PackingColorable (necklace [g.val] (by simp [backboneLength])) 5 := by
  by_cases hg : 5 ≤ g.val
  · exact necklace_long_singleton_colorable g hg
  · rcases g with ⟨n, hn⟩
    have hs : n = 2 ∨ n = 3 ∨ n = 4 := by simp only at hg; omega
    rcases hs with rfl | rfl | rfl
    · exact SingleGap2.colorable.palette_mono (by decide)
    · exact SingleGap3.colorable.palette_mono (by decide)
    · exact SingleGap4.colorable.palette_mono (by decide)

/-- The full necklace-family theorem: every nonempty sequence of connector
gaps at least two yields a graph with a packing coloring using at most five colors. -/
theorem necklace_colorable (g : Universal.Gap) (tail : List Universal.Gap) :
    PackingColorable
      (necklace ((g::tail).map (fun x => x.val)) (by
        simp only [backboneLength, List.map_cons, List.sum_cons]
        have := g.property
        omega)) 5 := by
  cases tail with
  | nil => exact necklace_singleton_colorable g
  | cons h tail => exact necklace_two_or_more_colorable g h tail

#print axioms necklace_colorable
end Packing
