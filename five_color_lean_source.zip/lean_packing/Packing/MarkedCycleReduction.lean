import Packing.DegreeTwo
import Packing.NecklaceTheorem
import Mathlib.Data.Finset.Sort

namespace Packing
open SimpleGraph

/-- Distinct colors suffice for a graph with at most `k` vertices. -/
theorem fin_graph_colorable_of_le {n k : Nat} (G : SimpleGraph (Fin n)) (hn : n ≤ k) :
    PackingColorable G k := by
  refine ⟨fun v => v.val+1, fun v => ⟨by dsimp; omega, by dsimp; have := v.isLt; omega⟩, ?_⟩
  intro u v huv heq p
  dsimp at heq
  exact False.elim (huv (Fin.ext (by omega)))

/-- Every cycle, including the degenerate one- and two-vertex cases, is five-colorable. -/
theorem backboneCycle_colorable (n : Nat) : PackingColorable (backboneCycle n) 5 := by
  by_cases hn : n ≤ 5
  · exact fin_graph_colorable_of_le _ hn
  · have hgap : 2 ≤ n-1 := by omega
    have hlen : backboneLength [n-1] = n := by simp [backboneLength]; omega
    have hc := necklace_singleton_colorable ⟨n-1,hgap⟩
    let hpos : 0 < backboneLength [n-1] := by omega
    let f : backboneCycle (backboneLength [n-1]) →g necklace [n-1] hpos :=
      { toFun := Sum.inl
        map_rel' := by intro u v huv; exact huv }
    have hf : Function.Injective f := Sum.inl_injective
    have hh := hc.pullback f hf
    rwa [hlen] at hh

/-- The complete connected maximum-degree-two case of the target theorem. -/
theorem degree_two_colorable {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2) (hconn : G.Connected) :
    PackingColorable G 5 := by
  obtain ⟨n,hn,f,hf⟩ := degree_two_cycle_embedding G hd hconn
  exact (backboneCycle_colorable n).pullback f hf.1

/-- Segment lengths obtained by cutting the interval at the listed coordinates. -/
def cutLengths (a : Nat) : List Nat → Nat → List Nat
  | [], L => [L-a]
  | x::xs, L => (x-a)::cutLengths x xs L

def validCuts (a : Nat) : List Nat → Nat → Prop
  | [], L => a+3 ≤ L
  | x::xs, L => a+3 ≤ x ∧ validCuts x xs L

theorem validCuts_bound {a L : Nat} {xs : List Nat} (h : validCuts a xs L) : a+3 ≤ L := by
  induction xs generalizing a with
  | nil => exact h
  | cons x xs ih =>
    obtain ⟨ha,hx⟩ := h
    have := ih hx
    omega

theorem cutLengths_nonempty (a L : Nat) (xs : List Nat) : cutLengths a xs L ≠ [] := by
  cases xs <;> simp [cutLengths]

theorem cutLengths_large {a L : Nat} {xs : List Nat} (h : validCuts a xs L) :
    ∀ n ∈ cutLengths a xs L, 3 ≤ n := by
  induction xs generalizing a with
  | nil => simpa only [cutLengths, List.mem_singleton] using fun n (hn : n=L-a) =>
      (show 3 ≤ n by have : a+3 ≤ L := h; omega)
  | cons x xs ih =>
    obtain ⟨ha,hx⟩ := h
    intro n hn
    simp only [cutLengths, List.mem_cons] at hn
    rcases hn with rfl | hn
    · omega
    · exact ih hx n hn

theorem cutLengths_sum {a L : Nat} {xs : List Nat} (h : validCuts a xs L) :
    (cutLengths a xs L).sum = L-a := by
  induction xs generalizing a with
  | nil => simp [cutLengths]
  | cons x xs ih =>
    obtain ⟨ha,hx⟩ := h
    have hb := validCuts_bound hx
    simp only [cutLengths, List.sum_cons, ih hx]
    omega

theorem cutLengths_ends {a L : Nat} {xs : List Nat} (h : validCuts a xs L) :
    segmentEnds (cutLengths a xs L) = xs.map (·-a) ++ [L-a] := by
  induction xs generalizing a with
  | nil => simp [cutLengths,segmentEnds]
  | cons x xs ih =>
    obtain ⟨ha,hx⟩ := h
    have hb := validCuts_bound hx
    simp only [cutLengths,segmentEnds,ih hx,List.map_append,List.map_cons,List.map_nil,
      List.map_map,List.cons_append]
    congr 1
    apply congrArg₂ List.append
    · apply List.map_congr_left
      intro y hy
      have hey : y-x ≤ L-x := by
        have hmem : y-x ∈ segmentEnds (cutLengths x xs L) := by
          rw [ih hx]
          exact List.mem_append_left _ (List.mem_map.mpr ⟨y,hy,rfl⟩)
        simpa only [cutLengths_sum hx] using segmentEnds_le_sum _ _ hmem
      have hxy : x ≤ y := by
        clear hey
        have aux : ∀ {a xs}, validCuts a xs L → ∀ y ∈ xs, a+3 ≤ y := by
          intro a xs h
          induction xs generalizing a with
          | nil => simp
          | cons z zs ih =>
            intro y hy
            rcases h with ⟨haz,hzs⟩
            rcases List.mem_cons.mp hy with rfl | hy
            · exact haz
            · have := ih hzs y hy; omega
        have := aux hx y hy
        omega
      dsimp
      omega
    · congr 1
      omega

theorem validCuts_of_pairwise {a L : Nat} {xs : List Nat}
    (hp : xs.Pairwise (fun x y => x+3 ≤ y))
    (ha : ∀ x ∈ xs, a+3 ≤ x) (hL : ∀ x ∈ xs, x+3 ≤ L) (haL : a+3 ≤ L) :
    validCuts a xs L := by
  induction xs generalizing a with
  | nil => exact haL
  | cons x xs ih =>
    simp only [List.pairwise_cons] at hp
    exact ⟨ha x (by simp), ih hp.2 hp.1
      (fun y hy => hL y (by simp [hy])) (hL x (by simp))⟩

/-- Natural-valued necklace lists can be passed to the previously checked theorem. -/
theorem necklace_nat_colorable (gs : List Nat) (hne : gs ≠ [])
    (hg : ∀ g ∈ gs, 2 ≤ g) (hpos : 0 < backboneLength gs) :
    PackingColorable (necklace gs hpos) 5 := by
  have lift : ∀ xs : List Nat, (∀ x ∈ xs, 2 ≤ x) →
      ∃ ys : List Universal.Gap, ys.map (fun g => g.val) = xs := by
    intro xs hx
    induction xs with
    | nil => exact ⟨[],rfl⟩
    | cons x xs ih =>
      obtain ⟨ys,hys⟩ := ih (fun y hy => hx y (by simp [hy]))
      exact ⟨⟨x,hx x (by simp)⟩::ys,by simp [hys]⟩
  obtain ⟨ys,hys⟩ := lift gs hg
  cases ys with
  | nil => exact False.elim (hne (by simpa using hys.symm))
  | cons y ys =>
    have hh := necklace_colorable y ys
    subst gs
    exact hh

/-- Any injective subset of the marked endpoints of a necklace inherits its coloring. -/
theorem marked_colorable_of_endpoints {T : Type*} (L : Nat) (hL : 0 < L)
    (m : T → Fin L) (hm : Function.Injective m)
    (gs : List Nat) (hne : gs ≠ []) (hg : ∀ g ∈ gs, 2 ≤ g)
    (hlen : backboneLength gs = L)
    (he : ∀ t, ∃ k ∈ segmentEnds (gs.map (·+1)), k % L = (m t).val) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  classical
  subst L
  let tip : T → NecklaceTip gs := fun t =>
    ⟨(he t).choose,(he t).choose_spec.1⟩
  have htip : ∀ t, necklaceMark gs hL (tip t) = m t := by
    intro t
    apply Fin.ext
    exact (he t).choose_spec.2
  have hti : Function.Injective tip := by
    intro s t hst
    apply hm
    rw [← htip s,← htip t,hst]
  let f : tipGraph (backboneCycle (backboneLength gs)) (cyclePrev ∘ m) m →g
      necklace gs hL :=
    { toFun := Sum.map id tip
      map_rel' := by
        intro x y hxy
        cases x with
        | inl u =>
          cases y with
          | inl v => exact hxy
          | inr t =>
            change u = cyclePrev (necklaceMark gs hL (tip t)) ∨
              u = necklaceMark gs hL (tip t)
            rw [htip]
            exact hxy
        | inr s =>
          cases y with
          | inl v =>
            change v = cyclePrev (necklaceMark gs hL (tip s)) ∨
              v = necklaceMark gs hL (tip s)
            rw [htip]
            exact hxy
          | inr t => exact hxy }
  apply (necklace_nat_colorable gs hne hg hL).pullback f
  exact Sum.map_injective.mpr ⟨Function.injective_id,hti⟩

/-- A list of interval cuts separated by at least three yields a five-colorable
marked cycle whenever every mark is among those cuts or at the cyclic origin. -/
theorem marked_colorable_of_validCuts {T : Type*} (L : Nat) (m : T → Fin L)
    (hm : Function.Injective m) (xs : List Nat) (hv : validCuts 0 xs L)
    (hc : ∀ t, (m t).val = 0 ∨ (m t).val ∈ xs) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  let ns := cutLengths 0 xs L
  let gs := ns.map (·-1)
  have large : ∀ n ∈ ns, 3 ≤ n := cutLengths_large hv
  have mapgs : gs.map (·+1) = ns := by
    simp only [gs,List.map_map]
    have heq : ns.map (fun n => (n-1)+1) = ns.map id := by
      apply List.map_congr_left
      intro n hn
      have := large n hn
      dsimp
      omega
    simpa [Function.comp_def] using heq
  have hlen : backboneLength gs = L := by
    simp only [backboneLength,mapgs]
    simpa using cutLengths_sum hv
  have hL : 0 < L := by have := validCuts_bound hv; omega
  apply marked_colorable_of_endpoints L hL m hm gs
  · intro he
    have hem : ns = [] := List.map_eq_nil_iff.mp he
    exact cutLengths_nonempty 0 L xs hem
  · intro g hg
    obtain ⟨n,hn,rfl⟩ := List.mem_map.mp hg
    have := large n hn
    omega
  · exact hlen
  · intro t
    have ends : segmentEnds (gs.map (·+1)) = xs ++ [L] := by
      rw [mapgs]
      simpa using cutLengths_ends hv
    rcases hc t with ht | ht
    · exact ⟨L,by rw [ends]; simp,by simp [ht]⟩
    · exact ⟨(m t).val,by rw [ends]; simp [ht],Nat.mod_eq_of_lt (m t).isLt⟩

/-- Distinct triangle marks have cyclic forward distance at least three. -/
def SeparatedMarks {T : Type*} (L : Nat) (m : T → Fin L) : Prop :=
  ∀ s t, s ≠ t → if (m s).val < (m t).val
    then (m s).val+3 ≤ (m t).val else (m s).val+3 ≤ L+(m t).val

/-- The marked-cycle theorem when one mark is already at coordinate zero. -/
theorem markedCycle_colorable_zero {T : Type*} [Fintype T]
    (L : Nat) (hL : 3 ≤ L) (m : T → Fin L) (hm : Function.Injective m)
    (hs : SeparatedMarks L m) (z : T) (hz : (m z).val=0) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  classical
  let coords : Finset Nat := (Finset.univ.image (fun t => (m t).val)).erase 0
  let xs := coords.sort (· ≤ ·)
  have mem : ∀ x, x ∈ xs ↔ x ≠ 0 ∧ ∃ t, (m t).val=x := by
    intro x
    simp [xs,coords,Finset.mem_sort]
  have lower : ∀ x ∈ xs, 0+3 ≤ x := by
    intro x hx
    obtain ⟨hx0,t,ht⟩ := (mem x).mp hx
    have hzt : z ≠ t := by intro he; subst t; omega
    have h := hs z t hzt
    rw [hz,ht] at h
    split_ifs at h <;> omega
  have upper : ∀ x ∈ xs, x+3 ≤ L := by
    intro x hx
    obtain ⟨hx0,t,ht⟩ := (mem x).mp hx
    have htz : t ≠ z := by intro he; subst t; omega
    have h := hs t z htz
    rw [hz,ht] at h
    split_ifs at h <;> omega
  have pair : xs.Pairwise (fun x y => x+3 ≤ y) := by
    have hp : xs.Pairwise (· < ·) := coords.sortedLT_sort.pairwise
    apply hp.imp_of_mem
    intro x y hx hy hxy
    obtain ⟨_,s,hxs⟩ := (mem x).mp hx
    obtain ⟨_,t,hyt⟩ := (mem y).mp hy
    have hst : s ≠ t := by intro he; subst t; omega
    have h := hs s t hst
    rw [hxs,hyt,if_pos hxy] at h
    exact h
  apply marked_colorable_of_validCuts L m hm xs
    (validCuts_of_pairwise pair lower upper (by omega))
  intro t
  by_cases ht : (m t).val=0
  · exact Or.inl ht
  · exact Or.inr ((mem _).mpr ⟨ht,t,rfl⟩)

/-- Translate a cycle coordinate so that `r` becomes zero. -/
def cycleRotate {L : Nat} (r v : Fin L) : Fin L :=
  ⟨if r.val ≤ v.val then v.val-r.val else L+v.val-r.val, by
    have hr := r.isLt
    have hv := v.isLt
    split_ifs <;> omega⟩

theorem cycleRotate_injective {L : Nat} (r : Fin L) :
    Function.Injective (cycleRotate r) := by
  intro u v huv
  have h := congrArg Fin.val huv
  have hu := u.isLt
  have hv := v.isLt
  have hr := r.isLt
  simp only [cycleRotate] at h
  apply Fin.ext
  split_ifs at h <;> omega

@[simp] theorem cycleRotate_self {L : Nat} (r : Fin L) : (cycleRotate r r).val = 0 := by
  simp [cycleRotate]

theorem cycleRotate_prev {L : Nat} (r v : Fin L) :
    cycleRotate r (cyclePrev v) = cyclePrev (cycleRotate r v) := by
  apply Fin.ext
  have hr := r.isLt
  have hv := v.isLt
  simp only [cycleRotate,cyclePrev]
  split_ifs <;> omega

theorem cycleRotate_adj {L : Nat} (r u v : Fin L) (h : (backboneCycle L).Adj u v) :
    (backboneCycle L).Adj (cycleRotate r u) (cycleRotate r v) := by
  change u ≠ v ∧ _ at h
  change cycleRotate r u ≠ cycleRotate r v ∧ _
  refine ⟨fun hh => h.1 (cycleRotate_injective r hh), ?_⟩
  have hr := r.isLt
  have hu := u.isLt
  have hv := v.isLt
  have hadj := h.2
  change ((u.val+1=v.val ∨ (u.val+1=L ∧ v.val=0)) ∨
    (v.val+1=u.val ∨ (v.val+1=L ∧ u.val=0))) at hadj
  simp only [cycleRotate]
  split_ifs <;> omega

theorem SeparatedMarks.rotate {T : Type*} {L : Nat} {m : T → Fin L}
    (h : SeparatedMarks L m) (r : Fin L) : SeparatedMarks L (cycleRotate r ∘ m) := by
  intro s t hst
  have hs := h s t hst
  have hu := (m s).isLt
  have hv := (m t).isLt
  have hr := r.isLt
  dsimp only [Function.comp_apply,cycleRotate]
  split_ifs at hs ⊢ <;> omega

/-- Five-colorability of the rotated marked cycle pulls back to the original. -/
theorem markedCycle_rotate_pullback {T : Type*} {L : Nat} (m : T → Fin L) (r : Fin L)
    (hc : PackingColorable
      (tipGraph (backboneCycle L) (cyclePrev ∘ (cycleRotate r ∘ m)) (cycleRotate r ∘ m)) 5) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  let f : tipGraph (backboneCycle L) (cyclePrev ∘ m) m →g
      tipGraph (backboneCycle L) (cyclePrev ∘ (cycleRotate r ∘ m)) (cycleRotate r ∘ m) :=
    { toFun := Sum.map (cycleRotate r) id
      map_rel' := by
        intro x y hxy
        cases x with
        | inl u =>
          cases y with
          | inl v => exact cycleRotate_adj r u v hxy
          | inr t =>
            change cycleRotate r u = cyclePrev (cycleRotate r (m t)) ∨
              cycleRotate r u = cycleRotate r (m t)
            rcases hxy with hxy | hxy
            · exact Or.inl ((congrArg (cycleRotate r) hxy).trans (cycleRotate_prev r (m t)))
            · exact Or.inr (congrArg (cycleRotate r) hxy)
        | inr t =>
          cases y with
          | inl u =>
            change cycleRotate r u = cyclePrev (cycleRotate r (m t)) ∨
              cycleRotate r u = cycleRotate r (m t)
            rcases hxy with hxy | hxy
            · exact Or.inl ((congrArg (cycleRotate r) hxy).trans (cycleRotate_prev r (m t)))
            · exact Or.inr (congrArg (cycleRotate r) hxy)
          | inr s => exact hxy }
  exact hc.pullback f (Sum.map_injective.mpr ⟨cycleRotate_injective r,Function.injective_id⟩)

/-- A cycle with no marked triangle tips has the cycle coloring. -/
theorem markedCycle_colorable_empty {T : Type*} [IsEmpty T] (L : Nat) (m : T → Fin L) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  let f : tipGraph (backboneCycle L) (cyclePrev ∘ m) m →g backboneCycle L :=
    { toFun := fun x => x.elim id isEmptyElim
      map_rel' := by
        intro x y hxy
        cases x with
        | inl u =>
          cases y with
          | inl v => exact hxy
          | inr t => exact isEmptyElim t
        | inr t => exact isEmptyElim t }
  apply (backboneCycle_colorable L).pullback f
  intro x y hxy
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl hxy
    | inr t => exact isEmptyElim t
  | inr t => exact isEmptyElim t

/-- Any finite family of triangle tips placed at cyclic distance at least three
has a five-color packing coloring, without a preferred cyclic cut. -/
theorem markedCycle_colorable {T : Type*} [Fintype T]
    (L : Nat) (hL : 3 ≤ L) (m : T → Fin L) (hm : Function.Injective m)
    (hs : SeparatedMarks L m) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ m) m) 5 := by
  cases isEmpty_or_nonempty T with
  | inl hi =>
    let := hi
    exact markedCycle_colorable_empty L m
  | inr hn =>
    obtain ⟨z⟩ := hn
    apply markedCycle_rotate_pullback m (m z)
    exact markedCycle_colorable_zero L hL (cycleRotate (m z) ∘ m)
      ((cycleRotate_injective (m z)).comp hm) (hs.rotate (m z)) z
      (cycleRotate_self (m z))

end Packing
