import Packing.Cycles
import Packing.Tips

namespace Packing

def cyclePrev {L : Nat} (v : Fin L) : Fin L :=
  ⟨if v.val = 0 then L-1 else v.val-1, by
    have := v.isLt
    split_ifs <;> omega⟩

theorem cyclePrev_adj {L : Nat} (hL : 2 ≤ L) (v : Fin L) :
    (backboneCycle L).Adj (cyclePrev v) v := by
  have hv := v.isLt
  change cyclePrev v ≠ v ∧ _
  constructor
  · intro he
    have h := congrArg Fin.val he
    simp only [cyclePrev] at h
    split_ifs at h <;> omega
  · left
    by_cases hz : v.val = 0
    · right
      simp only [cyclePrev, hz, ↓reduceIte, and_true]
      omega
    · left
      simp only [cyclePrev, hz, ↓reduceIte]
      omega

/-- The previous cycle vertex is coordinate 3 of the current history,
including the wraparound from vertex 0 back to vertex L-1. -/
theorem history_at_cyclePrev (s : Nat → History.Word)
    (steps : ∀ n, History.Step (s n) (s (n+1))) (L : Nat)
    (periodic : ∀ n, s (n+L) = s n) (v : Fin L) :
    (s (cyclePrev v).val)[4] = (s v.val)[3] := by
  have hv := v.isLt
  by_cases hz : v.val = 0
  · have he : L-1+1 = L := by omega
    have hs := (steps (L-1)).1 (⟨3, by decide⟩ : Fin 4)
    rw [he, show s L = s 0 by simpa using periodic 0] at hs
    simpa only [cyclePrev, hz, ↓reduceIte] using hs.symm
  · have he : v.val-1+1 = v.val := by omega
    have hs := (steps (v.val-1)).1 (⟨3, by decide⟩ : Fin 4)
    rw [he] at hs
    simpa only [cyclePrev, hz, ↓reduceIte] using hs.symm

/-- A periodic run with marked boundary histories colors the cycle and all
attached triangle tips. Boundary positions may include the cyclic cut. -/
theorem periodic_history_marked_cycle_colorable {T : Type*}
    (s : Nat → History.Word)
    (steps : ∀ n, History.Step (s n) (s (n+1))) (L : Nat) (hL : 2 ≤ L)
    (periodic : ∀ n, s (n+L) = s n)
    (bounds : ∀ n, 1 ≤ (s n)[4] ∧ (s n)[4] ≤ 5)
    (marks : T → Fin L)
    (ports : ∀ t, (s (marks t).val)[3] ≠ 1 ∧ (s (marks t).val)[4] ≠ 1) :
    PackingColorable (tipGraph (backboneCycle L) (cyclePrev ∘ marks) marks) 5 := by
  let c : Fin L → Nat := fun v => (s v.val)[4]
  have hc : IsPacking (backboneCycle L) c := by
    apply isPacking_of_distance_lower_bound c cycleDistance
      (distance_lower_bound_of_edge_bounds cycleDistance cycleDistance_zero cycleDistance_edge_bound)
    intro u v huv hcol
    have hne : u.val ≠ v.val := fun h => huv (Fin.ext h)
    have h := History.periodic_two_arc_separation s steps L periodic u v huv hcol
    simpa only [cycleDistance, hne, ↓reduceIte] using h
  apply packingColorable_withTips (by decide : 1 ≤ 5) (fun v => bounds v.val) hc
    (cyclePrev ∘ marks) marks (fun t => cyclePrev_adj hL (marks t))
  intro t
  refine ⟨?_, (ports t).2⟩
  change (s (cyclePrev (marks t)).val)[4] ≠ 1
  rw [history_at_cyclePrev s steps L periodic (marks t)]
  exact (ports t).1

#print axioms periodic_history_marked_cycle_colorable
end Packing
