import Packing.TriangleStructure
import Packing.Components
import Packing.TipDeletion
import Mathlib.Data.Fintype.Fin
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fin.VecNotation

set_option backward.isDefEq.respectTransparency.types false
set_option maxHeartbeats 1000000

namespace Packing
open SimpleGraph

/-- An injective copy of the six-vertex barbell in a connected target-class graph
exhausts the graph, and hence supplies its explicit four-color packing coloring. -/
theorem connected_barbell_colorable {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G) (hc : G.Connected)
    (f : SmallGraphs.Barbell.graph →g G) (hf : Function.Injective f) :
    PackingColorable G 4 := by
  classical
  have edge (i j : Fin 6) (h : SmallGraphs.Barbell.graph.Adj i j) : G.Adj (f i) (f j) :=
    f.map_rel h
  have h01 := edge 0 1 (by decide)
  have h02 := edge 0 2 (by decide)
  have h12 := edge 1 2 (by decide)
  have h23 := edge 2 3 (by decide)
  have h34 := edge 3 4 (by decide)
  have h35 := edge 3 5 (by decide)
  have h45 := edge 4 5 (by decide)
  have ne (i j : Fin 6) (h : i ≠ j) : f i ≠ f j := fun he => h (hf he)
  have d2 : G.degree (f 2) = 3 := three_neighbors_force_degree_three G hG _ _ _ _
    h02.symm h12.symm h23 (ne 0 1 (by decide)) (ne 0 3 (by decide)) (ne 1 3 (by decide))
  have d3 : G.degree (f 3) = 3 := three_neighbors_force_degree_three G hG _ _ _ _
    h23.symm h34 h35 (ne 2 4 (by decide)) (ne 2 5 (by decide)) (ne 4 5 (by decide))
  have d0 := other_neighbor_degree_le_two G hG _ _ _ d2 d3 h23 h02.symm (ne 3 0 (by decide))
  have d1 := other_neighbor_degree_le_two G hG _ _ _ d2 d3 h23 h12.symm (ne 3 1 (by decide))
  have d4 := other_neighbor_degree_le_two G hG _ _ _ d3 d2 h23.symm h34 (ne 2 4 (by decide))
  have d5 := other_neighbor_degree_le_two G hG _ _ _ d3 d2 h23.symm h35 (ne 2 5 (by decide))
  have n0 := neighbors_eq_pair G (f 0) (f 1) (f 2) d0 h01 h02 (ne 1 2 (by decide))
  have n1 := neighbors_eq_pair G (f 1) (f 0) (f 2) d1 h01.symm h12 (ne 0 2 (by decide))
  have n2 := neighbors_eq_triple G (f 2) (f 0) (f 1) (f 3) (hG.1 _) h02.symm h12.symm h23
    (ne 0 1 (by decide)) (ne 0 3 (by decide)) (ne 1 3 (by decide))
  have n3 := neighbors_eq_triple G (f 3) (f 2) (f 4) (f 5) (hG.1 _) h23.symm h34 h35
    (ne 2 4 (by decide)) (ne 2 5 (by decide)) (ne 4 5 (by decide))
  have n4 := neighbors_eq_pair G (f 4) (f 3) (f 5) d4 h34.symm h45 (ne 3 5 (by decide))
  have n5 := neighbors_eq_pair G (f 5) (f 3) (f 4) d5 h35.symm h45.symm (ne 3 4 (by decide))
  have closed : ∀ x ∈ Set.range f, ∀ y, G.Adj x y → y ∈ Set.range f := by
    rintro _ ⟨i, rfl⟩ y hy
    fin_cases i
    · rcases (n0 y).mp hy with rfl | rfl <;> exact Set.mem_range_self _
    · rcases (n1 y).mp hy with rfl | rfl <;> exact Set.mem_range_self _
    · rcases (n2 y).mp hy with rfl | rfl | rfl <;> exact Set.mem_range_self _
    · rcases (n3 y).mp hy with rfl | rfl | rfl <;> exact Set.mem_range_self _
    · rcases (n4 y).mp hy with rfl | rfl <;> exact Set.mem_range_self _
    · rcases (n5 y).mp hy with rfl | rfl <;> exact Set.mem_range_self _
  have surj : Function.Surjective f := by
    intro x
    obtain ⟨p⟩ := hc (f 0) x
    exact walk_closed_set G (Set.range f) closed p (Set.mem_range_self 0)
  have row0 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 0 j ↔ j = 1 ∨ j = 2 := by decide
  have row1 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 1 j ↔ j = 0 ∨ j = 2 := by decide
  have row2 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 2 j ↔ j = 0 ∨ j = 1 ∨ j = 3 := by decide
  have row3 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 3 j ↔ j = 2 ∨ j = 4 ∨ j = 5 := by decide
  have row4 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 4 j ↔ j = 3 ∨ j = 5 := by decide
  have row5 : ∀ j : Fin 6, SmallGraphs.Barbell.graph.Adj 5 j ↔ j = 3 ∨ j = 4 := by decide
  have adj_iff : ∀ i j, G.Adj (f i) (f j) ↔ SmallGraphs.Barbell.graph.Adj i j := by
    intro i j
    fin_cases i
    · change G.Adj (f 0) (f j) ↔ SmallGraphs.Barbell.graph.Adj 0 j
      rw [n0, row0]
      simp only [hf.eq_iff]
    · change G.Adj (f 1) (f j) ↔ SmallGraphs.Barbell.graph.Adj 1 j
      rw [n1, row1]
      simp only [hf.eq_iff]
    · change G.Adj (f 2) (f j) ↔ SmallGraphs.Barbell.graph.Adj 2 j
      rw [n2, row2]
      simp only [hf.eq_iff]
    · change G.Adj (f 3) (f j) ↔ SmallGraphs.Barbell.graph.Adj 3 j
      rw [n3, row3]
      simp only [hf.eq_iff]
    · change G.Adj (f 4) (f j) ↔ SmallGraphs.Barbell.graph.Adj 4 j
      rw [n4, row4]
      simp only [hf.eq_iff]
    · change G.Adj (f 5) (f j) ↔ SmallGraphs.Barbell.graph.Adj 5 j
      rw [n5, row5]
      simp only [hf.eq_iff]
  let e : Fin 6 ≃ V := Equiv.ofBijective f ⟨hf, surj⟩
  let hom : G →g SmallGraphs.Barbell.graph := {
    toFun := e.symm
    map_rel' := by
      intro u v huv
      apply (adj_iff (e.symm u) (e.symm v)).mp
      change G.Adj (e (e.symm u)) (e (e.symm v))
      simpa only [Equiv.apply_symm_apply] using huv
  }
  exact SmallGraphs.Barbell.colorable.pullback hom e.symm.injective

/-- A bridge between two distinct tip-port edges forces the barbell exception. -/
theorem TipDeletionData.bridge_colorable {V : Type*} [Fintype V]
    {G : SimpleGraph V} [DecidableRel G.Adj] (D : TipDeletionData G)
    (hG : TargetClass G) (hc : G.Connected)
    (overlap : ∀ s t : D.tips, ∀ v,
      (v = D.left s ∨ v = D.right s) → (v = D.left t ∨ v = D.right t) → s = t)
    (t s : D.tips) (hts : t ≠ s) (x y : V)
    (hx : x = D.left t ∨ x = D.right t) (hy : y = D.left s ∨ y = D.right s)
    (hxy : G.Adj x y) : PackingColorable G 4 := by
  classical
  have tip_ne (a b : D.tips) (ha : a ≠ b) : a.val ≠ b.val := fun h => ha (Subtype.ext h)
  have tip_port_ne (a b : D.tips) :
      a.val ≠ D.left b ∧ a.val ≠ D.right b :=
    ⟨fun h => D.left_keep b (h ▸ a.property), fun h => D.right_keep b (h ▸ a.property)⟩
  have cross (a b : V) (ha : a = D.left t ∨ a = D.right t)
      (hb : b = D.left s ∨ b = D.right s) : a ≠ b := by
    intro he
    subst b
    exact hts (overlap t s a ha hb)
  have ntl := (tip_port_ne t t).1
  have ntr := (tip_port_ne t t).2
  have ntsl := (tip_port_ne t s).1
  have ntsr := (tip_port_ne t s).2
  have nstl := (tip_port_ne s t).1
  have nstr := (tip_port_ne s t).2
  have nsl := (tip_port_ne s s).1
  have nsr := (tip_port_ne s s).2
  have ntt := tip_ne t s hts
  have nt := (D.ports_adj t).ne
  have ns := (D.ports_adj s).ne
  have nll := cross (D.left t) (D.left s) (Or.inl rfl) (Or.inl rfl)
  have nlr := cross (D.left t) (D.right s) (Or.inl rfl) (Or.inr rfl)
  have nrl := cross (D.right t) (D.left s) (Or.inr rfl) (Or.inl rfl)
  have nrr := cross (D.right t) (D.right s) (Or.inr rfl) (Or.inr rfl)
  have etl := (D.tip_adj t (D.left t)).mpr (Or.inl rfl)
  have etr := (D.tip_adj t (D.right t)).mpr (Or.inr rfl)
  have esl := (D.tip_adj s (D.left s)).mpr (Or.inl rfl)
  have esr := (D.tip_adj s (D.right s)).mpr (Or.inr rfl)
  have et := D.ports_adj t
  have es := D.ports_adj s
  rcases hx with rfl | rfl <;> rcases hy with rfl | rfl
  · let v : Fin 6 → V := ![t.val, D.right t, D.left t, D.left s, s.val, D.right s]
    have hinj : Function.Injective v := by
      intro i j hij
      fin_cases i <;> fin_cases j <;> simp [v, ntl, ntr, ntsl, ntsr, nstl, nstr, nsl, nsr, ntt, nt, ns, nll, nlr, nrl, nrr, Ne.symm ntl, Ne.symm ntr, Ne.symm ntsl, Ne.symm ntsr, Ne.symm nstl, Ne.symm nstr, Ne.symm nsl, Ne.symm nsr, Ne.symm ntt, Ne.symm nt, Ne.symm ns, Ne.symm nll, Ne.symm nlr, Ne.symm nrl, Ne.symm nrr] at hij ⊢
    have hedge : ∀ i j, SmallGraphs.Barbell.graph.Adj i j → G.Adj (v i) (v j) := by
      intro i j hij
      fin_cases i <;> fin_cases j <;>
        simp [SmallGraphs.Barbell.graph, SimpleGraph.fromRel, SmallGraphs.Barbell.edges] at hij <;>
        simp [v, etl, etr, esl, esr, et, es, hxy, etl.symm, etr.symm, esl.symm, esr.symm, et.symm, es.symm, hxy.symm]
    let hom : SmallGraphs.Barbell.graph →g G := {toFun := v, map_rel' := hedge _ _}
    exact connected_barbell_colorable G hG hc hom hinj
  · let v : Fin 6 → V := ![t.val, D.right t, D.left t, D.right s, s.val, D.left s]
    have hinj : Function.Injective v := by
      intro i j hij
      fin_cases i <;> fin_cases j <;> simp [v, ntl, ntr, ntsl, ntsr, nstl, nstr, nsl, nsr, ntt, nt, ns, nll, nlr, nrl, nrr, Ne.symm ntl, Ne.symm ntr, Ne.symm ntsl, Ne.symm ntsr, Ne.symm nstl, Ne.symm nstr, Ne.symm nsl, Ne.symm nsr, Ne.symm ntt, Ne.symm nt, Ne.symm ns, Ne.symm nll, Ne.symm nlr, Ne.symm nrl, Ne.symm nrr] at hij ⊢
    have hedge : ∀ i j, SmallGraphs.Barbell.graph.Adj i j → G.Adj (v i) (v j) := by
      intro i j hij
      fin_cases i <;> fin_cases j <;>
        simp [SmallGraphs.Barbell.graph, SimpleGraph.fromRel, SmallGraphs.Barbell.edges] at hij <;>
        simp [v, etl, etr, esl, esr, et, es, hxy, etl.symm, etr.symm, esl.symm, esr.symm, et.symm, es.symm, hxy.symm]
    let hom : SmallGraphs.Barbell.graph →g G := {toFun := v, map_rel' := hedge _ _}
    exact connected_barbell_colorable G hG hc hom hinj
  · let v : Fin 6 → V := ![t.val, D.left t, D.right t, D.left s, s.val, D.right s]
    have hinj : Function.Injective v := by
      intro i j hij
      fin_cases i <;> fin_cases j <;> simp [v, ntl, ntr, ntsl, ntsr, nstl, nstr, nsl, nsr, ntt, nt, ns, nll, nlr, nrl, nrr, Ne.symm ntl, Ne.symm ntr, Ne.symm ntsl, Ne.symm ntsr, Ne.symm nstl, Ne.symm nstr, Ne.symm nsl, Ne.symm nsr, Ne.symm ntt, Ne.symm nt, Ne.symm ns, Ne.symm nll, Ne.symm nlr, Ne.symm nrl, Ne.symm nrr] at hij ⊢
    have hedge : ∀ i j, SmallGraphs.Barbell.graph.Adj i j → G.Adj (v i) (v j) := by
      intro i j hij
      fin_cases i <;> fin_cases j <;>
        simp [SmallGraphs.Barbell.graph, SimpleGraph.fromRel, SmallGraphs.Barbell.edges] at hij <;>
        simp [v, etl, etr, esl, esr, et, es, hxy, etl.symm, etr.symm, esl.symm, esr.symm, et.symm, es.symm, hxy.symm]
    let hom : SmallGraphs.Barbell.graph →g G := {toFun := v, map_rel' := hedge _ _}
    exact connected_barbell_colorable G hG hc hom hinj
  · let v : Fin 6 → V := ![t.val, D.left t, D.right t, D.right s, s.val, D.left s]
    have hinj : Function.Injective v := by
      intro i j hij
      fin_cases i <;> fin_cases j <;> simp [v, ntl, ntr, ntsl, ntsr, nstl, nstr, nsl, nsr, ntt, nt, ns, nll, nlr, nrl, nrr, Ne.symm ntl, Ne.symm ntr, Ne.symm ntsl, Ne.symm ntsr, Ne.symm nstl, Ne.symm nstr, Ne.symm nsl, Ne.symm nsr, Ne.symm ntt, Ne.symm nt, Ne.symm ns, Ne.symm nll, Ne.symm nlr, Ne.symm nrl, Ne.symm nrr] at hij ⊢
    have hedge : ∀ i j, SmallGraphs.Barbell.graph.Adj i j → G.Adj (v i) (v j) := by
      intro i j hij
      fin_cases i <;> fin_cases j <;>
        simp [SmallGraphs.Barbell.graph, SimpleGraph.fromRel, SmallGraphs.Barbell.edges] at hij <;>
        simp [v, etl, etr, esl, esr, et, es, hxy, etl.symm, etr.symm, esl.symm, esr.symm, et.symm, es.symm, hxy.symm]
    let hom : SmallGraphs.Barbell.graph →g G := {toFun := v, map_rel' := hedge _ _}
    exact connected_barbell_colorable G hG hc hom hinj

end Packing
