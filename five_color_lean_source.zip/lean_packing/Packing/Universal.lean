import Packing.Certificate
import Packing.Automaton

namespace Packing.Universal

abbrev Gap := {g : Nat // 2 ≤ g}
def capped (g : Gap) : Fin 14 := ⟨min g.val 15 - 2, by omega⟩
def R (g : Gap) : Rel (Fin 171) := Automaton.gap g.val

theorem cap_correct (g : Gap) : R g = Certificate.R (capped g) := by
  have h := Automaton.gap_spec (capped g)
  have he : (capped g).val + 2 = min g.val 15 := by
    simp only [capped]
    have := g.property
    omega
  rw [he] at h
  exact (Automaton.gap_clamp g.val).trans h

/-- The concrete automaton has a closed walk for every sequence of two or
more gaps, without an upper bound on the gaps or the length of the sequence. -/
theorem arbitrary_gap_sequence (g h : Gap) (tail : List Gap) :
    (product R (g :: h :: tail)).Diagonal := by
  unfold product
  rw [extend_map R Certificate.R capped cap_correct]
  exact Certificate.every_word_of_length_at_least_two (capped g) (capped h) (tail.map capped)

/-- The one-triangle long cases. Gaps 2, 3, and 4 are deliberately separate. -/
theorem long_single_gap (g : Gap) (hg : 5 ≤ g.val) :
    (product R [g]).Diagonal := by
  unfold product
  rw [extend_map R Certificate.R capped cap_correct]
  have hk : 3 ≤ (capped g).val := by
    simp only [capped]
    omega
  let j : Fin 11 := ⟨(capped g).val - 3, by have := (capped g).isLt; omega⟩
  have hj : (⟨j.val + 3, by omega⟩ : Fin 14) = capped g := by
    apply Fin.ext
    dsimp [j]
    omega
  have h := Certificate.every_long_singleton j
  rw [hj] at h
  exact h

#print axioms arbitrary_gap_sequence
#print axioms long_single_gap
end Packing.Universal
