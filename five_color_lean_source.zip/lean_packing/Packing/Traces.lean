import Packing.Relations

namespace Packing

/-- An explicit relational walk with a prescribed number of edges. -/
inductive Trace (B : Rel α) : Nat → α → α → Prop
  | zero (a : α) : Trace B 0 a a
  | snoc {n a b c} : Trace B n a b → B b c → Trace B (n+1) a c

theorem power_iff_trace (B : Rel α) (n : Nat) (a b : α) :
    B.power n a b ↔ Trace B n a b := by
  induction n generalizing a b with
  | zero =>
    constructor
    · intro h
      change a = b at h
      subst b
      exact Trace.zero a
    · intro h
      cases h
      rfl
  | succ n ih =>
    constructor
    · rintro ⟨c, h, k⟩
      exact Trace.snoc ((ih a c).mp h) k
    · intro h
      cases h with
      | snoc h k => exact ⟨_, (ih _ _).mpr h, k⟩

theorem Trace.append {B : Rel α} {n m : Nat} {a b c : α}
    (p : Trace B n a b) (q : Trace B m b c) : Trace B (n+m) a c := by
  induction q with
  | zero => exact p
  | snoc q h ih => exact Trace.snoc (ih p) h

theorem trace_extend (B : Rel α) (R : γ → Rel β) (f : β → α) (len : γ → Nat)
    (hR : ∀ g u v, R g u v → Trace B (len g) (f u) (f v))
    (gs : List γ) (n : Nat) (P : Rel β)
    (hP : ∀ u v, P u v → Trace B n (f u) (f v)) :
    ∀ u v, extend R P gs u v → Trace B (n + (gs.map len).sum) (f u) (f v) := by
  induction gs generalizing n P with
  | nil => exact hP
  | cons g gs ih =>
    have hstep : ∀ u v, P.comp (R g) u v → Trace B (n + len g) (f u) (f v) := by
      rintro u v ⟨w, h, k⟩
      exact (hP u w h).append (hR g w v k)
    have h := ih (n + len g) (P.comp (R g)) hstep
    simpa only [extend, List.map_cons, List.sum_cons, Nat.add_assoc] using h

theorem trace_product (B : Rel α) (R : γ → Rel β) (f : β → α) (len : γ → Nat)
    (hR : ∀ g u v, R g u v → Trace B (len g) (f u) (f v))
    (gs : List γ) (u v : β) (h : product R gs u v) :
    Trace B (gs.map len).sum (f u) (f v) := by
  have hid : ∀ a b, Rel.ident a b → Trace B 0 (f a) (f b) := by
    intro a b hab
    change a = b at hab
    subst b
    exact Trace.zero (f a)
  simpa only [Nat.zero_add] using trace_extend B R f len hR gs 0 Rel.ident hid u v h

/-- Extract a finite path as an indexed function, keeping the two endpoints. -/
theorem Trace.indexed {B : Rel α} {L : Nat} {a b : α} (p : Trace B L a b) :
    ∃ f : Nat → α, f 0 = a ∧ f L = b ∧ ∀ k, k < L → B (f k) (f (k+1)) := by
  induction p with
  | zero a => exact ⟨fun _ => a, rfl, rfl, fun _ h => by omega⟩
  | @snoc n a b c p h ih =>
    obtain ⟨f, hzero, hend, hedge⟩ := ih
    let f' : Nat → α := fun k => if k ≤ n then f k else c
    refine ⟨f', ?_, ?_, ?_⟩
    · simpa [f'] using hzero
    · simp [f', show ¬ n+1 ≤ n by omega]
    · intro k hk
      by_cases hkn : k < n
      · simpa [f', Nat.le_of_lt hkn, Nat.succ_le_of_lt hkn] using hedge k hkn
      · have he : k = n := by omega
        subst k
        simpa [f', hend, show ¬ n+1 ≤ n by omega] using h

/-- A nonempty closed trace can be repeated forever, with the same period. -/
theorem Trace.periodic_run {B : Rel α} {L : Nat} {a : α} (p : Trace B L a a)
    (hL : 0 < L) :
    ∃ run : Nat → α, run 0 = a ∧ (∀ k, B (run k) (run (k+1))) ∧
      ∀ k, run (k+L) = run k := by
  obtain ⟨f, hzero, hend, hedge⟩ := p.indexed
  let run := fun k => f (k % L)
  refine ⟨run, ?_, ?_, ?_⟩
  · simpa [run] using hzero
  · intro k
    have hk := Nat.mod_lt k hL
    have he := hedge (k % L) hk
    change B (f (k % L)) (f ((k+1) % L))
    rw [← Nat.mod_add_mod k L 1]
    by_cases hlast : k % L + 1 = L
    · rw [hlast, Nat.mod_self]
      rw [hlast, hend] at he
      rwa [hzero]
    · have hs : k % L + 1 < L := by omega
      rw [Nat.mod_eq_of_lt hs]
      exact he
  · intro k
    simp [run]

end Packing
