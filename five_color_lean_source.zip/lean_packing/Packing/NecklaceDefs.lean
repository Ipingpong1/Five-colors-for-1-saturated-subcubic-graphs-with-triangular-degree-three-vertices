import Packing.MarkedCycles
import Packing.SegmentedTraces
import Packing.History

namespace Packing

def backboneLength (gs : List Nat) : Nat := (gs.map (· + 1)).sum
abbrev NecklaceTip (gs : List Nat) := {k : Nat // k ∈ segmentEnds (gs.map (· + 1))}

def necklaceMark (gs : List Nat) (hL : 0 < backboneLength gs)
    (t : NecklaceTip gs) : Fin (backboneLength gs) :=
  ⟨t.val % backboneLength gs, Nat.mod_lt _ hL⟩

/-- A cycle with a triangle tip at the final edge of each gap-plus-one block.
The final block closes at vertex zero. -/
def necklace (gs : List Nat) (hL : 0 < backboneLength gs) :
    SimpleGraph (Fin (backboneLength gs) ⊕ NecklaceTip gs) :=
  tipGraph (backboneCycle (backboneLength gs))
    (cyclePrev ∘ necklaceMark gs hL) (necklaceMark gs hL)

def boundaryGood (i : Fin 390) : Prop :=
  Data.histories[i.val][3] ≠ 1 ∧ Data.histories[i.val][4] ≠ 1

theorem boundaryGood_map (i : Fin 171) : boundaryGood (Automaton.boundaryMap i) :=
  History.boundary_ports_avoid_one i

/-- This construction preserves every marked triangle boundary and produces
an actual graph coloring, including all tips and the cyclic cut. -/
theorem necklace_colorable_of_segmented (gs : List Nat)
    (hL : 2 ≤ backboneLength gs) (a : Fin 390)
    (p : SegmentedTrace Data.B.denote boundaryGood (gs.map (· + 1)) a a) :
    PackingColorable (necklace gs (by omega)) 5 := by
  obtain ⟨f, fzero, fend, fedge, fgood⟩ := p.indexed
  have closed : f (backboneLength gs) = f 0 := fend.trans fzero.symm
  obtain ⟨run, edges, periodic, retained⟩ :=
    periodize_indexed Data.B.denote f (backboneLength gs) (by omega) closed fedge
  let s : Nat → History.Word := fun k => Data.histories[(run k).val]
  apply periodic_history_marked_cycle_colorable s
    (fun k => History.ordinary_steps_sound _ _ (edges k)) (backboneLength gs) hL
  · intro k; simp only [s, periodic k]
  · intro k; exact (History.histories_admissible (run k)).1 ⟨4, by decide⟩
  · intro t
    have ht := segmentEnds_le_sum (gs.map (· + 1)) t.val t.property
    have hg := fgood t.val t.property
    have hr := retained t.val ht
    change boundaryGood (run (t.val % backboneLength gs))
    rw [hr]
    exact hg

#print axioms necklace_colorable_of_segmented
end Packing
