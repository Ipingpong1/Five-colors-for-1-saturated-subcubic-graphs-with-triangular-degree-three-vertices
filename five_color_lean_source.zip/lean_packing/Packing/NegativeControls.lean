import Packing.Coverage
import Packing.HistoryDefs

namespace Packing.NegativeControls

/-- An empty relation must not provide a closed walk. -/
theorem empty_has_no_diagonal :
    BitMatrix.diagCheck (⟨#[0,0], rfl⟩ : BitMatrix 2) = false := by decide +kernel

/-- A proposed intermediate vertex is rejected when its first edge is absent. -/
theorem invalid_cover_rejected : coverCheck
    (⟨#[1], rfl⟩ : BitMatrix 1) ⟨#[0], rfl⟩ ⟨#[1], rfl⟩
    ⟨#[[0]], rfl⟩ = false := by decide +kernel

/-- Repeating color 5 at distance exactly 5 is forbidden, not merely distance 4. -/
theorem distance_five_is_forbidden :
    ¬ History.Step ⟨#[5,1,2,1,3], rfl⟩ ⟨#[1,2,1,3,5], rfl⟩ := by decide +kernel

end Packing.NegativeControls
