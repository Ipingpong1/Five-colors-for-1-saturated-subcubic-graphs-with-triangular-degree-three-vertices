import Packing.Relations

namespace Packing

/-- Row bitsets. Bits outside the finite vertex set are ignored by `denote`. -/
abbrev BitMatrix (n : Nat) := Vector Nat n

def allFin (n : Nat) (f : Fin n → Bool) : Bool := (List.finRange n).all f

theorem allFin_sound {f : Fin n → Bool} (h : allFin n f = true) (i : Fin n) :
    f i = true := List.all_eq_true.mp h i (List.mem_finRange i)

def BitMatrix.eqCheck (P Q : BitMatrix n) : Bool := P == Q

theorem BitMatrix.eqCheck_sound (P Q : BitMatrix n) (h : P.eqCheck Q = true) : P = Q := by
  simpa only [eqCheck, beq_iff_eq] using h

def orList : List Nat → Nat
  | [] => 0
  | a :: as => a ||| orList as

theorem orList_spec (xs : List Nat) (j : Nat) :
    (orList xs).testBit j = true ↔ ∃ x ∈ xs, x.testBit j = true := by
  induction xs with
  | nil => simp [orList]
  | cons x xs ih => simp [orList, Nat.testBit_or, ih]

def BitMatrix.denote (P : BitMatrix n) : Rel (Fin n) :=
  fun i j => P[i.val].testBit j.val = true

def BitMatrix.mul (P Q : BitMatrix n) : BitMatrix n :=
  Vector.ofFn fun i => orList ((List.finRange n).map fun k =>
    if P[i.val].testBit k.val then Q[k.val] else 0)

theorem BitMatrix.mul_spec (P Q : BitMatrix n) :
    (P.mul Q).denote = P.denote.comp Q.denote := by
  funext i j
  apply propext
  simp only [denote, mul, Vector.getElem_ofFn, orList_spec, List.mem_map]
  constructor
  · rintro ⟨x, ⟨k, _, rfl⟩, hx⟩
    by_cases h : P[i.val].testBit k.val = true
    · simp only [h, ↓reduceIte] at hx
      exact ⟨k, h, hx⟩
    · simp [h] at hx
  · rintro ⟨k, hk, hj⟩
    change P[i.val].testBit k.val = true at hk
    refine ⟨Q[k.val], ⟨k, List.mem_finRange k, ?_⟩, hj⟩
    simp [hk]

def BitMatrix.subCheck (P Q : BitMatrix n) : Bool :=
  (List.finRange n).all fun i => (P[i.val] &&& Q[i.val]) == P[i.val]

theorem BitMatrix.subCheck_sound (P Q : BitMatrix n)
    (h : P.subCheck Q = true) : P.denote.Included Q.denote := by
  intro i j hp
  have hi : P[i.val] &&& Q[i.val] = P[i.val] := by
    have := (List.all_eq_true.mp h) i (List.mem_finRange i)
    simpa only [beq_iff_eq] using this
  have hbit := congrArg (fun x : Nat => x.testBit j.val) hi
  simp only [Nat.testBit_and] at hbit
  change P[i.val].testBit j.val = true at hp
  change Q[i.val].testBit j.val = true
  simpa only [hp, Bool.true_and] using hbit

def BitMatrix.diagCheck (P : BitMatrix n) : Bool :=
  (List.finRange n).any fun i => P[i.val].testBit i.val

theorem BitMatrix.diagCheck_sound (P : BitMatrix n)
    (h : P.diagCheck = true) : P.denote.Diagonal := by
  obtain ⟨i, _, hi⟩ := List.any_eq_true.mp h
  exact ⟨i, hi⟩

def BitMatrix.ident (n : Nat) : BitMatrix n := Vector.ofFn fun i => 2 ^ i.val

theorem BitMatrix.ident_spec (n : Nat) : (BitMatrix.ident n).denote = Rel.ident := by
  funext i j
  simp [denote, ident, Rel.ident, Nat.testBit_two_pow, Fin.ext_iff]

/-- A restriction/reindexing of both ends, allowing different matrix dimensions. -/
def BitMatrix.restrict (P : BitMatrix n) (f : Fin m → Fin n) : BitMatrix m :=
  Vector.ofFn fun i => orList ((List.finRange m).map fun j =>
    if P[(f i).val].testBit (f j).val then 2 ^ j.val else 0)

theorem BitMatrix.restrict_spec (P : BitMatrix n) (f : Fin m → Fin n) :
    (P.restrict f).denote = fun i j => P.denote (f i) (f j) := by
  funext i j
  apply propext
  simp only [denote, restrict, Vector.getElem_ofFn, orList_spec, List.mem_map]
  constructor
  · rintro ⟨x, ⟨k, _, rfl⟩, hx⟩
    by_cases h : P[(f i).val].testBit (f k).val = true
    · simp only [h, ↓reduceIte, Nat.testBit_two_pow, decide_eq_true_eq] at hx
      have : k = j := Fin.ext hx
      simpa [this] using h
    · simp [h] at hx
  · intro h
    refine ⟨2 ^ j.val, ⟨j, List.mem_finRange j, ?_⟩, ?_⟩
    · simp [h]
    · simp

end Packing
