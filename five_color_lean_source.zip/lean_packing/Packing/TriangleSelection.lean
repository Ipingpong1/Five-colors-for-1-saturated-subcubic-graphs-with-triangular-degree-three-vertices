import Packing.TriangleStructure
import Packing.TipDeletion

namespace Packing
open SimpleGraph

/-- A triangle recorded by its unordered vertex set. -/
def IsTriangleSet {V : Type*} [DecidableEq V] (G : SimpleGraph V) (s : Finset V) : Prop :=
  ∃ a b c, G.Adj a b ∧ G.Adj b c ∧ G.Adj c a ∧ s = {a,b,c}

namespace IsTriangleSet
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V}
  [DecidableRel G.Adj]

omit [Fintype V] [DecidableRel G.Adj] in
theorem rooted {s : Finset V} (hs : IsTriangleSet G s) {v : V} (hv : v ∈ s) :
    ∃ b c, G.Adj v b ∧ G.Adj b c ∧ G.Adj c v ∧ s = {v,b,c} := by
  obtain ⟨a,b,c,hab,hbc,hca,rfl⟩ := hs
  simp only [Finset.mem_insert, Finset.mem_singleton] at hv
  rcases hv with rfl | rfl | rfl
  · exact ⟨b,c,hab,hbc,hca,rfl⟩
  · refine ⟨c,a,hbc,hca,hab,?_⟩
    ext x; simp only [Finset.mem_insert, Finset.mem_singleton]; tauto
  · refine ⟨a,b,hca,hab,hbc,?_⟩
    ext x; simp only [Finset.mem_insert, Finset.mem_singleton]; tauto

theorem eq_of_mem (hG : TargetClass G)
    (hdiamond : ∀ u v a b, G.Adj u v → G.Adj u a → G.Adj u b →
      G.Adj v a → G.Adj v b → a = b)
    {s t : Finset V} (hs : IsTriangleSet G s) (ht : IsTriangleSet G t)
    {v : V} (hvs : v ∈ s) (hvt : v ∈ t) : s = t := by
  obtain ⟨b,c,hvb,hbc,hcv,rfl⟩ := hs.rooted hvs
  obtain ⟨d,e,hvd,hde,hev,rfl⟩ := ht.rooted hvt
  rcases triangle_overlap_pair G hG hdiamond v b c d e hvb hbc hcv hvd hde hev with
    ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · rfl
  · ext x; simp only [Finset.mem_insert, Finset.mem_singleton]; tauto

structure TipChoice (s : Finset V) where
  tip : V
  left : V
  right : V
  degree_two : G.degree tip = 2
  tip_left : G.Adj tip left
  left_right : G.Adj left right
  right_tip : G.Adj right tip
  vertices : s = {tip,left,right}

theorem choice_exists (hG : TargetClass G) {s : Finset V} (hs : IsTriangleSet G s) :
    Nonempty (TipChoice (G := G) s) := by
  obtain ⟨a,b,c,hab,hbc,hca,rfl⟩ := hs
  rcases triangle_has_degree_two G hG a b c hab hbc hca with ha | hb | hc
  · exact ⟨⟨a,b,c,ha,hab,hbc,hca,rfl⟩⟩
  · refine ⟨⟨b,c,a,hb,hbc,hca,hab,?_⟩⟩
    ext x; simp only [Finset.mem_insert, Finset.mem_singleton]; tauto
  · refine ⟨⟨c,a,b,hc,hca,hab,hbc,?_⟩⟩
    ext x; simp only [Finset.mem_insert, Finset.mem_singleton]; tauto

end IsTriangleSet

namespace TriangleSelection
variable {V : Type*} [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj]
noncomputable section
local instance : DecidableEq V := Classical.decEq V

abbrev Triangle := {s : Finset V // IsTriangleSet G s}

variable (hG : TargetClass G)

def choice (s : Triangle G) : IsTriangleSet.TipChoice (G := G) s.val :=
  Classical.choice (s.property.choice_exists hG)

def tips : Set V := Set.range (fun s : Triangle G => (choice G hG s).tip)

theorem tip_mem (s : Triangle G) : (choice G hG s).tip ∈ s.val := by
  simp only [(choice G hG s).vertices, Finset.mem_insert, Finset.mem_singleton, true_or, or_true, eq_self]

theorem left_mem (s : Triangle G) : (choice G hG s).left ∈ s.val := by
  simp only [(choice G hG s).vertices, Finset.mem_insert, Finset.mem_singleton, true_or, or_true, eq_self]

theorem right_mem (s : Triangle G) : (choice G hG s).right ∈ s.val := by
  simp only [(choice G hG s).vertices, Finset.mem_insert, Finset.mem_singleton, true_or, or_true, eq_self]

variable (hdiamond : ∀ u v a b, G.Adj u v → G.Adj u a → G.Adj u b →
      G.Adj v a → G.Adj v b → a = b)

include hdiamond in
theorem unique_selected {s : Triangle G} {v : V} (hv : v ∈ s.val)
    (ht : v ∈ tips G hG) : v = (choice G hG s).tip := by
  obtain ⟨t, rfl⟩ := ht
  have he : t = s := Subtype.ext (t.property.eq_of_mem hG hdiamond s.property
    (tip_mem G hG t) hv)
  rw [he]

include hdiamond in
theorem left_keep (s : Triangle G) : (choice G hG s).left ∉ tips G hG := by
  intro h
  exact (choice G hG s).tip_left.ne (unique_selected G hG hdiamond (left_mem G hG s) h).symm

include hdiamond in
theorem right_keep (s : Triangle G) : (choice G hG s).right ∉ tips G hG := by
  intro h
  exact (choice G hG s).right_tip.ne (unique_selected G hG hdiamond (right_mem G hG s) h)

def owner (t : tips G hG) : Triangle G := Classical.choose t.property

theorem owner_tip (t : tips G hG) : (choice G hG (owner G hG t)).tip = t.val :=
  Classical.choose_spec t.property

def data : TipDeletionData G where
  tips := tips G hG
  left t := (choice G hG (owner G hG t)).left
  right t := (choice G hG (owner G hG t)).right
  left_keep t := left_keep G hG hdiamond (owner G hG t)
  right_keep t := right_keep G hG hdiamond (owner G hG t)
  ports_adj t := (choice G hG (owner G hG t)).left_right
  tip_adj t v := by
    rw [← owner_tip G hG t]
    exact neighbors_eq_pair G _ _ _ (choice G hG (owner G hG t)).degree_two.le
      (choice G hG (owner G hG t)).tip_left
      (choice G hG (owner G hG t)).right_tip.symm
      (choice G hG (owner G hG t)).left_right.ne v


include hdiamond in
theorem degree_two (t : (data G hG hdiamond).tips) : G.degree t.val = 2 := by
  rw [← owner_tip G hG t]
  exact (choice G hG (owner G hG t)).degree_two

include hdiamond in
theorem drop (v : V) (hv : G.degree v = 3) :
    ∃ t : (data G hG hdiamond).tips, G.Adj v t.val := by
  obtain ⟨a,b,hab,hva,habedge,hbv⟩ := hG.2.1 v hv
  let s : Triangle G := ⟨{v,a,b}, v,a,b,hva,habedge,hbv,rfl⟩
  let c := choice G hG s
  have hvm : v ∈ s.val := by simp [s]
  have hne : v ≠ c.tip := by
    intro h
    have hh : G.degree v = 2 := h.symm ▸ c.degree_two
    omega
  refine ⟨⟨c.tip, ⟨s,rfl⟩⟩, ?_⟩
  have hm : v = c.tip ∨ v = c.left ∨ v = c.right := by
    simpa only [c.vertices, Finset.mem_insert, Finset.mem_singleton] using hvm
  rcases hm with hm | hm | hm
  · exact (hne hm).elim
  · simpa only [hm] using c.tip_left.symm
  · simpa only [hm] using c.right_tip

include hdiamond in
theorem port_mem_owner (t : (data G hG hdiamond).tips) (v : V)
    (hv : v = (data G hG hdiamond).left t ∨ v = (data G hG hdiamond).right t) :
    v ∈ (owner G hG t).val := by
  rcases hv with rfl | rfl
  · exact left_mem G hG (owner G hG t)
  · exact right_mem G hG (owner G hG t)

include hdiamond in
/-- Distinct selected triangles have disjoint pairs of retained ports. -/
theorem ports_disjoint (s t : (data G hG hdiamond).tips) (v : V)
    (hs : v = (data G hG hdiamond).left s ∨ v = (data G hG hdiamond).right s)
    (ht : v = (data G hG hdiamond).left t ∨ v = (data G hG hdiamond).right t) : s = t := by
  have hst : owner G hG s = owner G hG t := Subtype.ext
    ((owner G hG s).property.eq_of_mem hG hdiamond (owner G hG t).property
      (port_mem_owner G hG hdiamond s v hs) (port_mem_owner G hG hdiamond t v ht))
  apply Subtype.ext
  rw [← owner_tip G hG s, ← owner_tip G hG t, hst]

include hG hdiamond in
/-- Every graph without a shared-edge pair admits a simultaneous choice of
independent degree-two tips, with one removed neighbor at every degree-three
vertex and disjoint retained triangle edges. -/
theorem exists_data : ∃ D : TipDeletionData G,
    (∀ t : D.tips, G.degree t.val = 2) ∧
    (∀ v, G.degree v = 3 → ∃ t : D.tips, G.Adj v t.val) ∧
    (∀ s t : D.tips, ∀ v,
      (v = D.left s ∨ v = D.right s) →
      (v = D.left t ∨ v = D.right t) → s = t) := by
  exact ⟨data G hG hdiamond, degree_two G hG hdiamond, drop G hG hdiamond,
    ports_disjoint G hG hdiamond⟩

end
end TriangleSelection
end Packing
