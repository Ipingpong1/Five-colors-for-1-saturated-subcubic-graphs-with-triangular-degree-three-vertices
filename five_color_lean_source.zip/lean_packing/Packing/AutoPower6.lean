import Packing.GapDefs
import Packing.FastMatrix
namespace Packing.Automaton.Checks
open Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

theorem power_step6 : P6.mul B = P7 := by
  rw [← BitMatrix.fastMul_eq]
  apply BitMatrix.eqCheck_sound
  decide_cbv
end Packing.Automaton.Checks
