import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Combinatorics.SimpleGraph.Walk.Maps

/-! Graph-level definitions and inheritance lemmas. The universal coloring
theorem for this exact target class is proved in `Packing.FullTheorem`. -/
namespace Packing
open SimpleGraph

/-- The walk formulation correctly handles vertices in different components. -/
def IsPacking {V : Type*} (G : SimpleGraph V) (c : V → ℕ) : Prop :=
  ∀ u v, u ≠ v → c u = c v → ∀ p : G.Walk u v, c u < p.length

def PackingColorable {V : Type*} (G : SimpleGraph V) (k : ℕ) : Prop :=
  ∃ c : V → ℕ, (∀ v, 1 ≤ c v ∧ c v ≤ k) ∧ IsPacking G c

/-- The exact local hypotheses; leaves and disconnected graphs are allowed. -/
def TargetClass {V : Type*} [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj] : Prop :=
  (∀ v, G.degree v ≤ 3) ∧
  (∀ v, G.degree v = 3 → ∃ a b, a ≠ b ∧ G.Adj v a ∧ G.Adj a b ∧ G.Adj b v) ∧
  (∀ v, G.degree v = 3 → ∀ a b,
    G.Adj v a → G.degree a = 3 → G.Adj v b → G.degree b = 3 → a = b)

/-- Restriction along an injective edge-preserving map, including non-induced subgraphs. -/
theorem IsPacking.pullback {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    {c : W → ℕ} (hc : IsPacking H c) (f : G →g H) (hf : Function.Injective f) :
    IsPacking G (c ∘ f) := by
  intro u v huv hcol p
  have hne : f u ≠ f v := fun h => huv (hf h)
  have h := hc (f u) (f v) hne hcol (p.map f)
  change c (f u) < p.length
  simpa only [Walk.length_map] using h

theorem PackingColorable.pullback {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    {k : ℕ} (hc : PackingColorable H k) (f : G →g H) (hf : Function.Injective f) :
    PackingColorable G k := by
  obtain ⟨c, hb, hp⟩ := hc
  exact ⟨c ∘ f, fun v => hb (f v), hp.pullback f hf⟩

theorem IsPacking.mono {V : Type*} {G H : SimpleGraph V} {c : V → ℕ}
    (h : G ≤ H) (hc : IsPacking H c) : IsPacking G c := by
  intro u v huv heq p
  simpa only [Walk.length_mapLe] using hc u v huv heq (p.mapLe h)

theorem PackingColorable.mono {V : Type*} {G H : SimpleGraph V}
    {k : ℕ} (h : G ≤ H) (hc : PackingColorable H k) : PackingColorable G k := by
  obtain ⟨c, hb, hp⟩ := hc
  exact ⟨c, hb, hp.mono h⟩

theorem PackingColorable.palette_mono {V : Type*} {G : SimpleGraph V}
    {k l : ℕ} (h : k ≤ l) (hc : PackingColorable G k) : PackingColorable G l := by
  obtain ⟨c, hb, hp⟩ := hc
  exact ⟨c, fun v => ⟨(hb v).1, (hb v).2.trans h⟩, hp⟩

/-- A convenient sufficient condition using a distance lower bound.
It supports finite distance certificates without assuming a BFS implementation. -/
theorem isPacking_of_distance_lower_bound {V : Type*} {G : SimpleGraph V}
    (c : V → ℕ) (d : V → V → ℕ)
    (lower : ∀ u v, ∀ p : G.Walk u v, d u v ≤ p.length)
    (separated : ∀ u v, u ≠ v → c u = c v → c u < d u v) : IsPacking G c := by
  intro u v huv hc p
  exact lt_of_lt_of_le (separated u v huv hc) (lower u v p)

/-- A finite collection of 1-Lipschitz potentials supplies distance lower bounds. -/
theorem distance_lower_bound_of_edge_bounds {V : Type*} {G : SimpleGraph V}
    (d : V → V → ℕ) (zero : ∀ u, d u u = 0)
    (step : ∀ root u v, G.Adj u v → d root v ≤ d root u + 1)
    (u v : V) (p : G.Walk u v) : d u v ≤ p.length := by
  have aux : ∀ {a b : V} (p : G.Walk a b), d u b ≤ d u a + p.length := by
    intro a b p
    induction p with
    | nil => simp
    | @cons a b c hab p ih =>
      have hs := step u a b hab
      simp only [Walk.length_cons]
      omega
  have h := aux p
  simpa [zero] using h

end Packing
