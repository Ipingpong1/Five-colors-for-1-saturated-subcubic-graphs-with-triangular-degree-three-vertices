import Packing.NecklaceDefs
import Packing.SmallGraphs

namespace Packing
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

instance (L : Nat) : DecidableRel (backboneCycle L).Adj := by
  unfold backboneCycle SimpleGraph.fromRel
  infer_instance

theorem singleTip_value (g : Nat) (t : NecklaceTip [g]) : t.val = g+1 := by
  have h := t.property
  simpa [segmentEnds] using h

theorem singleTip_unique (g : Nat) (s t : NecklaceTip [g]) : s = t :=
  Subtype.ext ((singleTip_value g s).trans (singleTip_value g t).symm)

theorem singleMark_zero (g : Nat) (hL : 0 < backboneLength [g]) (t : NecklaceTip [g]) :
    necklaceMark [g] hL t = ⟨0, hL⟩ := by
  apply Fin.ext
  simp [necklaceMark, singleTip_value, backboneLength]

namespace SingleGap2
def back (v : Fin 3) : Fin 4 :=
  (⟨#[⟨1, by decide⟩,⟨3, by decide⟩,⟨0, by decide⟩], by rfl⟩ : Vector (Fin 4) 3)[v.val]

theorem back_injective : Function.Injective back := by
  unfold Function.Injective
  decide_cbv

theorem back_avoids_tip : ∀ v, back v ≠ 2 := by decide_cbv

theorem back_edges : ∀ u v, (backboneCycle 3).Adj u v →
    SmallGraphs.Diamond.graph.Adj (back u) (back v) := by decide_cbv

def mapVertex : Fin 3 ⊕ NecklaceTip [2] → Fin 4 :=
  Sum.elim back (fun _ => 2)

theorem map_injective : Function.Injective mapVertex := by
  intro x y he
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl (back_injective he)
    | inr t => exact False.elim (back_avoids_tip u he)
  | inr s =>
    cases y with
    | inl v => exact False.elim (back_avoids_tip v he.symm)
    | inr t => exact congrArg Sum.inr (singleTip_unique 2 s t)

def hom : necklace [2] (by decide) →g SmallGraphs.Diamond.graph where
  toFun := mapVertex
  map_rel' := by
    intro x y h
    cases x with
    | inl u =>
      cases y with
      | inl v => exact back_edges u v h
      | inr t =>
        change u = cyclePrev (necklaceMark [2] _ t) ∨ u = necklaceMark [2] _ t at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
    | inr s =>
      cases y with
      | inl v =>
        change v = cyclePrev (necklaceMark [2] _ s) ∨ v = necklaceMark [2] _ s at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
      | inr t => exact False.elim h

theorem colorable : PackingColorable (necklace [2] (by decide)) 4 :=
  SmallGraphs.Diamond.colorable.pullback hom map_injective
end SingleGap2

namespace SingleGap3
def back (v : Fin 4) : Fin 5 :=
  (⟨#[⟨1, by decide⟩,⟨3, by decide⟩,⟨4, by decide⟩,⟨0, by decide⟩], by rfl⟩ : Vector (Fin 5) 4)[v.val]

theorem back_injective : Function.Injective back := by
  unfold Function.Injective
  decide_cbv

theorem back_avoids_tip : ∀ v, back v ≠ 2 := by decide_cbv

theorem back_edges : ∀ u v, (backboneCycle 4).Adj u v →
    SmallGraphs.GapThree.graph.Adj (back u) (back v) := by decide_cbv

def mapVertex : Fin 4 ⊕ NecklaceTip [3] → Fin 5 :=
  Sum.elim back (fun _ => 2)

theorem map_injective : Function.Injective mapVertex := by
  intro x y he
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl (back_injective he)
    | inr t => exact False.elim (back_avoids_tip u he)
  | inr s =>
    cases y with
    | inl v => exact False.elim (back_avoids_tip v he.symm)
    | inr t => exact congrArg Sum.inr (singleTip_unique 3 s t)

def hom : necklace [3] (by decide) →g SmallGraphs.GapThree.graph where
  toFun := mapVertex
  map_rel' := by
    intro x y h
    cases x with
    | inl u =>
      cases y with
      | inl v => exact back_edges u v h
      | inr t =>
        change u = cyclePrev (necklaceMark [3] _ t) ∨ u = necklaceMark [3] _ t at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
    | inr s =>
      cases y with
      | inl v =>
        change v = cyclePrev (necklaceMark [3] _ s) ∨ v = necklaceMark [3] _ s at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
      | inr t => exact False.elim h

theorem colorable : PackingColorable (necklace [3] (by decide)) 4 :=
  SmallGraphs.GapThree.colorable.pullback hom map_injective
end SingleGap3

namespace SingleGap4
def back (v : Fin 5) : Fin 6 :=
  (⟨#[⟨1, by decide⟩,⟨3, by decide⟩,⟨4, by decide⟩,⟨5, by decide⟩,⟨0, by decide⟩], by rfl⟩ : Vector (Fin 6) 5)[v.val]

theorem back_injective : Function.Injective back := by
  unfold Function.Injective
  decide_cbv

theorem back_avoids_tip : ∀ v, back v ≠ 2 := by decide_cbv

theorem back_edges : ∀ u v, (backboneCycle 5).Adj u v →
    SmallGraphs.GapFour.graph.Adj (back u) (back v) := by decide_cbv

def mapVertex : Fin 5 ⊕ NecklaceTip [4] → Fin 6 :=
  Sum.elim back (fun _ => 2)

theorem map_injective : Function.Injective mapVertex := by
  intro x y he
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl (back_injective he)
    | inr t => exact False.elim (back_avoids_tip u he)
  | inr s =>
    cases y with
    | inl v => exact False.elim (back_avoids_tip v he.symm)
    | inr t => exact congrArg Sum.inr (singleTip_unique 4 s t)

def hom : necklace [4] (by decide) →g SmallGraphs.GapFour.graph where
  toFun := mapVertex
  map_rel' := by
    intro x y h
    cases x with
    | inl u =>
      cases y with
      | inl v => exact back_edges u v h
      | inr t =>
        change u = cyclePrev (necklaceMark [4] _ t) ∨ u = necklaceMark [4] _ t at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
    | inr s =>
      cases y with
      | inl v =>
        change v = cyclePrev (necklaceMark [4] _ s) ∨ v = necklaceMark [4] _ s at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
      | inr t => exact False.elim h

theorem colorable : PackingColorable (necklace [4] (by decide)) 4 :=
  SmallGraphs.GapFour.colorable.pullback hom map_injective
end SingleGap4

#print axioms SingleGap2.colorable
#print axioms SingleGap3.colorable
#print axioms SingleGap4.colorable
end Packing
