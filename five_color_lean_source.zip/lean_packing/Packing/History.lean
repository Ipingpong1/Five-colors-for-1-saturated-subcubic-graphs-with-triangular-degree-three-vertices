import Packing.GapDefs
import Packing.HistoryDefs
namespace Packing.History
open Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

instance (P : BitMatrix n) (i j : Fin n) : Decidable (P.denote i j) :=
  inferInstanceAs (Decidable (_ = true))

theorem histories_checked : allFin 390 (fun i => decide (Admissible histories[i.val])) = true := by
  decide +kernel

theorem histories_admissible (i : Fin 390) : Admissible histories[i.val] :=
  of_decide_eq_true (allFin_sound histories_checked i)

def ordinaryCheck : Bool := allFin 390 fun i => allFin 390 fun j =>
  if B[i.val].testBit j.val then decide (Step histories[i.val] histories[j.val]) else true

theorem ordinary_checked : ordinaryCheck = true := by decide +kernel

theorem ordinary_steps_sound (i j : Fin 390)
    (h : B.denote i j) : Step histories[i.val] histories[j.val] := by
  have hc := allFin_sound (allFin_sound ordinary_checked i) j
  change B[i.val].testBit j.val = true at h
  simpa only [h, ↓reduceIte, decide_eq_true_eq] using hc

theorem restricted_steps_subset : A.subCheck B = true := by decide +kernel

theorem restricted_steps_sound (i j : Fin 390) (h : A.denote i j) :
    Step histories[i.val] histories[j.val] :=
  ordinary_steps_sound i j (BitMatrix.subCheck_sound A B restricted_steps_subset i j h)

def restrictedCheck : Bool := allFin 390 fun i => allFin 390 fun j =>
  if A[i.val].testBit j.val then decide (histories[j.val][4] ≠ 1) else true

theorem restricted_checked : restrictedCheck = true := by decide +kernel

theorem restricted_steps_avoid_one (i j : Fin 390) (h : A.denote i j) :
    histories[j.val][4] ≠ 1 := by
  have hc := allFin_sound (allFin_sound restricted_checked i) j
  change A[i.val].testBit j.val = true at h
  simpa only [h, ↓reduceIte, decide_eq_true_eq] using hc

theorem boundary_checked : allFin 171 (fun i =>
    decide (histories[(Automaton.boundaryMap i).val][3] ≠ 1 ∧
      histories[(Automaton.boundaryMap i).val][4] ≠ 1)) = true := by decide +kernel

theorem boundary_ports_avoid_one (i : Fin 171) :
    histories[(Automaton.boundaryMap i).val][3] ≠ 1 ∧
    histories[(Automaton.boundaryMap i).val][4] ≠ 1 :=
  of_decide_eq_true (allFin_sound boundary_checked i)

#print axioms ordinary_steps_sound
end Packing.History
