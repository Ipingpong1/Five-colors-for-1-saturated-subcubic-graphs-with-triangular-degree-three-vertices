import Packing.Graphs
import Packing.PathSemantics
import Mathlib.Tactic.SplitIfs

namespace Packing

def backboneCycle (L : Nat) : SimpleGraph (Fin L) :=
  SimpleGraph.fromRel fun u v =>
    u.val + 1 = v.val ∨ (u.val + 1 = L ∧ v.val = 0)

def cycleDistance {L : Nat} (u v : Fin L) : Nat :=
  if u.val = v.val then 0 else
    min (History.arcLength L u.val v.val) (History.arcLength L v.val u.val)

theorem cycleDistance_zero {L : Nat} (u : Fin L) : cycleDistance u u = 0 := by
  simp [cycleDistance]

set_option maxHeartbeats 0 in
theorem cycleDistance_edge_bound {L : Nat} (root u v : Fin L)
    (h : (backboneCycle L).Adj u v) : cycleDistance root v ≤ cycleDistance root u + 1 := by
  have hr := root.isLt
  have hu := u.isLt
  have hv := v.isLt
  change u ≠ v ∧ ((u.val + 1 = v.val ∨ (u.val + 1 = L ∧ v.val = 0)) ∨
    (v.val + 1 = u.val ∨ (v.val + 1 = L ∧ u.val = 0))) at h
  rcases h.2 with (h | ⟨h, hz⟩) | (h | ⟨h, hz⟩)
  all_goals
    simp only [cycleDistance, History.arcLength]
    split_ifs <;> omega

/-- A periodic history run gives an actual graph packing coloring of its cycle.
This statement needs no assumption about how the periodic run was obtained. -/
theorem periodic_history_cycle_colorable (s : Nat → History.Word)
    (steps : ∀ n, History.Step (s n) (s (n+1))) (L : Nat)
    (periodic : ∀ n, s (n+L) = s n)
    (bounds : ∀ n, 1 ≤ (s n)[4] ∧ (s n)[4] ≤ 5) :
    PackingColorable (backboneCycle L) 5 := by
  let c : Fin L → Nat := fun v => (s v.val)[4]
  refine ⟨c, fun v => bounds v.val, ?_⟩
  apply isPacking_of_distance_lower_bound c cycleDistance
    (distance_lower_bound_of_edge_bounds cycleDistance cycleDistance_zero cycleDistance_edge_bound)
  intro u v huv hc
  have hne : u.val ≠ v.val := fun h => huv (Fin.ext h)
  have h := History.periodic_two_arc_separation s steps L periodic u v huv hc
  simpa only [cycleDistance, hne, ↓reduceIte] using h

end Packing
