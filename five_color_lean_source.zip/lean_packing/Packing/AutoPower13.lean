import Packing.GapDefs
import Packing.FastMatrix
namespace Packing.Automaton.Checks
open Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

theorem power_step13 : P13.mul B = P14 := by
  rw [← BitMatrix.fastMul_eq]
  apply BitMatrix.eqCheck_sound
  decide_cbv
end Packing.Automaton.Checks
