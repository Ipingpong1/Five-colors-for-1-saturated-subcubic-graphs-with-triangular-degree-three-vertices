import Packing.Graphs

namespace Packing
open SimpleGraph

/-- Once a degree-three vertex has a degree-three neighbor, every other
neighbor has degree at most two. This includes neighbors that are leaves. -/
theorem other_neighbor_degree_le_two {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (v a b : V) (hv : G.degree v = 3) (ha : G.degree a = 3)
    (hva : G.Adj v a) (hvb : G.Adj v b) (hab : a ≠ b) :
    G.degree b ≤ 2 := by
  have hb := hG.1 b
  have hne : G.degree b ≠ 3 := by
    intro hb3
    exact hab (hG.2.2 v hv a b hva ha hvb hb3)
  omega

/-- Every triangle has a vertex of degree exactly two. -/
theorem triangle_has_degree_two {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (a b c : V) (hab : G.Adj a b) (hbc : G.Adj b c) (hca : G.Adj c a) :
    G.degree a = 2 ∨ G.degree b = 2 ∨ G.degree c = 2 := by
  have degree_lower (x y z : V) (hxy : G.Adj x y) (hxz : G.Adj x z)
      (hyz : y ≠ z) : 2 ≤ G.degree x := by
    classical
    have hsub : ({y, z} : Finset V) ⊆ G.neighborFinset x := by
      intro w hw
      simp only [Finset.mem_insert, Finset.mem_singleton] at hw
      rcases hw with rfl | rfl
      · exact (G.mem_neighborFinset x w).mpr hxy
      · exact (G.mem_neighborFinset x w).mpr hxz
    have hcard := Finset.card_le_card hsub
    have he : ({y, z} : Finset V).card = 2 := Finset.card_pair hyz
    rw [he] at hcard
    exact hcard
  have ha2 := degree_lower a b c hab hca.symm hbc.ne
  have hb2 := degree_lower b a c hab.symm hbc hca.ne.symm
  have hc2 := degree_lower c a b hca hbc.symm hab.ne
  by_cases ha : G.degree a = 3
  · by_cases hb : G.degree b = 3
    · have hc := other_neighbor_degree_le_two G hG a b c ha hb hab hca.symm hbc.ne
      exact Or.inr (Or.inr (by omega))
    · have hb3 := hG.1 b
      exact Or.inr (Or.inl (by omega))
  · have ha3 := hG.1 a
    exact Or.inl (by omega)

theorem three_neighbors_force_degree_three {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (x a b c : V) (ha : G.Adj x a) (hb : G.Adj x b) (hc : G.Adj x c)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) : G.degree x = 3 := by
  classical
  have hs : ({a,b,c} : Finset V) ⊆ G.neighborFinset x := by
    intro w hw
    simp only [Finset.mem_insert, Finset.mem_singleton] at hw
    rcases hw with rfl | rfl | rfl
    · exact (G.mem_neighborFinset x w).mpr ha
    · exact (G.mem_neighborFinset x w).mpr hb
    · exact (G.mem_neighborFinset x w).mpr hc
  have hcard := Finset.card_le_card hs
  have he : ({a,b,c} : Finset V).card = 3 := Finset.card_triple_eq_three_iff.mpr ⟨hab,hac,hbc⟩
  rw [he] at hcard
  have hx := hG.1 x
  exact Nat.le_antisymm hx hcard

/-- In two triangles sharing an edge, the common endpoints have degree three
and both other vertices have degree two. This is the local diamond case. -/
theorem shared_edge_degrees {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (hG : TargetClass G)
    (u v a b : V) (huv : G.Adj u v) (hua : G.Adj u a) (hub : G.Adj u b)
    (hva : G.Adj v a) (hvb : G.Adj v b) (hab : a ≠ b) :
    G.degree u = 3 ∧ G.degree v = 3 ∧ G.degree a = 2 ∧ G.degree b = 2 := by
  have hu := three_neighbors_force_degree_three G hG u v a b huv hua hub hva.ne hvb.ne hab
  have hv := three_neighbors_force_degree_three G hG v u a b huv.symm hva hvb hua.ne hub.ne hab
  have ha := triangle_has_degree_two G hG u v a huv hva hua.symm
  have hb := triangle_has_degree_two G hG u v b huv hvb hub.symm
  exact ⟨hu, hv, by omega, by omega⟩

end Packing
