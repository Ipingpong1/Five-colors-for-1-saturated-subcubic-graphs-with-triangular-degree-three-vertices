import Packing.Graphs

namespace Packing.SmallGraphs

set_option maxRecDepth 100000

set_option maxHeartbeats 0

set_option cbv.maxSteps 10000000

namespace Diamond
def edges : List (Nat × Nat) := [(0,1),(0,2),(1,2),(1,3),(3,0)]
def graph : SimpleGraph (Fin 4) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin 4) : Nat := (#[3,2,1,1] : Array Nat)[v.val]!
def dist (u v : Fin 4) : Nat := (#[#[0,1,1,1],#[1,0,1,1],#[1,1,0,2],#[1,1,2,0]] : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ 4 := by decide_cbv
theorem colorable : PackingColorable graph 4 := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end Diamond

namespace GapThree
def edges : List (Nat × Nat) := [(0,1),(0,2),(1,2),(1,3),(3,4),(4,0)]
def graph : SimpleGraph (Fin 5) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin 5) : Nat := (#[4,3,1,2,1] : Array Nat)[v.val]!
def dist (u v : Fin 5) : Nat := (#[#[0,1,1,2,1],#[1,0,1,1,2],#[1,1,0,2,2],#[2,1,2,0,1],#[1,2,2,1,0]] : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ 4 := by decide_cbv
theorem colorable : PackingColorable graph 4 := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end GapThree

namespace GapFour
def edges : List (Nat × Nat) := [(0,1),(0,2),(1,2),(1,3),(3,4),(4,5),(5,0)]
def graph : SimpleGraph (Fin 6) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin 6) : Nat := (#[4,3,1,1,2,1] : Array Nat)[v.val]!
def dist (u v : Fin 6) : Nat := (#[#[0,1,1,2,2,1],#[1,0,1,1,2,2],#[1,1,0,2,3,2],#[2,1,2,0,1,2],#[2,2,3,1,0,1],#[1,2,2,2,1,0]] : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ 4 := by decide_cbv
theorem colorable : PackingColorable graph 4 := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end GapFour

namespace Barbell
def edges : List (Nat × Nat) := [(0,1),(0,2),(1,2),(2,3),(3,4),(3,5),(4,5)]
def graph : SimpleGraph (Fin 6) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin 6) : Nat := (#[3,2,1,4,2,1] : Array Nat)[v.val]!
def dist (u v : Fin 6) : Nat := (#[#[0,1,1,2,3,3],#[1,0,1,2,3,3],#[1,1,0,1,2,2],#[2,2,1,0,1,1],#[3,3,2,1,0,1],#[3,3,2,1,1,0]] : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ 4 := by decide_cbv
theorem colorable : PackingColorable graph 4 := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end Barbell

namespace SharpnessExample
def edges : List (Nat × Nat) := [(0,1),(0,2),(1,2),(1,9),(9,3),(3,4),(3,5),(4,5),(4,10),(10,6),(6,7),(6,8),(7,8),(7,11),(11,0)]
def graph : SimpleGraph (Fin 12) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin 12) : Nat := (#[5,2,1,4,2,1,3,2,1,1,1,1] : Array Nat)[v.val]!
def dist (u v : Fin 12) : Nat := (#[#[0,1,1,3,4,4,3,2,3,2,4,1],#[1,0,1,2,3,3,4,3,4,1,4,2],#[1,1,0,3,4,4,4,3,4,2,5,2],#[3,2,3,0,1,1,3,4,4,1,2,4],#[4,3,4,1,0,1,2,3,3,2,1,4],#[4,3,4,1,1,0,3,4,4,2,2,5],#[3,4,4,3,2,3,0,1,1,4,1,2],#[2,3,3,4,3,4,1,0,1,4,2,1],#[3,4,4,4,3,4,1,1,0,5,2,2],#[2,1,2,1,2,2,4,4,5,0,3,3],#[4,4,5,2,1,2,1,2,2,3,0,3],#[1,2,2,4,4,5,2,1,2,3,3,0]] : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ 5 := by decide_cbv
theorem colorable : PackingColorable graph 5 := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end SharpnessExample

#print axioms SharpnessExample.colorable
end Packing.SmallGraphs
