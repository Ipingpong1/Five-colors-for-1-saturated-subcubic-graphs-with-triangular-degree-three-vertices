import Packing.TriangleSelection
import Packing.ExceptionalComponents
import Packing.TipCycleReduction

namespace Packing
open SimpleGraph

/-- The connected structural reduction: overlapping triangles give a diamond;
otherwise delete disjoint degree-two tips. A cross-edge between distinct
triangle ports gives the barbell, and the remaining case is the general
maximum-degree-two backbone with separated marked edges. -/
theorem connected_target_colorable {V : Type*} [Fintype V]
    (G : SimpleGraph V) [DecidableRel G.Adj]
    (hG : TargetClass G) (hc : G.Connected) : PackingColorable G 5 := by
  classical
  by_cases hdiamond : ∀ u v a b, G.Adj u v → G.Adj u a → G.Adj u b →
      G.Adj v a → G.Adj v b → a = b
  · obtain ⟨D, htip, hdrop, hdisjoint⟩ := TriangleSelection.exists_data G hG hdiamond
    letI : Fintype D.tips := Fintype.ofFinite _
    by_cases hcross : ∃ s t : D.tips, s ≠ t ∧ ∃ u v,
        (u = D.left s ∨ u = D.right s) ∧
        (v = D.left t ∨ v = D.right t) ∧ G.Adj u v
    · obtain ⟨s,t,hst,u,v,hu,hv,huv⟩ := hcross
      exact (D.bridge_colorable hG hc hdisjoint s t hst u v hu hv huv).palette_mono (by decide)
    · apply D.colorable
      apply degree_two_tipped_colorable D.backbone (D.degree_le_two hG.1 hdrop)
        (D.connected hc) D.leftPort D.rightPort D.ports_edge
      · intro s t v hs ht
        apply hdisjoint s t v.val
        · rcases hs with hs | hs
          · exact Or.inl (congrArg Subtype.val hs)
          · exact Or.inr (congrArg Subtype.val hs)
        · rcases ht with ht | ht
          · exact Or.inl (congrArg Subtype.val ht)
          · exact Or.inr (congrArg Subtype.val ht)
      · intro s t hst u v hu hv huv
        apply hcross
        refine ⟨s,t,hst,u.val,v.val,?_,?_,huv⟩
        · rcases hu with hu | hu
          · exact Or.inl (congrArg Subtype.val hu)
          · exact Or.inr (congrArg Subtype.val hu)
        · rcases hv with hv | hv
          · exact Or.inl (congrArg Subtype.val hv)
          · exact Or.inr (congrArg Subtype.val hv)
  · push_neg at hdiamond
    obtain ⟨u,v,a,b,huv,hua,hub,hva,hvb,hab⟩ := hdiamond
    exact (connected_shared_edge_colorable G hG hc u v a b huv hua hub hva hvb hab).palette_mono
      (by decide)

end Packing
