import Packing.BitMatrix

namespace Packing

def BitMatrix.rowMul (row : Nat) (Q : BitMatrix n) : Nat :=
  orList ((List.finRange n).map fun k => if row.testBit k.val then Q[k.val] else 0)

/-- Pulling a row outside the inner closure lets evaluation share work for
repeated rows. The next theorem proves this optimization preserves the matrix. -/
def BitMatrix.fastMul (P Q : BitMatrix n) : BitMatrix n :=
  P.map (fun row => BitMatrix.rowMul row Q)

theorem BitMatrix.fastMul_eq (P Q : BitMatrix n) : P.fastMul Q = P.mul Q := by
  apply Vector.ext
  intro i hi
  simp only [fastMul, mul, Vector.getElem_map, Vector.getElem_ofFn, rowMul]

theorem BitMatrix.fastMul_spec (P Q : BitMatrix n) :
    (P.fastMul Q).denote = P.denote.comp Q.denote := by
  rw [fastMul_eq, mul_spec]

end Packing
