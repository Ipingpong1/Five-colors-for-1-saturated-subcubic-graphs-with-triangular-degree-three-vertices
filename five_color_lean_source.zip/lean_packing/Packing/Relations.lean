import Std

/-! Abstract certificate argument. No finite calculation is assumed in the
definitions. The hypotheses of each theorem expose exactly what a concrete
certificate must establish. Composition is in traversal order. -/
namespace Packing

abbrev Rel (α : Type) := α → α → Prop
def Rel.comp (P Q : Rel α) : Rel α := fun a c => ∃ b, P a b ∧ Q b c
def Rel.ident : Rel α := fun a b => a = b
def Rel.Included (P Q : Rel α) : Prop := ∀ a b, P a b → Q a b
def Rel.Diagonal (P : Rel α) : Prop := ∃ a, P a a

theorem Rel.comp_mono {P Q R S : Rel α}
    (h : P.Included Q) (k : R.Included S) :
    (P.comp R).Included (Q.comp S) := by
  intro a c ⟨b, hab, hbc⟩
  exact ⟨b, h a b hab, k b c hbc⟩

theorem Rel.included_trans {P Q R : Rel α}
    (h : P.Included Q) (k : Q.Included R) : P.Included R :=
  fun a b hab => k a b (h a b hab)

theorem Rel.diagonal_mono {P Q : Rel α}
    (h : P.Included Q) (k : P.Diagonal) : Q.Diagonal := by
  obtain ⟨a, ha⟩ := k
  exact ⟨a, h a a ha⟩

theorem Rel.comp_assoc (P Q R : Rel α) :
    (P.comp Q).comp R = P.comp (Q.comp R) := by
  funext a d
  apply propext
  constructor
  · rintro ⟨c, ⟨b, hab, hbc⟩, hcd⟩
    exact ⟨b, hab, c, hbc, hcd⟩
  · rintro ⟨b, hab, c, hbc, hcd⟩
    exact ⟨c, ⟨b, hab, hbc⟩, hcd⟩

theorem Rel.ident_comp (P : Rel α) : Rel.ident.comp P = P := by
  funext a b
  apply propext
  constructor
  · rintro ⟨c, rfl, h⟩; exact h
  · intro h; exact ⟨a, rfl, h⟩

def extend (R : γ → Rel α) : Rel α → List γ → Rel α
  | P, [] => P
  | P, g :: gs => extend R (P.comp (R g)) gs

def product (R : γ → Rel α) (gs : List γ) : Rel α :=
  extend R Rel.ident gs

def Covered (M : ι → Rel α) (P : Rel α) : Prop :=
  ∃ i, (M i).Included P

theorem covered_step (M : ι → Rel α) (R : γ → Rel α)
    (closed : ∀ i g, Covered M ((M i).comp (R g)))
    {P : Rel α} (h : Covered M P) (g : γ) :
    Covered M (P.comp (R g)) := by
  obtain ⟨i, hi⟩ := h
  obtain ⟨j, hj⟩ := closed i g
  exact ⟨j, Rel.included_trans hj (Rel.comp_mono hi (fun _ _ h => h))⟩

theorem covered_extend (M : ι → Rel α) (R : γ → Rel α)
    (closed : ∀ i g, Covered M ((M i).comp (R g)))
    (gs : List γ) {P : Rel α} (h : Covered M P) :
    Covered M (extend R P gs) := by
  induction gs generalizing P with
  | nil => exact h
  | cons g gs ih => exact ih (covered_step M R closed h g)

theorem covered_diagonal (M : ι → Rel α)
    (diagonal : ∀ i, (M i).Diagonal) {P : Rel α}
    (h : Covered M P) : P.Diagonal := by
  obtain ⟨i, hi⟩ := h
  exact Rel.diagonal_mono hi (diagonal i)

/-- The universal closure conclusion for every word with at least two letters. -/
theorem every_two_letter_extension_diagonal
    (M : ι → Rel α) (R : γ → Rel α)
    (diagonal : ∀ i, (M i).Diagonal)
    (seeds : ∀ g h, Covered M ((R g).comp (R h)))
    (closed : ∀ i g, Covered M ((M i).comp (R g)))
    (g h : γ) (tail : List γ) :
    (product R (g :: h :: tail)).Diagonal := by
  simp only [product, extend, Rel.ident_comp]
  exact covered_diagonal M diagonal
    (covered_extend M R closed tail (seeds g h))

theorem every_one_letter_seed_diagonal
    (M : ι → Rel α) (R : γ → Rel α)
    (diagonal : ∀ i, (M i).Diagonal)
    (g : γ) (seed : Covered M (R g)) :
    (product R [g]).Diagonal := by
  simp only [product, extend, Rel.ident_comp]
  exact covered_diagonal M diagonal seed

def Rel.power (B : Rel α) : Nat → Rel α
  | 0 => Rel.ident
  | n + 1 => (B.power n).comp B

/-- A single consecutive equality certifies stabilization at every larger power. -/
theorem Rel.power_stable (B : Rel α) (k : Nat)
    (h : B.power k = B.power (k + 1)) (n : Nat) :
    B.power (k + n) = B.power k := by
  induction n with
  | zero => simp
  | succ n ih =>
    change (B.power (k + n)).comp B = B.power k
    rw [ih]
    exact h.symm

theorem Rel.power_stable_of_le (B : Rel α) (k n : Nat)
    (h : B.power k = B.power (k + 1)) (hn : k ≤ n) :
    B.power n = B.power k := by
  have e : k + (n - k) = n := by omega
  simpa only [e] using B.power_stable k h (n - k)

theorem extend_map (R : γ → Rel α) (T : δ → Rel α) (f : γ → δ)
    (h : ∀ g, R g = T (f g)) (P : Rel α) (gs : List γ) :
    extend R P gs = extend T P (gs.map f) := by
  induction gs generalizing P with
  | nil => rfl
  | cons g gs ih =>
    simp only [extend, List.map_cons]
    rw [h g]
    exact ih _

end Packing
