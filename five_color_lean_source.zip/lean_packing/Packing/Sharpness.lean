import Packing.SmallGraphs
namespace Packing.SmallGraphs.SharpnessExample
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem short_0_1 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 1) : c 0 < 1 := by
  have h := hp 0 1 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.nil : graph.Walk 1 1))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_2 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 2) : c 0 < 1 := by
  have h := hp 0 2 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 2) (SimpleGraph.Walk.nil : graph.Walk 2 2))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_3 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 3) : c 0 < 3 := by
  have h := hp 0 3 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.nil : graph.Walk 3 3))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_4 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 4) : c 0 < 4 := by
  have h := hp 0 4 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.nil : graph.Walk 4 4)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_5 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 5) : c 0 < 4 := by
  have h := hp 0 5 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 5) (SimpleGraph.Walk.nil : graph.Walk 5 5)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 6) : c 0 < 3 := by
  have h := hp 0 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 6) (SimpleGraph.Walk.nil : graph.Walk 6 6))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 7) : c 0 < 2 := by
  have h := hp 0 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.nil : graph.Walk 7 7)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 8) : c 0 < 3 := by
  have h := hp 0 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 8) (SimpleGraph.Walk.nil : graph.Walk 8 8))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 9) : c 0 < 2 := by
  have h := hp 0 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 10) : c 0 < 4 := by
  have h := hp 0 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_0_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 0 = c 11) : c 0 < 1 := by
  have h := hp 0 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.nil : graph.Walk 11 11))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_2 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 2) : c 1 < 1 := by
  have h := hp 1 2 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 2) (SimpleGraph.Walk.nil : graph.Walk 2 2))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_3 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 3) : c 1 < 2 := by
  have h := hp 1 3 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.nil : graph.Walk 3 3)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_4 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 4) : c 1 < 3 := by
  have h := hp 1 4 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.nil : graph.Walk 4 4))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_5 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 5) : c 1 < 3 := by
  have h := hp 1 5 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 5) (SimpleGraph.Walk.nil : graph.Walk 5 5))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 6) : c 1 < 4 := by
  have h := hp 1 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 6) (SimpleGraph.Walk.nil : graph.Walk 6 6)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 7) : c 1 < 3 := by
  have h := hp 1 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.nil : graph.Walk 7 7))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 8) : c 1 < 4 := by
  have h := hp 1 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 8) (SimpleGraph.Walk.nil : graph.Walk 8 8)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 9) : c 1 < 1 := by
  have h := hp 1 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.nil : graph.Walk 9 9))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 10) : c 1 < 4 := by
  have h := hp 1 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_1_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 1 = c 11) : c 1 < 2 := by
  have h := hp 1 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_3 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 3) : c 2 < 3 := by
  have h := hp 2 3 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.nil : graph.Walk 3 3))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_4 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 4) : c 2 < 4 := by
  have h := hp 2 4 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.nil : graph.Walk 4 4)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_5 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 5) : c 2 < 4 := by
  have h := hp 2 5 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 5) (SimpleGraph.Walk.nil : graph.Walk 5 5)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 6) : c 2 < 4 := by
  have h := hp 2 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 6) (SimpleGraph.Walk.nil : graph.Walk 6 6)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 7) : c 2 < 3 := by
  have h := hp 2 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.nil : graph.Walk 7 7))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 8) : c 2 < 4 := by
  have h := hp 2 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 8) (SimpleGraph.Walk.nil : graph.Walk 8 8)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 9) : c 2 < 2 := by
  have h := hp 2 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_2_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 2 = c 11) : c 2 < 2 := by
  have h := hp 2 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 2 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_4 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 4) : c 3 < 1 := by
  have h := hp 3 4 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.nil : graph.Walk 4 4))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_5 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 5) : c 3 < 1 := by
  have h := hp 3 5 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 5) (SimpleGraph.Walk.nil : graph.Walk 5 5))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 6) : c 3 < 3 := by
  have h := hp 3 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.nil : graph.Walk 6 6))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 7) : c 3 < 4 := by
  have h := hp 3 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.nil : graph.Walk 7 7)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 8) : c 3 < 4 := by
  have h := hp 3 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 8) (SimpleGraph.Walk.nil : graph.Walk 8 8)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 9) : c 3 < 1 := by
  have h := hp 3 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 9) (SimpleGraph.Walk.nil : graph.Walk 9 9))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 10) : c 3 < 2 := by
  have h := hp 3 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_3_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 3 = c 11) : c 3 < 4 := by
  have h := hp 3 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 3 9) (SimpleGraph.Walk.cons (by decide : graph.Adj 9 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_5 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 5) : c 4 < 1 := by
  have h := hp 4 5 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 5) (SimpleGraph.Walk.nil : graph.Walk 5 5))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 6) : c 4 < 2 := by
  have h := hp 4 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.nil : graph.Walk 6 6)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 7) : c 4 < 3 := by
  have h := hp 4 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.nil : graph.Walk 7 7))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 8) : c 4 < 3 := by
  have h := hp 4 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 8) (SimpleGraph.Walk.nil : graph.Walk 8 8))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 9) : c 4 < 2 := by
  have h := hp 4 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 10) : c 4 < 1 := by
  have h := hp 4 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.nil : graph.Walk 10 10))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_4_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 4 = c 11) : c 4 < 4 := by
  have h := hp 4 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_5_6 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 5 = c 6) : c 5 < 3 := by
  have h := hp 5 6 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 5 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.nil : graph.Walk 6 6))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_5_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 5 = c 7) : c 5 < 4 := by
  have h := hp 5 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 5 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.nil : graph.Walk 7 7)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_5_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 5 = c 8) : c 5 < 4 := by
  have h := hp 5 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 5 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 8) (SimpleGraph.Walk.nil : graph.Walk 8 8)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_5_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 5 = c 9) : c 5 < 2 := by
  have h := hp 5 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 5 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_5_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 5 = c 10) : c 5 < 2 := by
  have h := hp 5 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 5 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_6_7 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 6 = c 7) : c 6 < 1 := by
  have h := hp 6 7 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.nil : graph.Walk 7 7))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_6_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 6 = c 8) : c 6 < 1 := by
  have h := hp 6 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 6 8) (SimpleGraph.Walk.nil : graph.Walk 8 8))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_6_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 6 = c 9) : c 6 < 4 := by
  have h := hp 6 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 6 10) (SimpleGraph.Walk.cons (by decide : graph.Adj 10 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_6_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 6 = c 10) : c 6 < 1 := by
  have h := hp 6 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 6 10) (SimpleGraph.Walk.nil : graph.Walk 10 10))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_6_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 6 = c 11) : c 6 < 2 := by
  have h := hp 6 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_7_8 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 7 = c 8) : c 7 < 1 := by
  have h := hp 7 8 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 7 8) (SimpleGraph.Walk.nil : graph.Walk 8 8))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_7_9 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 7 = c 9) : c 7 < 4 := by
  have h := hp 7 9 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.cons (by decide : graph.Adj 11 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 9) (SimpleGraph.Walk.nil : graph.Walk 9 9)))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_7_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 7 = c 10) : c 7 < 2 := by
  have h := hp 7 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 7 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_7_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 7 = c 11) : c 7 < 1 := by
  have h := hp 7 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.nil : graph.Walk 11 11))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_8_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 8 = c 10) : c 8 < 2 := by
  have h := hp 8 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 8 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 10) (SimpleGraph.Walk.nil : graph.Walk 10 10)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_8_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 8 = c 11) : c 8 < 2 := by
  have h := hp 8 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 8 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.nil : graph.Walk 11 11)))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_9_10 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 9 = c 10) : c 9 < 3 := by
  have h := hp 9 10 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 9 3) (SimpleGraph.Walk.cons (by decide : graph.Adj 3 4) (SimpleGraph.Walk.cons (by decide : graph.Adj 4 10) (SimpleGraph.Walk.nil : graph.Walk 10 10))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_9_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 9 = c 11) : c 9 < 3 := by
  have h := hp 9 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 9 1) (SimpleGraph.Walk.cons (by decide : graph.Adj 1 0) (SimpleGraph.Walk.cons (by decide : graph.Adj 0 11) (SimpleGraph.Walk.nil : graph.Walk 11 11))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem short_10_11 (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c 10 = c 11) : c 10 < 3 := by
  have h := hp 10 11 (by decide) he (SimpleGraph.Walk.cons (by decide : graph.Adj 10 6) (SimpleGraph.Walk.cons (by decide : graph.Adj 6 7) (SimpleGraph.Walk.cons (by decide : graph.Adj 7 11) (SimpleGraph.Walk.nil : graph.Walk 11 11))))
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h
theorem four_cases (n : Nat) (h : 1 ≤ n ∧ n ≤ 4) : n = 1 ∨ n = 2 ∨ n = 3 ∨ n = 4 := by omega
theorem not_four_colorable : ¬ PackingColorable graph 4 := by
  rintro ⟨c, hb, hp⟩
  rcases four_cases (c 0) (hb 0) with h0 | h0 | h0 | h0
  ·
    rcases four_cases (c 1) (hb 1) with h1 | h1 | h1 | h1
    · have h := short_0_1 c hp (h0.trans h1.symm)
      rw [h0] at h
      exact (by decide : ¬ (1 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_9_10 c hp (h9.trans h10.symm)
                        rw [h9] at h
                        exact (by decide : ¬ (4 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (2 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_6_11 c hp (h6.trans h11.symm)
                          rw [h6] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_3_11 c hp (h3.trans h11.symm)
                          rw [h3] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_6_11 c hp (h6.trans h11.symm)
                          rw [h6] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_3_11 c hp (h3.trans h11.symm)
                          rw [h3] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_6_11 c hp (h6.trans h11.symm)
                          rw [h6] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_4_11 c hp (h4.trans h11.symm)
                          rw [h4] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_4_11 c hp (h4.trans h11.symm)
                          rw [h4] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_4_11 c hp (h4.trans h11.symm)
                          rw [h4] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (3 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_3_11 c hp (h3.trans h11.symm)
                          rw [h3] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_3_11 c hp (h3.trans h11.symm)
                          rw [h3] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (4 < 2)) h
  ·
    rcases four_cases (c 1) (hb 1) with h1 | h1 | h1 | h1
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_9_10 c hp (h9.trans h10.symm)
                        rw [h9] at h
                        exact (by decide : ¬ (4 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_2_11 c hp (h2.trans h11.symm)
                          rw [h2] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    · have h := short_0_1 c hp (h0.trans h1.symm)
      rw [h0] at h
      exact (by decide : ¬ (2 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_4_11 c hp (h4.trans h11.symm)
                          rw [h4] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_4_11 c hp (h4.trans h11.symm)
                          rw [h4] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (4 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (3 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (2 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (3 < 2)) h
                        · have h := short_3_11 c hp (h3.trans h11.symm)
                          rw [h3] at h
                          exact (by decide : ¬ (4 < 4)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (4 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (2 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_1_10 c hp (h1.trans h10.symm)
                        rw [h1] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (4 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (4 < 2)) h
  ·
    rcases four_cases (c 1) (hb 1) with h1 | h1 | h1 | h1
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_6_11 c hp (h6.trans h11.symm)
                          rw [h6] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_6_11 c hp (h6.trans h11.symm)
                          rw [h6] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (3 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      ·
                        rcases four_cases (c 11) (hb 11) with h11 | h11 | h11 | h11
                        · have h := short_7_11 c hp (h7.trans h11.symm)
                          rw [h7] at h
                          exact (by decide : ¬ (1 < 1)) h
                        · have h := short_1_11 c hp (h1.trans h11.symm)
                          rw [h1] at h
                          exact (by decide : ¬ (2 < 2)) h
                        · have h := short_0_11 c hp (h0.trans h11.symm)
                          rw [h0] at h
                          exact (by decide : ¬ (3 < 1)) h
                        · have h := short_8_11 c hp (h8.trans h11.symm)
                          rw [h8] at h
                          exact (by decide : ¬ (4 < 2)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (3 < 1)) h
                      · have h := short_8_10 c hp (h8.trans h10.symm)
                        rw [h8] at h
                        exact (by decide : ¬ (4 < 2)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_5_8 c hp (h5.trans h8.symm)
                    rw [h5] at h
                    exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_2_8 c hp (h2.trans h8.symm)
                    rw [h2] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_2_5 c hp (h2.trans h5.symm)
                  rw [h2] at h
                  exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_7_9 c hp (h7.trans h9.symm)
                      rw [h7] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_7 c hp (h5.trans h7.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_6_9 c hp (h6.trans h9.symm)
                      rw [h6] at h
                      exact (by decide : ¬ (4 < 4)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (4 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_6 c hp (h2.trans h6.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (4 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_4 c hp (h2.trans h4.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 4)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (4 < 2)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (2 < 2)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (3 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_3_8 c hp (h3.trans h8.symm)
                    rw [h3] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (4 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (4 < 3)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_3_7 c hp (h3.trans h7.symm)
              rw [h3] at h
              exact (by decide : ¬ (4 < 4)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (4 < 1)) h
    · have h := short_0_1 c hp (h0.trans h1.symm)
      rw [h0] at h
      exact (by decide : ¬ (3 < 1)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_1_8 c hp (h1.trans h8.symm)
                    rw [h1] at h
                    exact (by decide : ¬ (4 < 4)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (4 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (3 < 2)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (4 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_1_6 c hp (h1.trans h6.symm)
            rw [h1] at h
            exact (by decide : ¬ (4 < 4)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (4 < 3)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (3 < 3)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (4 < 2)) h
  ·
    rcases four_cases (c 1) (hb 1) with h1 | h1 | h1 | h1
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (1 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_4_9 c hp (h4.trans h9.symm)
                      rw [h4] at h
                      exact (by decide : ¬ (2 < 2)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (4 < 3)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_2_9 c hp (h2.trans h9.symm)
                      rw [h2] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (1 < 1)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_5_9 c hp (h5.trans h9.symm)
                      rw [h5] at h
                      exact (by decide : ¬ (3 < 2)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_7 c hp (h2.trans h7.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_5_6 c hp (h5.trans h6.symm)
                  rw [h5] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (3 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_4_8 c hp (h4.trans h8.symm)
                    rw [h4] at h
                    exact (by decide : ¬ (3 < 3)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_4_7 c hp (h4.trans h7.symm)
              rw [h4] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (3 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (2 < 2)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_7_10 c hp (h7.trans h10.symm)
                        rw [h7] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_5_10 c hp (h5.trans h10.symm)
                        rw [h5] at h
                        exact (by decide : ¬ (2 < 2)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (2 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (2 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                ·
                  rcases four_cases (c 8) (hb 8) with h8 | h8 | h8 | h8
                  · have h := short_6_8 c hp (h6.trans h8.symm)
                    rw [h6] at h
                    exact (by decide : ¬ (1 < 1)) h
                  ·
                    rcases four_cases (c 9) (hb 9) with h9 | h9 | h9 | h9
                    ·
                      rcases four_cases (c 10) (hb 10) with h10 | h10 | h10 | h10
                      · have h := short_6_10 c hp (h6.trans h10.symm)
                        rw [h6] at h
                        exact (by decide : ¬ (1 < 1)) h
                      · have h := short_4_10 c hp (h4.trans h10.symm)
                        rw [h4] at h
                        exact (by decide : ¬ (2 < 1)) h
                      · have h := short_3_10 c hp (h3.trans h10.symm)
                        rw [h3] at h
                        exact (by decide : ¬ (3 < 2)) h
                      · have h := short_0_10 c hp (h0.trans h10.symm)
                        rw [h0] at h
                        exact (by decide : ¬ (4 < 4)) h
                    · have h := short_1_9 c hp (h1.trans h9.symm)
                      rw [h1] at h
                      exact (by decide : ¬ (2 < 1)) h
                    · have h := short_3_9 c hp (h3.trans h9.symm)
                      rw [h3] at h
                      exact (by decide : ¬ (3 < 1)) h
                    · have h := short_0_9 c hp (h0.trans h9.symm)
                      rw [h0] at h
                      exact (by decide : ¬ (4 < 2)) h
                  · have h := short_7_8 c hp (h7.trans h8.symm)
                    rw [h7] at h
                    exact (by decide : ¬ (3 < 1)) h
                  · have h := short_0_8 c hp (h0.trans h8.symm)
                    rw [h0] at h
                    exact (by decide : ¬ (4 < 3)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (3 < 1)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (2 < 1)) h
              · have h := short_2_3 c hp (h2.trans h3.symm)
                rw [h2] at h
                exact (by decide : ¬ (3 < 3)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          · have h := short_3_6 c hp (h3.trans h6.symm)
            rw [h3] at h
            exact (by decide : ¬ (3 < 3)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (3 < 1)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (4 < 3)) h
    ·
      rcases four_cases (c 3) (hb 3) with h3 | h3 | h3 | h3
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (1 < 1)) h
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_4_6 c hp (h4.trans h6.symm)
            rw [h4] at h
            exact (by decide : ¬ (2 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      ·
        rcases four_cases (c 4) (hb 4) with h4 | h4 | h4 | h4
        ·
          rcases four_cases (c 6) (hb 6) with h6 | h6 | h6 | h6
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (1 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_6_7 c hp (h6.trans h7.symm)
              rw [h6] at h
              exact (by decide : ¬ (2 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          ·
            rcases four_cases (c 7) (hb 7) with h7 | h7 | h7 | h7
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            ·
              rcases four_cases (c 2) (hb 2) with h2 | h2 | h2 | h2
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              ·
                rcases four_cases (c 5) (hb 5) with h5 | h5 | h5 | h5
                · have h := short_4_5 c hp (h4.trans h5.symm)
                  rw [h4] at h
                  exact (by decide : ¬ (1 < 1)) h
                · have h := short_3_5 c hp (h3.trans h5.symm)
                  rw [h3] at h
                  exact (by decide : ¬ (2 < 1)) h
                · have h := short_1_5 c hp (h1.trans h5.symm)
                  rw [h1] at h
                  exact (by decide : ¬ (3 < 3)) h
                · have h := short_0_5 c hp (h0.trans h5.symm)
                  rw [h0] at h
                  exact (by decide : ¬ (4 < 4)) h
              · have h := short_1_2 c hp (h1.trans h2.symm)
                rw [h1] at h
                exact (by decide : ¬ (3 < 1)) h
              · have h := short_0_2 c hp (h0.trans h2.symm)
                rw [h0] at h
                exact (by decide : ¬ (4 < 1)) h
            · have h := short_1_7 c hp (h1.trans h7.symm)
              rw [h1] at h
              exact (by decide : ¬ (3 < 3)) h
            · have h := short_0_7 c hp (h0.trans h7.symm)
              rw [h0] at h
              exact (by decide : ¬ (4 < 2)) h
          · have h := short_0_6 c hp (h0.trans h6.symm)
            rw [h0] at h
            exact (by decide : ¬ (4 < 3)) h
        · have h := short_3_4 c hp (h3.trans h4.symm)
          rw [h3] at h
          exact (by decide : ¬ (2 < 1)) h
        · have h := short_1_4 c hp (h1.trans h4.symm)
          rw [h1] at h
          exact (by decide : ¬ (3 < 3)) h
        · have h := short_0_4 c hp (h0.trans h4.symm)
          rw [h0] at h
          exact (by decide : ¬ (4 < 4)) h
      · have h := short_1_3 c hp (h1.trans h3.symm)
        rw [h1] at h
        exact (by decide : ¬ (3 < 2)) h
      · have h := short_0_3 c hp (h0.trans h3.symm)
        rw [h0] at h
        exact (by decide : ¬ (4 < 3)) h
    · have h := short_0_1 c hp (h0.trans h1.symm)
      rw [h0] at h
      exact (by decide : ¬ (4 < 1)) h
#print axioms not_four_colorable
end Packing.SmallGraphs.SharpnessExample
