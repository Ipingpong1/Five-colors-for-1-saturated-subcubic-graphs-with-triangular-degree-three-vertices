import Packing.Data
namespace Packing.Automaton
open Data
def boundaryMap (i : Fin 171) : Fin 390 := boundary[i.val]

def gap (g : Nat) : Rel (Fin 171) := fun i j =>
  (((B.denote.power (g-1)).comp A.denote).comp A.denote)
    (boundaryMap i) (boundaryMap j)

end Packing.Automaton
