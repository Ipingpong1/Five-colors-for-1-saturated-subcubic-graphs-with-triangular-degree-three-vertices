import Packing.Cycles
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected
import Mathlib.Combinatorics.SimpleGraph.Paths

/-! Connected finite graphs of maximum degree two have a spanning path. Its
vertex order contains every graph edge, with at most the additional edge
joining the endpoints. -/
namespace Packing
open SimpleGraph

/-- In a vertex of degree at most two, two distinct neighbors exhaust all neighbors. -/
theorem degree_two_neighbors {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] {v a b w : V} (hd : G.degree v ≤ 2)
    (ha : G.Adj v a) (hb : G.Adj v b) (hab : a ≠ b) (hw : G.Adj v w) :
    w = a ∨ w = b := by
  classical
  by_contra h
  have hwa : w ≠ a := fun hh => h (Or.inl hh)
  have hwb : w ≠ b := fun hh => h (Or.inr hh)
  have hs : ({a,b,w} : Finset V) ⊆ G.neighborFinset v := by
    intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl | rfl
    · exact (G.mem_neighborFinset v x).mpr ha
    · exact (G.mem_neighborFinset v x).mpr hb
    · exact (G.mem_neighborFinset v x).mpr hw
  have hc := Finset.card_le_card hs
  rw [Finset.card_triple_eq_three_iff.mpr ⟨hab,hwa.symm,hwb.symm⟩] at hc
  change 3 ≤ G.degree v at hc
  omega

/-- Every neighbor of an internal path vertex is one of its two path neighbors. -/
theorem path_internal_neighbors {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2)
    {u v : V} (p : G.Walk u v) (hp : p.IsPath) (i : Nat)
    (hi : 0 < i) (hi' : i < p.length) {w : V} (hw : G.Adj (p.getVert i) w) :
    w = p.getVert (i-1) ∨ w = p.getVert (i+1) := by
  apply degree_two_neighbors G (hd (p.getVert i)) ?_ (p.adj_getVert_succ hi') ?_ hw
  · have ha := (p.adj_getVert_succ (show i-1 < p.length by omega)).symm
    simpa only [show i-1+1 = i by omega] using ha
  · intro he
    have hn := hp.getVert_injOn (show i-1 ≤ p.length by omega)
      (show i+1 ≤ p.length by omega) he
    omega

/-- The support of a longest path is closed under taking graph neighbors. -/
theorem longest_path_neighbor_closed {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2)
    {u v : V} (p : G.Walk u v) (hp : p.IsPath)
    (hmax : ∀ a b (q : G.Walk a b), q.IsPath → q.length ≤ p.length)
    {x y : V} (hx : x ∈ p.support) (hxy : G.Adj x y) : y ∈ p.support := by
  by_contra hy
  obtain ⟨i, hix, hi⟩ := Walk.mem_support_iff_exists_getVert.mp hx
  by_cases hi0 : i = 0
  · subst i
    simp only [Walk.getVert_zero] at hix
    subst x
    have hm := hmax y v (p.cons hxy.symm) (hp.cons hy)
    simp only [Walk.length_cons] at hm
    omega
  · by_cases hie : i = p.length
    · subst i
      simp only [Walk.getVert_length] at hix
      subst x
      have hm := hmax u y (p.concat hxy) (hp.concat hy hxy)
      simp only [Walk.length_concat] at hm
      omega
    · have hs := path_internal_neighbors G hd p hp i (by omega) (by omega)
        (hix ▸ hxy)
      rcases hs with hs | hs
      · exact hy (hs ▸ p.getVert_mem_support (i-1))
      · exact hy (hs ▸ p.getVert_mem_support (i+1))

/-- A longest path in a connected graph of maximum degree two visits every vertex. -/
theorem degree_two_spanning_path {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2) (hconn : G.Connected) :
    ∃ u v, ∃ p : G.Walk u v, p.IsPath ∧ ∀ w, w ∈ p.support := by
  classical
  let : Nonempty V := hconn.nonempty
  obtain ⟨u,v,p,hp,hmax⟩ := Walk.exists_isPath_forall_isPath_length_le_length G
  refine ⟨u,v,p,hp,?_⟩
  have propagate {a b : V} (q : G.Walk a b) (ha : a ∈ p.support) : b ∈ p.support := by
    induction q with
    | nil => exact ha
    | @cons a b c hab q ih =>
      exact ih (longest_path_neighbor_closed G hd p hp hmax ha hab)
  intro w
  exact (hconn.preconnected u w).elim fun q => propagate q p.start_mem_support

/-- In path coordinates, the only edges are consecutive or join the endpoints. -/
theorem degree_two_path_edges {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2)
    {u v : V} (p : G.Walk u v) (hp : p.IsPath) (i j : Fin (p.length+1))
    (hij : G.Adj (p.getVert i.val) (p.getVert j.val)) :
    i.val+1 = j.val ∨ j.val+1 = i.val ∨
      (i.val = 0 ∧ j.val = p.length) ∨ (j.val = 0 ∧ i.val = p.length) := by
  have hi := i.isLt
  have hj := j.isLt
  have hne : i.val ≠ j.val := fun he => hij.ne (congrArg p.getVert he)
  by_cases hio : 0 < i.val ∧ i.val < p.length
  · rcases path_internal_neighbors G hd p hp i.val hio.1 hio.2 hij with he | he
    · have he' := hp.getVert_injOn (show j.val ≤ p.length by omega)
        (show i.val-1 ≤ p.length by omega) he
      exact Or.inr (Or.inl (by omega))
    · have he' := hp.getVert_injOn (show j.val ≤ p.length by omega)
        (show i.val+1 ≤ p.length by omega) he
      exact Or.inl he'.symm
  · by_cases hjo : 0 < j.val ∧ j.val < p.length
    · rcases path_internal_neighbors G hd p hp j.val hjo.1 hjo.2 hij.symm with he | he
      · have he' := hp.getVert_injOn (show i.val ≤ p.length by omega)
          (show j.val-1 ≤ p.length by omega) he
        exact Or.inl (by omega)
      · have he' := hp.getVert_injOn (show i.val ≤ p.length by omega)
          (show j.val+1 ≤ p.length by omega) he
        exact Or.inr (Or.inl he'.symm)
    · omega

/-- An ordering of all vertices with consecutive edges and no possible chords.
This retains actual consecutive edges as well as the embedding into a cycle. -/
theorem degree_two_vertex_order {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2) (hconn : G.Connected) :
    ∃ (n : Nat) (hn : 0 < n) (e : Fin n ≃ V),
      (∀ i j : Fin n, i.val+1 = j.val → G.Adj (e i) (e j)) ∧
      (∀ i j : Fin n, G.Adj (e i) (e j) → (backboneCycle n).Adj i j) := by
  classical
  obtain ⟨u,v,p,hp,hspan⟩ := degree_two_spanning_path G hd hconn
  let f : Fin (p.length+1) → V := fun i => p.getVert i.val
  have hf : Function.Bijective f := by
    constructor
    · intro i j hij
      exact Fin.ext (hp.getVert_injOn (show i.val ≤ p.length by omega)
        (show j.val ≤ p.length by omega) hij)
    · intro w
      obtain ⟨i,hi,hib⟩ := Walk.mem_support_iff_exists_getVert.mp (hspan w)
      exact ⟨⟨i,by omega⟩,hi⟩
  let e := Equiv.ofBijective f hf
  refine ⟨p.length+1, by omega, e, ?_, ?_⟩
  · intro i j hij
    change G.Adj (p.getVert i.val) (p.getVert j.val)
    rw [← hij]
    exact p.adj_getVert_succ (by have := j.isLt; omega)
  · intro i j hij
    have he := degree_two_path_edges G hd p hp i j hij
    change i ≠ j ∧ ((i.val + 1 = j.val ∨ (i.val+1 = p.length+1 ∧ j.val=0)) ∨
      (j.val+1 = i.val ∨ (j.val+1 = p.length+1 ∧ i.val=0)))
    constructor
    · intro hh
      exact hij.ne (congrArg e hh)
    · rcases he with he | he | ⟨hi,hj⟩ | ⟨hj,hi⟩
      · exact Or.inl (Or.inl he)
      · exact Or.inr (Or.inl he)
      · exact Or.inr (Or.inr ⟨by omega,hi⟩)
      · exact Or.inl (Or.inr ⟨by omega,hj⟩)

/-- Every connected finite maximum-degree-two graph embeds in a cycle. -/
theorem degree_two_cycle_embedding {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (hd : ∀ v, G.degree v ≤ 2) (hconn : G.Connected) :
    ∃ (n : Nat) (hn : 0 < n) (f : G →g backboneCycle n), Function.Bijective f := by
  obtain ⟨n,hn,e,hstep,hedge⟩ := degree_two_vertex_order G hd hconn
  let f : G →g backboneCycle n :=
    { toFun := e.symm
      map_rel' := by
        intro u v huv
        apply hedge
        simpa only [Equiv.apply_symm_apply] using huv }
  exact ⟨n,hn,f,e.symm.bijective⟩

end Packing
