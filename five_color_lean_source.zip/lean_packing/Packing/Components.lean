import Packing.Graphs
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Finite

/-! Packing colorings and the target hypotheses assemble over connected components.
These lemmas reduce the global theorem to its connected case without changing distances. -/
namespace Packing
open SimpleGraph

/-- Graph isomorphisms preserve packing colorability. -/
theorem PackingColorable.of_iso {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    {k : ℕ} (hc : PackingColorable H k) (e : G ≃g H) : PackingColorable G k :=
  hc.pullback e.toHom e.injective

theorem PackingColorable.iff_iso {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    {k : ℕ} (e : G ≃g H) : PackingColorable G k ↔ PackingColorable H k :=
  ⟨fun h => h.of_iso e.symm, fun h => h.of_iso e⟩

/-- Restrict a walk to its connected component, retaining the exact walk length. -/
def componentWalk {V : Type*} {G : SimpleGraph V} (C : G.ConnectedComponent) :
    {u v : V} → (p : G.Walk u v) → (hu : u ∈ C) → (hv : v ∈ C) →
      C.toSimpleGraph.Walk ⟨u, hu⟩ ⟨v, hv⟩
  | _, _, .nil, _, _ => .nil
  | _, _, .cons hab p, hu, hv =>
    .cons (show C.toSimpleGraph.Adj ⟨_, hu⟩
        ⟨_, C.mem_supp_of_adj_mem_supp hu hab⟩ from hab)
      (componentWalk C p (C.mem_supp_of_adj_mem_supp hu hab) hv)

@[simp] theorem componentWalk_length {V : Type*} {G : SimpleGraph V}
    (C : G.ConnectedComponent) {u v : V} (p : G.Walk u v) (hu : u ∈ C) (hv : v ∈ C) :
    (componentWalk C p hu hv).length = p.length := by
  induction p with
  | nil => rfl
  | cons hab p ih => simp [componentWalk, ih]

/-- Independently color each component with the same palette. -/
theorem PackingColorable.of_components {V : Type*} {G : SimpleGraph V} {k : ℕ}
    (h : ∀ C : G.ConnectedComponent, PackingColorable C.toSimpleGraph k) :
    PackingColorable G k := by
  classical
  choose colors bounded packing using h
  let c : V → ℕ := fun v => colors (G.connectedComponentMk v) ⟨v, rfl⟩
  have hc (C : G.ConnectedComponent) (v : C) : c v.val = colors C v := by
    obtain ⟨v, hv⟩ := v
    change G.connectedComponentMk v = C at hv
    subst C
    rfl
  refine ⟨c, fun v => bounded _ _, ?_⟩
  intro u v huv hcol p
  let C := G.connectedComponentMk u
  have hu : u ∈ C := rfl
  have hv : v ∈ C := (ConnectedComponent.sound p.reachable).symm
  have hp := packing C ⟨u, hu⟩ ⟨v, hv⟩ (fun h => huv (congrArg Subtype.val h))
    (by rw [← hc C ⟨u, hu⟩, ← hc C ⟨v, hv⟩]; exact hcol)
    (componentWalk C p hu hv)
  simpa only [componentWalk_length, ← hc C ⟨u, hu⟩] using hp

theorem PackingColorable.iff_components {V : Type*} {G : SimpleGraph V} {k : ℕ} :
    PackingColorable G k ↔ ∀ C : G.ConnectedComponent, PackingColorable C.toSimpleGraph k := by
  constructor
  · intro h C
    exact h.pullback C.toSimpleGraph_hom Subtype.val_injective
  · exact PackingColorable.of_components

/-- A connected component retains every neighbor of each of its vertices. -/
theorem component_degree {V : Type*} [Fintype V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (C : G.ConnectedComponent) [Fintype C]
    [DecidableRel C.toSimpleGraph.Adj] (v : C) : C.toSimpleGraph.degree v = G.degree v.val := by
  classical
  convert G.degree_induce_of_neighborSet_subset
    (fun _ hadj => C.mem_supp_of_adj_mem_supp v.prop hadj) using 1
  congr 1
  exact Subsingleton.elim _ _

/-- The local target hypotheses pass to each connected component. -/
theorem TargetClass.component {V : Type*} [Fintype V] {G : SimpleGraph V}
    [DecidableRel G.Adj] (h : TargetClass G) (C : G.ConnectedComponent)
    [Fintype C] [DecidableRel C.toSimpleGraph.Adj] : TargetClass C.toSimpleGraph := by
  classical
  refine ⟨?_, ?_, ?_⟩
  · intro v
    simpa only [component_degree] using h.1 v.val
  · intro v hv
    have hv' : G.degree v.val = 3 := by simpa only [component_degree] using hv
    obtain ⟨a, b, hab, hva, habadj, hbv⟩ := h.2.1 v.val hv'
    have ha : a ∈ C := C.mem_supp_of_adj_mem_supp v.prop hva
    have hb : b ∈ C := C.mem_supp_of_adj_mem_supp v.prop hbv.symm
    exact ⟨⟨a, ha⟩, ⟨b, hb⟩, fun he => hab (congrArg Subtype.val he), hva, habadj, hbv⟩
  · intro v hv a b hva ha hvb hb
    apply Subtype.ext
    apply h.2.2 v.val (by simpa only [component_degree] using hv) a.val b.val hva
      (by simpa only [component_degree] using ha) hvb
      (by simpa only [component_degree] using hb)

/-- The local target hypotheses are invariant under graph isomorphism. -/
theorem TargetClass.of_iso {V W : Type*} [Fintype V] [Fintype W]
    {G : SimpleGraph V} {H : SimpleGraph W} [DecidableRel G.Adj] [DecidableRel H.Adj]
    (h : TargetClass H) (e : G ≃g H) : TargetClass G := by
  refine ⟨?_, ?_, ?_⟩
  · intro v
    simpa only [e.degree_eq] using h.1 (e v)
  · intro v hv
    have hev : H.degree (e v) = 3 := by simpa only [e.degree_eq] using hv
    obtain ⟨a, b, hab, hva, habadj, hbv⟩ := h.2.1 (e v) hev
    refine ⟨e.symm a, e.symm b, fun he => hab (e.symm.injective he), ?_, ?_, ?_⟩
    · have q : G.Adj (e.symm (e v)) (e.symm a) := e.symm.toHom.map_rel hva
      simpa only [RelIso.symm_apply_apply] using q
    · exact e.symm.toHom.map_rel habadj
    · have q : G.Adj (e.symm b) (e.symm (e v)) := e.symm.toHom.map_rel hbv
      simpa only [RelIso.symm_apply_apply] using q
  · intro v hv a b hva ha hvb hb
    apply e.injective
    exact h.2.2 (e v) (by simpa only [e.degree_eq] using hv) (e a) (e b)
      (e.toHom.map_rel hva) (by simpa only [e.degree_eq] using ha)
      (e.toHom.map_rel hvb) (by simpa only [e.degree_eq] using hb)

/-- The graph with no edges admits a one-color packing coloring. -/
theorem PackingColorable.edgeless {V : Type*} {G : SimpleGraph V} {k : ℕ}
    (hedge : ∀ u v, ¬ G.Adj u v) (hk : 1 ≤ k) : PackingColorable G k := by
  refine ⟨fun _ => 1, fun _ => ⟨le_rfl, hk⟩, ?_⟩
  intro u v huv _ p
  cases p with
  | nil => exact (huv rfl).elim
  | cons hadj _ => exact (hedge _ _ hadj).elim

end Packing
