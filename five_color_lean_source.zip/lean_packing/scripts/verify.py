"""Build the Lean sources and reject nonstandard axioms in the advertised results."""
from pathlib import Path
import subprocess, json, re, hashlib, datetime, time, argparse
root=Path(__file__).resolve().parents[1]
lake=Path.home()/'.elan/bin/lake'
logs=root/'logs';logs.mkdir(exist_ok=True)
start=time.monotonic()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--jobs',type=int,default=4,help='Maximum expensive root modules per build batch (default: 4).')
args=parser.parse_args()
if args.jobs<1:parser.error('--jobs must be positive')
heavy=[f'CoverChecks{i}' for i in range(4)]+['AutoInit']
heavy += [f'AutoPower{i}' for i in range(15)]+[f'AutoGap{i}' for i in range(14)]
heavy += ['History','SmallGraphs','Sharpness','SharpnessClass']
with (logs/'final_build.log').open('w') as log:
    batches=[['Packing.'+s for s in heavy[i:i+args.jobs]] for i in range(0,len(heavy),args.jobs)]+[[]]
    for batch in batches:
        command=[str(lake),'build']+batch
        print('Building:',', '.join(batch) if batch else 'full project',flush=True)
        build=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        log.write('$ '+' '.join(command)+'\n'+build.stdout);log.flush()
        if build.returncode:
            print(build.stdout[-14000:]);raise SystemExit(build.returncode)
audit=subprocess.run([str(lake),'env','lean','Packing/Audit.lean'],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(logs/'axioms.log').write_text(audit.stdout)
if audit.returncode:
    print(audit.stdout[-14000:]);raise SystemExit(audit.returncode)
allowed={'propext','Classical.choice','Quot.sound'}
entries={name:[x.strip() for x in xs.split(',') if x.strip()]
         for name,xs in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",audit.stdout)}
expected=[
 'Packing.Universal.arbitrary_gap_sequence','Packing.Universal.long_single_gap',
 'Packing.Automaton.stabilization','Packing.History.ordinary_steps_sound',
 'Packing.History.periodic_two_arc_separation','Packing.closed_history_walk',
 'Packing.closed_history_cycle_colorable','Packing.IsPacking.withTips',
 'Packing.periodic_history_marked_cycle_colorable',
 'Packing.necklace_two_or_more_colorable','Packing.necklace_long_singleton_colorable',
 'Packing.necklace_colorable','Packing.SingleGap2.colorable',
 'Packing.SingleGap3.colorable','Packing.SingleGap4.colorable',
 'Packing.triangle_has_degree_two','Packing.SmallGraphs.Diamond.colorable',
 'Packing.SmallGraphs.GapThree.colorable','Packing.SmallGraphs.GapFour.colorable',
 'Packing.SmallGraphs.Barbell.colorable','Packing.SmallGraphs.SharpnessExample.colorable',
 'Packing.SmallGraphs.SharpnessExample.not_four_colorable',
 'Packing.SmallGraphs.SharpnessExample.in_target_class',
 'Packing.SmallGraphs.SharpnessExample.exactly_five',
 'Packing.PackingColorable.of_components','Packing.TargetClass.component',
 'Packing.connected_shared_edge_colorable','Packing.TriangleSelection.exists_data',
 'Packing.TipDeletionData.connected','Packing.TipDeletionData.degree_le_two',
 'Packing.TipDeletionData.colorable','Packing.degree_two_vertex_order',
 'Packing.degree_two_induced_cycle','Packing.connected_barbell_colorable',
 'Packing.TipDeletionData.bridge_colorable','Packing.backboneCycle_colorable',
 'Packing.degree_two_colorable','Packing.markedCycle_colorable',
 'Packing.degree_two_tipped_cycle','Packing.cyclic_spacing_of_predecessor_exclusions',
 'Packing.degree_two_tipped_colorable','Packing.connected_target_colorable',
 'Packing.target_class_colorable','Packing.target_theorem',
 'Packing.full_theorem_and_sharpness']
if set(entries)!=set(expected):
    raise SystemExit('Axiom audit did not return exactly the expected theorem list: '+repr(entries))
if any(set(xs)-allowed for xs in entries.values()):
    raise SystemExit('Nonstandard axioms found: '+repr(entries))
source=list((root/'Packing').glob('*.lean'))+[root/'Packing.lean',root/'lean-toolchain',root/'lakefile.toml',root/'lake-manifest.json']
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source)}
report={'status':'PASS','scope':'Full formalization of TargetTheorem and sharpness: all finite graphs in TargetClass are packing-colorable with five colors, and a twelve-vertex member is not four-colorable.',
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'lean':subprocess.check_output([str(lake),'env','lean','--version'],cwd=root,text=True).strip(),
 'mathlib_commit':subprocess.check_output(['git','-C','.lake/packages/mathlib','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'standard_axioms_only':True,'audited_theorems':entries,
 'source_sha256':hashes,'verification_seconds':round(time.monotonic()-start,3)}
(root/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','scope','standard_axioms_only','verification_seconds']},indent=2))
print('Audited theorems:',len(entries))
