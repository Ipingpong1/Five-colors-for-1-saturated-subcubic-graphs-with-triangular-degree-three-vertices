"""Check that packaged witness generators reproduce the checked Lean source data."""
from pathlib import Path
import tempfile, shutil, subprocess, sys, hashlib, json
root=Path(__file__).resolve().parents[1]
names=['generate_data.py','generate_cover_witnesses.py','generate_auto_checks.py','generate_small_graphs.py','generate_sharpness.py','generate_single_necklaces.py']
with tempfile.TemporaryDirectory(prefix='packing-regeneration-') as td:
    target=Path(td)
    (target/'scripts').mkdir();(target/'Packing').mkdir()
    for name in names:shutil.copy2(root/'scripts'/name,target/'scripts'/name)
    for name in names:
        subprocess.run([sys.executable,str(target/'scripts'/name)],cwd=target,check=True,stdout=subprocess.DEVNULL)
    files=sorted((target/'Packing').glob('*.lean'))
    mismatches=[p.name for p in files if not (root/'Packing'/p.name).exists() or p.read_bytes()!=(root/'Packing'/p.name).read_bytes()]
    if mismatches:raise SystemExit('Generated-source mismatch: '+repr(mismatches))
    print(json.dumps({'status':'PASS','generated_files':len(files),'generators':names}))
