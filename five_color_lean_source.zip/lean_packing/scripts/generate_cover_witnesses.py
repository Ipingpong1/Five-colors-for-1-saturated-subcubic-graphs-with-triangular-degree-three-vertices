"""Untrusted witness generation; soundness is proved in Packing.Coverage."""
from pathlib import Path
import runpy
r=runpy.run_path(str(Path(__file__).with_name('generate_data.py')))
root=r['ROOT']
def cover(P,Q,R):
    cache={}; result=[]
    for target,left in zip(P,Q):
        key=target,left
        if key not in cache:
            candidates=[k for k in range(len(R)) if left>>k&1]
            todo=target; selected=[]
            while todo:
                k=max(candidates,key=lambda k:(todo&R[k]).bit_count())
                assert todo&R[k]
                selected.append(k);todo &= ~R[k]
            cache[key]=selected
        result.append(cache[key])
    return result

def literal(w): return '⟨#['+','.join('['+','.join(map(str,row))+']' for row in w)+'], by rfl⟩'
header='import Packing.Data\nimport Packing.Coverage\nnamespace Packing.Checked\nopen Data\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nset_option cbv.maxSteps 10000000\n'
chunks=[[header] for _ in range(4)]
facts=[]
for g in range(14):
    for h in range(14):
        j=r['pairSeeds'][g][h]
        facts.append((f'pair{g}_{h}',f'M{j}',f'R{g}',f'R{h}',r['M'][j],r['R'][g],r['R'][h]))
for i in range(18):
    for g in range(14):
        j=r['extensions'][i][g]
        facts.append((f'ext{i}_{g}',f'M{j}',f'M{i}',f'R{g}',r['M'][j],r['M'][i],r['R'][g]))
maxWitness=0
for ix,(name,p,q,z,P,Q,R) in enumerate(facts):
    ws=cover(P,Q,R);maxWitness=max(maxWitness,max(map(len,ws)))
    chunks[ix%4].append(f'def w_{name} : CoverWitness 171 := {literal(ws)}\ntheorem {name} : {p}.denote.Included ({q}.denote.comp {z}.denote) := by\n  apply coverCheck_sound {p} {q} {z} w_{name}\n  decide_cbv')
for i in range(18):chunks[0].append(f'theorem diag{i} : M{i}.diagCheck = true := by decide_cbv')
for g in range(11):
    j=r['oneSeeds'][g]
    chunks[0].append(f'theorem one{g} : M{j}.subCheck R{g+3} = true := by decide_cbv')
for i,out in enumerate(chunks):
    out.append('end Packing.Checked')
    (root/f'Packing/CoverChecks{i}.lean').write_text('\n\n'.join(out)+'\n')
(root/'Packing/Checked.lean').write_text('\n'.join(f'import Packing.CoverChecks{i}' for i in range(4))+'\n')
print({'product_inclusions':len(facts),'largest_row_witness':maxWitness})
