"""Generate untrusted literal witnesses; Lean must check every claimed property."""
from itertools import product, combinations
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def good(s):
    return all(s[i]!=s[j] or j-i>s[i] for i,j in combinations(range(len(s)),2))
W=[s for s in product(range(1,6),repeat=5) if good(s)]
wi={s:i for i,s in enumerate(W)}
def transition(pal):
    return tuple(sum(1<<wi[s[1:]+(c,)] for c in pal if good(s+(c,))) for s in W)
def mul(a,b):
    cache={}
    for row in set(a):
        bits,out=row,0
        while bits:
            low=bits & -bits
            out |= b[low.bit_length()-1]
            bits-=low
        cache[row]=out
    return tuple(cache[r] for r in a)
def sub(a,b): return all(x&~y==0 for x,y in zip(a,b))
B,A=transition(range(1,6)),transition(range(2,6))
P=[tuple(1<<i for i in range(len(W)))]
for _ in range(15): P.append(mul(P[-1],B))
ids=[i for i,s in enumerate(W) if s[-2]!=1 and s[-1]!=1]
R=[]
for g in range(2,16):
    raw=mul(mul(P[g-1],A),A)
    R.append(tuple(sum(1<<j for j,v in enumerate(ids) if raw[u]&(1<<v)) for u in ids))
words=['22','32','23','33','24','34','222','223','224','322','323','324','232','233','234','332','333','334']
M=[]
for w in words:
    m=tuple(1<<i for i in range(len(ids)))
    for g in map(int,w): m=mul(m,R[g-2])
    M.append(m)
pairSeeds=[[next(i for i,m in enumerate(M) if sub(m,mul(r,s))) for s in R] for r in R]
oneSeeds=[next(i for i,m in enumerate(M) if sub(m,r)) for r in R[3:]]
extensions=[[next(j for j,k in enumerate(M) if sub(k,mul(m,r))) for r in R] for m in M]
def vec(xs): return '⟨#['+','.join(map(str,xs))+'], by rfl⟩'
out=['import Packing.BitMatrix','namespace Packing.Data', 'set_option maxRecDepth 10000',
     'def histories : Vector (Vector Nat 5) 390 := '+vec(map(vec,W)),
     'def boundary : Vector (Fin 390) 171 := '+vec('⟨%s, by decide⟩'%i for i in ids)]
for name,arr in [('B',B),('A',A)]+[(f'P{i}',p) for i,p in enumerate(P)]+[(f'R{i}',r) for i,r in enumerate(R)]+[(f'M{i}',m) for i,m in enumerate(M)]:
    out.append(f'def {name} : BitMatrix {len(arr)} := '+vec(arr))
for name,prefix,n,sz in [('powers','P',16,390),('gaps','R',14,171),('cert','M',18,171)]:
    out.append(f'def {name} : Vector (BitMatrix {sz}) {n} := '+vec(f'{prefix}{i}' for i in range(n)))
out.append('def pairSeeds : Vector (Vector (Fin 18) 14) 14 := '+vec(vec(f'⟨{i}, by decide⟩' for i in row) for row in pairSeeds))
out.append('def oneSeeds : Vector (Fin 18) 11 := '+vec(f'⟨{i}, by decide⟩' for i in oneSeeds))
out.append('def extensions : Vector (Vector (Fin 18) 14) 18 := '+vec(vec(f'⟨{i}, by decide⟩' for i in row) for row in extensions))
out.append('def historyAt (i : Fin 390) : Vector Nat 5 := match i.val with\n'+'\n'.join(f'  | {i} => '+vec(w) for i,w in enumerate(W[:-1]))+'\n  | _ => '+vec(W[-1]))
out.append('def boundaryAt (i : Fin 171) : Fin 390 := match i.val with\n'+'\n'.join(f'  | {j} => ⟨{i}, by decide⟩' for j,i in enumerate(ids[:-1]))+f'\n  | _ => ⟨{ids[-1]}, by decide⟩')
out.append('end Packing.Data')
(ROOT/'Packing/Data.lean').write_text('\n\n'.join(out)+'\n')
print(json.dumps({'states':len(W),'boundary':len(ids),'relations':len(M),'bytes':(ROOT/'Packing/Data.lean').stat().st_size}))
