from pathlib import Path
from collections import deque
root=Path(__file__).resolve().parents[1]
edges=[(0,1),(0,2),(1,2),(1,9),(9,3),(3,4),(3,5),(4,5),(4,10),(10,6),(6,7),(6,8),(7,8),(7,11),(11,0)]
adj=[set() for _ in range(12)]
for u,v in edges:adj[u].add(v);adj[v].add(u)
paths={}
for u in range(12):
    found={u:[u]};q=deque([u])
    while q:
        v=q.popleft()
        for w in sorted(adj[v]):
            if w not in found:found[w]=found[v]+[w];q.append(w)
    for v in range(u+1,12):paths[u,v]=found[v]
out=['import Packing.SmallGraphs','namespace Packing.SmallGraphs.SharpnessExample','set_option maxRecDepth 100000','set_option maxHeartbeats 0']
for (u,v),p in paths.items():
    d=len(p)-1
    if d>4:continue
    walk='SimpleGraph.Walk.nil'
    for _ in p[:-1]:walk=f'(SimpleGraph.Walk.cons (by decide) {walk})'
    # Explicit intermediate vertices remove all inference ambiguity.
    walk='(SimpleGraph.Walk.nil : graph.Walk %d %d)'%(v,v)
    for a,b in reversed(list(zip(p,p[1:]))):walk=f'(SimpleGraph.Walk.cons (by decide : graph.Adj {a} {b}) {walk})'
    out.append(f'''theorem short_{u}_{v} (c : Fin 12 → Nat) (hp : IsPacking graph c)
    (he : c {u} = c {v}) : c {u} < {d} := by
  have h := hp {u} {v} (by decide) he {walk}
  simpa only [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_nil] using h''')
out.append('theorem four_cases (n : Nat) (h : 1 ≤ n ∧ n ≤ 4) : n = 1 ∨ n = 2 ∨ n = 3 ∨ n = 4 := by omega')
out.append('theorem not_four_colorable : ¬ PackingColorable graph 4 := by\n  rintro ⟨c, hb, hp⟩')
order=sorted(range(12),key=lambda u:(-len(adj[u]),u))
assign={};calls=0;leaves=0

def tree(depth,indent):
    global calls,leaves
    calls+=1
    if depth==12:raise RuntimeError('SAT coloring')
    u=order[depth]
    out.append(indent+f'rcases four_cases (c {u}) (hb {u}) with h{u} | h{u} | h{u} | h{u}')
    for color in range(1,5):
        conflict=next((v for v,k in assign.items() if k==color and len(paths[min(u,v),max(u,v)])-1<=color),None)
        if conflict is None:
            assign[u]=color
            out.append(indent+'·')
            tree(depth+1,indent+'  ')
            del assign[u]
        else:
            a,b=sorted([u,conflict]);d=len(paths[a,b])-1
            out.append(indent+f'· have h := short_{a}_{b} c hp (h{a}.trans h{b}.symm)')
            out.append(indent+f'  rw [h{a}] at h')
            out.append(indent+f'  exact (by decide : ¬ ({color} < {d})) h')
            leaves+=1

tree(0,'  ')
out.append('#print axioms not_four_colorable\nend Packing.SmallGraphs.SharpnessExample')
(root/'Packing/Sharpness.lean').write_text('\n'.join(out)+'\n')
print({'nodes':calls,'leaves':leaves,'bytes':(root/'Packing/Sharpness.lean').stat().st_size})
