from pathlib import Path
from itertools import combinations
from collections import deque
root=Path(__file__).resolve().parents[1]
def necklace(gs):
    t=len(gs); edges=[]; n=3*t
    for i,g in enumerate(gs):
        edges.extend(combinations(range(3*i,3*i+3),2)); old=3*i+1
        for _ in range(g-1):
            edges.append((old,n));old=n;n+=1
        edges.append((old,3*((i+1)%t)))
    return n,edges
cases=[('Diamond',necklace([2]),[3,2,1,1],4),('GapThree',necklace([3]),[4,3,1,2,1],4),('GapFour',necklace([4]),[4,3,1,1,2,1],4),('Barbell',(6,[(0,1),(0,2),(1,2),(2,3),(3,4),(3,5),(4,5)]),[3,2,1,4,2,1],4),('SharpnessExample',necklace([2,2,2]),[5,2,1,4,2,1,3,2,1,1,1,1],5)]
out=['import Packing.Graphs','namespace Packing.SmallGraphs','set_option maxRecDepth 100000','set_option maxHeartbeats 0','set_option cbv.maxSteps 10000000']
for name,(n,es),cs,k in cases:
    adj=[set() for _ in range(n)]
    for u,v in es:adj[u].add(v);adj[v].add(u)
    ds=[]
    for u in range(n):
        d=[n+1]*n;d[u]=0;q=deque([u])
        while q:
            v=q.popleft()
            for w in adj[v]:
                if d[w]>n:d[w]=d[v]+1;q.append(w)
        ds.append(d)
    vec=lambda a:'#[%s]'%(','.join(map(str,a)))
    out.append(f'''namespace {name}
def edges : List (Nat × Nat) := [{','.join(f'({u},{v})' for u,v in es)}]
def graph : SimpleGraph (Fin {n}) := SimpleGraph.fromRel (fun u v => (u.val,v.val) ∈ edges)
instance : DecidableRel graph.Adj := by unfold graph SimpleGraph.fromRel; infer_instance
def color (v : Fin {n}) : Nat := ({vec(cs)} : Array Nat)[v.val]!
def dist (u v : Fin {n}) : Nat := ({vec(map(vec,ds))} : Array (Array Nat))[u.val]![v.val]!
theorem zero : ∀ u, dist u u = 0 := by decide_cbv
theorem edge_bounds : ∀ root u v, graph.Adj u v → dist root v ≤ dist root u + 1 := by decide_cbv
theorem separated : ∀ u v, u ≠ v → color u = color v → color u < dist u v := by decide_cbv
theorem color_bounds : ∀ v, 1 ≤ color v ∧ color v ≤ {k} := by decide_cbv
theorem colorable : PackingColorable graph {k} := by
  refine ⟨color, color_bounds, ?_⟩
  exact isPacking_of_distance_lower_bound color dist
    (distance_lower_bound_of_edge_bounds dist zero edge_bounds) separated
end {name}''')
out.append('#print axioms SharpnessExample.colorable\nend Packing.SmallGraphs')
(root/'Packing/SmallGraphs.lean').write_text('\n\n'.join(out)+'\n')
