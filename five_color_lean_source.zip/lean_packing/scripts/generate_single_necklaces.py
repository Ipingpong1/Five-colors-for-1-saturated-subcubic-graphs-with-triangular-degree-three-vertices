from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=['''import Packing.NecklaceDefs
import Packing.SmallGraphs

namespace Packing
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000

instance (L : Nat) : DecidableRel (backboneCycle L).Adj := by
  unfold backboneCycle SimpleGraph.fromRel
  infer_instance

theorem singleTip_value (g : Nat) (t : NecklaceTip [g]) : t.val = g+1 := by
  have h := t.property
  simpa [segmentEnds] using h

theorem singleTip_unique (g : Nat) (s t : NecklaceTip [g]) : s = t :=
  Subtype.ext ((singleTip_value g s).trans (singleTip_value g t).symm)

theorem singleMark_zero (g : Nat) (hL : 0 < backboneLength [g]) (t : NecklaceTip [g]) :
    necklaceMark [g] hL t = ⟨0, hL⟩ := by
  apply Fin.ext
  simp [necklaceMark, singleTip_value, backboneLength]
''']
for g,name in [(2,'Diamond'),(3,'GapThree'),(4,'GapFour')]:
    L,N=g+1,g+2
    row=[1]+list(range(3,N))+[0]
    rowlit='⟨#['+','.join(f'⟨{x}, by decide⟩' for x in row)+'], by rfl⟩'
    out.append(f'''namespace SingleGap{g}
def back (v : Fin {L}) : Fin {N} :=
  ({rowlit} : Vector (Fin {N}) {L})[v.val]

theorem back_injective : Function.Injective back := by
  unfold Function.Injective
  decide_cbv

theorem back_avoids_tip : ∀ v, back v ≠ 2 := by decide_cbv

theorem back_edges : ∀ u v, (backboneCycle {L}).Adj u v →
    SmallGraphs.{name}.graph.Adj (back u) (back v) := by decide_cbv

def mapVertex : Fin {L} ⊕ NecklaceTip [{g}] → Fin {N} :=
  Sum.elim back (fun _ => 2)

theorem map_injective : Function.Injective mapVertex := by
  intro x y he
  cases x with
  | inl u =>
    cases y with
    | inl v => exact congrArg Sum.inl (back_injective he)
    | inr t => exact False.elim (back_avoids_tip u he)
  | inr s =>
    cases y with
    | inl v => exact False.elim (back_avoids_tip v he.symm)
    | inr t => exact congrArg Sum.inr (singleTip_unique {g} s t)

def hom : necklace [{g}] (by decide) →g SmallGraphs.{name}.graph where
  toFun := mapVertex
  map_rel' := by
    intro x y h
    cases x with
    | inl u =>
      cases y with
      | inl v => exact back_edges u v h
      | inr t =>
        change u = cyclePrev (necklaceMark [{g}] _ t) ∨ u = necklaceMark [{g}] _ t at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
    | inr s =>
      cases y with
      | inl v =>
        change v = cyclePrev (necklaceMark [{g}] _ s) ∨ v = necklaceMark [{g}] _ s at h
        rw [singleMark_zero] at h
        rcases h with rfl | rfl <;> decide_cbv
      | inr t => exact False.elim h

theorem colorable : PackingColorable (necklace [{g}] (by decide)) 4 :=
  SmallGraphs.{name}.colorable.pullback hom map_injective
end SingleGap{g}
''')
out.append('#print axioms SingleGap2.colorable\n#print axioms SingleGap3.colorable\n#print axioms SingleGap4.colorable\nend Packing')
(root/'Packing/SingleNecklaces.lean').write_text('\n'.join(out)+'\n')
