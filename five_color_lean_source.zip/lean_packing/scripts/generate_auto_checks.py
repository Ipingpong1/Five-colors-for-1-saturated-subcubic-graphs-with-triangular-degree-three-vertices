from pathlib import Path
root=Path(__file__).resolve().parents[1]
header='''import Packing.GapDefs
import Packing.FastMatrix
namespace Packing.Automaton.Checks
open Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option cbv.maxSteps 10000000
'''
modules=[]
def save(name,body):
    (root/f'Packing/{name}.lean').write_text(header+'\n'+body+'\nend Packing.Automaton.Checks\n')
    modules.append(name)
save('AutoInit','''theorem initial_checked : P0 = BitMatrix.ident 390 := by
  apply BitMatrix.eqCheck_sound
  decide +kernel

theorem stabilization_checked : P14 = P15 := by rfl''')
for k in range(15):
    save(f'AutoPower{k}',f'''theorem power_step{k} : P{k}.mul B = P{k+1} := by
  rw [← BitMatrix.fastMul_eq]
  apply BitMatrix.eqCheck_sound
  {'decide +kernel' if k < 6 else 'decide_cbv'}''')
for k in range(14):
    save(f'AutoGap{k}',f'''theorem gap_check{k} : ((P{k+1}.mul A).mul A).restrict boundaryMap = R{k} := by
  rw [← BitMatrix.fastMul_eq, ← BitMatrix.fastMul_eq]
  apply BitMatrix.eqCheck_sound
  {'decide +kernel' if k < 5 else 'decide_cbv'}''')
(root/'Packing/AutoChecks.lean').write_text('\n'.join(f'import Packing.{m}' for m in modules)+'\n')
# These were earlier generated batches, superseded by one module per obligation.
for i in range(4):
    p=root/f'Packing/AutoChecks{i}.lean'
    if p.exists():p.unlink()
