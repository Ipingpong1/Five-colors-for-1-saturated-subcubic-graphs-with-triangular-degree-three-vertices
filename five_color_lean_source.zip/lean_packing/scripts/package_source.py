"""Package only sources and the successful audit; omit downloaded tools and build artifacts."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1]
report=json.loads((root/'verification.json').read_text())
if report.get('status')!='PASS': raise SystemExit('Successful verification is required.')
for name,digest in report['source_sha256'].items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Source changed after verification: '+name)
files=[root/x for x in ['README.txt','verification.json','lean-toolchain','lakefile.toml','lake-manifest.json','Packing.lean','.gitignore']]
files+=sorted((root/'Packing').glob('*.lean'))
files+=sorted((root/'scripts').glob('*.py'))
files += [root/'logs/axioms.log',root/'logs/final_build.log',root/'logs/regeneration.log']
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(root/'source_manifest.json')
output=root.parents[1]/'output/lean'; output.mkdir(parents=True,exist_ok=True)
archive=output/'five_color_lean_source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,Path('lean_packing')/p.relative_to(root))
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'files':len(files)}))
