LEAN FORMALIZATION OF THE FIVE-COLOR PACKING ARGUMENT
Local working supplement, started 5 October 2026.

STATUS

The main universal theorem and its sharpness are fully formalized.
Packing/FullTheorem.lean proves Packing.target_theorem : Packing.TargetTheorem,
using the exact statement recorded in Packing/Target.lean. No theorem assumes
that proposition as an axiom. The stronger arbitrary-finite-vertex-type theorem
is Packing.target_class_colorable; the combined result is
Packing.full_theorem_and_sharpness.

The result says that every finite simple subcubic graph whose degree-three
vertices each lie in a triangle and each have at most one degree-three neighbor
has a packing coloring with colors 1 through 5. Disconnected and empty graphs
are included. A specified twelve-vertex member cannot use four colors, so the
universal bound of five is sharp. This closes the structural-reduction gap in
the earlier partial formalization.

The final validation status and exact source hashes are in verification.json.
A missing file means the final validation has not yet completed.

ENVIRONMENT

Target: Conjecture 2 of El Zein and Mortada, arXiv:2603.25113v1.

Lean 4.34.1, installed through the official elan installer.
mathlib v4.34.1, commit d13f23b723b8a846827a245b89c10fc7d3f11612.
The toolchain and dependency revisions are pinned in lean-toolchain and
lake-manifest.json. Installation did not modify the user's shell startup files.

BUILD AND AUDIT

Recommended, from this directory with any Python 3:
  python3 scripts/verify.py

The script builds expensive root modules in batches of at most four to limit
memory pressure, then builds the whole project and audits the theorem axioms.
Use --jobs 1 on a machine with limited memory. The initial unrestricted build
on this machine caused substantial swapping; do not assume more concurrency
will finish faster. The checks can take tens of minutes or longer from scratch.

For a cached build, the direct commands are:
  ~/.elan/bin/lake build
  ~/.elan/bin/lake env lean Packing/Audit.lean

On a new machine, install elan, enter this directory, then run:
  ~/.elan/bin/lake exe cache get
  python3 scripts/verify.py

The computational checks can take substantial CPU time on a fresh build.
A successful cached build is much faster. No GPU or HPC is required.
Do not infer proof success from an interrupted or timed-out build.

To check that the witness generators reproduce the supplied Lean data files:
  python3 scripts/check_regeneration.py
This check is supplemental; Lean's successful build is what validates the proofs.

WHAT IS FORMALIZED

Relations.lean:
  Boolean-relation composition is monotone. If the finite certificate has
  its diagonal, seed, and extension properties, every extension of every
  seed has a diagonal. Consecutive equality of powers implies permanent
  stabilization. These are general proofs for arbitrary types and word lengths.

BitMatrix.lean and Coverage.lean:
  The executable bitset representation is connected by proofs to mathematical
  relations. Matrix multiplication, inclusion checking, diagonal checking,
  restriction, and explicit intermediate-state witness checking are proved sound.

Data.lean, CoverChecks0.lean through CoverChecks3.lean, Checked.lean,
Certificate.lean:
  The literal 390 history states, 171 boundary states, matrix generators,
  and 18 certificate relations are supplied as untrusted data. Lean checks
  18 diagonals, 196 two-letter seeds, 11 single-letter seeds, and 252 extensions.
  The product-inclusion checks use explicit intermediate-state witnesses.
  Their generator is not trusted. The kernel checks their validity using
  the proved coverCheck_sound theorem.
  The concrete induction establishes all finite words over the 14 generators.

Automaton.lean and Universal.lean:
  Powers of the concrete transition relation, B^14 = B^15, the definition
  of each gap relation, and stabilization for every larger gap.
  The concrete universal theorem covers all sequences with at least two gaps,
  each gap at least two, without any bound on lengths or gap values.
  One-gap words with gap at least five are also covered.

HistoryDefs.lean, History.lean, PathSemantics.lean:
  The history words are admissible. Every ordinary transition shifts the
  history correctly and forbids repeated colors at forbidden distances.
  Restricted transitions and boundary states avoid color 1 in the required
  positions. Infinite runs obey packing separation. Periodicity provides
  separation across both arcs of a cycle, including the wraparound cut.

Traces.lean, ClosedWalks.lean, Cycles.lean:
  Relation powers yield walks of the stated length. Closed nonempty walks
  yield periodic runs. Those runs give actual graph packing colorings of
  the unmarked backbone cycles.

Graphs.lean, Tips.lean:
  Packing coloring is defined by the absence of short connecting walks,
  correctly handling disconnected graphs. Colorings restrict along injective
  graph homomorphisms and to non-induced subgraphs. Coloring all added triangle
  tips 1 is sound when the two ports are adjacent and both avoid color 1.

MarkedCycles.lean:
  A periodic history run whose marked histories have their last two entries
  different from 1 gives a five-color packing coloring after attaching tips
  at those positions. The predecessor-coordinate identity is proved across
  the cyclic cut as well as at ordinary consecutive positions.

SegmentedTraces.lean, NecklaceDefs.lean, SingleNecklaces.lean, NecklaceTheorem.lean:
  Joined segments retain every cumulative endpoint when repeated periodically.
  The necklace graph is defined explicitly as a cycle with tips on the marked
  edges. Each list entry is the connector gap immediately preceding its tip.
  Every nonempty necklace whose connector gaps are at least two is five-colorable.
  Explicit injective graph homomorphisms connect the three short single-triangle
  cases to their checked four-colorings. Thus those cases use the same necklace
  definition as the unbounded family theorem.
  These are graph-coloring theorems with all triangle tips included, not just
  unmarked-cycle or abstract matrix-product statements.

TriangleLemmas.lean and TriangleStructure.lean:
  Every triangle in the target class has a degree-two vertex. Once a degree-three
  vertex has a degree-three neighbor, every other neighbor has degree at most two.
  Neighborhood exhaustion proves that overlapping distinct triangles form an
  entire diamond component, which inherits the checked four-coloring. In the
  absence of a diamond, triangles with a common vertex have identical vertex sets.

TriangleSelection.lean and TipDeletion.lean:
  Choose one degree-two tip from each unordered triangle. The chosen tips are
  independent; their retained port pairs are disjoint; every degree-three vertex
  loses a neighbor. Deleting the tips preserves connectivity and leaves maximum
  degree two. An explicit injective graph homomorphism restores all original
  vertices and edges into the backbone graph with its tips attached.

DegreeTwo.lean and CycleCompletion.lean:
  A longest path spans every connected finite graph of maximum degree two.
  Every edge is consecutive in that order or joins its endpoints. A genuine
  cycle is retained; a path is closed using two new vertices. The resulting
  embedding is induced: no new edge joins two old vertices. This stronger
  property preserves the forbidden-cross-edge condition on triangle ports.

ExceptionalComponents.lean:
  An injective copy of two triangles joined by an edge exhausts any connected
  target-class graph containing it. The component is the barbell and inherits
  its checked four-coloring. The theorem handles any orientation of the bridge
  between the selected port pairs.

MarkedCycleReduction.lean, TipCycleMaps.lean, and TipCycleReduction.lean:
  Orient the retained triangle edges on the completed cycle. Disjoint ports
  and the absence of cross-edges exclude separations one and two. Rotating and
  sorting the marks yields exactly the gap list and cumulative endpoints of a
  necklace with every connector gap at least two. The verified necklace theorem
  then supplies the coloring. Empty tip families and all short cycles are covered.

ConnectedReduction.lean, Components.lean, and FullTheorem.lean:
  Combine the diamond, barbell, and general backbone cases. Component restriction
  retains the exact target hypotheses and walk lengths; independently coloring
  all components proves the universal theorem, including the empty graph.
  The final conjunction includes the checked sharpness example.

SmallGraphs.lean:
  Explicit four-colorings of the three short single-triangle necklaces and
  the barbell, plus the five-coloring of the 12-vertex sharpness example.
  All use checked distance lower bounds justified by edge inequalities.

Sharpness.lean, SharpnessClass.lean, SharpnessResult.lean:
  The 12-vertex example satisfies the precise target-class hypotheses and
  cannot be packing-colored with four colors, hence its minimum palette is five.
  The generated exhaustive case proof has 1,485 branching nodes and 4,456
  contradiction leaves. Every leaf uses an explicit short graph walk, with
  every edge checked by Lean. No SAT solver or external distance computation
  is trusted for this lower bound.

SCOPE

The universal upper bound, its computational certificate, the graph reduction,
and the sharp lower-bound example are all included in the formal theorem.
Exploratory search logs, novelty/priority claims, and bibliographic assertions
are not mathematical conclusions of this formalization. A reviewer should still
compare TargetClass and IsPacking with the manuscript's intended definitions.

TRUST AND REVIEW

Completed proofs use ordinary Lean proofs, decide +kernel, and/or decide_cbv.
They do not use native_decide, admitted propositions, or custom result axioms.
The audit script checks that every advertised theorem depends only on a subset
of Lean's standard propext, Classical.choice, and Quot.sound axioms.

Python scripts only generate candidate literals and witnesses. They are not
part of the mathematical trust boundary. A corrupted or incorrect witness
must fail Lean's checker before it can support a theorem.

NegativeControls.lean also rejects an empty diagonal, an invalid intermediate
state witness, and a color-5 repeat at distance exactly five.

An optional additional kernel replay is available with:
  ~/.elan/bin/lake env leanchecker --fresh Packing.Audit
This rechecks the imported library as well and may be expensive. It is a replay
through Lean's kernel, not an independent human or external-logic review.

The reviewer must still inspect that definitions express the intended mathematics.
Kernel acceptance is not a novelty check and does not establish authorship or
priority. This is AI-assisted work and has not received independent human review.

READING ORDER

For a mathematician reviewing the scope, begin with FullTheorem.lean, Target.lean,
Graphs.lean, and ConnectedReduction.lean. Follow TriangleSelection.lean,
TipDeletion.lean, DegreeTwo.lean, CycleCompletion.lean, and TipCycleReduction.lean
for the reduction. Then read Relations.lean, Universal.lean, NecklaceDefs.lean,
and NecklaceTheorem.lean for the unbounded necklace argument.
For checking the computation, read BitMatrix.lean, Coverage.lean,
Certificate.lean, Automaton.lean, and the axiom audit.
The large generated literal files need not be read line by line: their role
is to provide data whose needed properties are checked in Lean.

The existing paper PDF, LaTeX source, Python proof checks, and public uploads
were not modified by this formalization work.
